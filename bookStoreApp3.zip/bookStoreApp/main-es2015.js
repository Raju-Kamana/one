(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/add-book/add-book.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/add-book/add-book.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card fxLayout=\"column\" fxLayoutGap=\"2%\" ngClass.lt-lg=\"mat-card-lt-md\">\n  <mat-toolbar fxLayoutAlign=\"center center\"\n    ><span>Add Book Form </span>\n  </mat-toolbar>\n  <div>\n    <form [formGroup]=\"bookForm\" fxLayout=\"column\" (ngSubmit)=\"onFormSubmit()\">\n      <div fxLayoutAlign=\"space-between center\">\n        <mat-form-field appearance=\"outline\" class=\"titleInput\">\n          <mat-label>Title</mat-label>\n          <input\n            required\n            matInput\n            formControlName=\"bookName\"\n            autocomplete=\"off\"\n          />\n          <mat-error *ngIf=\"bookForm.get('bookName').hasError('required')\">\n            book title is required</mat-error\n          >\n        </mat-form-field>\n        <mat-form-field appearance=\"outline\" class=\"authorInput\">\n          <mat-label>Author</mat-label>\n          <input\n            required\n            matInput\n            formControlName=\"authorName\"\n            autocomplete=\"off\"\n          />\n          <mat-error *ngIf=\"bookForm.get('authorName').hasError('required')\">\n            book author name is required</mat-error\n          >\n        </mat-form-field>\n      </div>\n      <div fxLayoutAlign=\"space-between center\">\n        <mat-form-field appearance=\"outline\" class=\"priceInput\">\n          <mat-label>Amount</mat-label>\n          <input\n            required\n            matInput\n            type=\"number\"\n            class=\"example-right-align\"\n            min=\"0\"\n            autocomplete=\"off\"\n            formControlName=\"price\"\n          />\n          <mat-error *ngIf=\"bookForm.get('price').hasError('min')\"\n            >Amount should not be less than zero</mat-error\n          >\n          <mat-error *ngIf=\"bookForm.get('price').hasError('required')\"\n            >book price is required</mat-error\n          >\n          <span matPrefix>₹&nbsp;</span>\n        </mat-form-field>\n        <mat-form-field appearance=\"outline\" class=\"quantityInput\">\n          <mat-label>Quantity</mat-label>\n          <input\n            matInput\n            required\n            type=\"number\"\n            min=\"1\"\n            autocomplete=\"off\"\n            formControlName=\"quantity\"\n          />\n          <mat-error *ngIf=\"bookForm.get('quantity').hasError('min')\"\n            >Quantity should not be less than zero</mat-error\n          >\n          <mat-error *ngIf=\"bookForm.get('quantity').hasError('pattern')\"\n            >Quantity should not be decimal values</mat-error\n          >\n          <mat-error *ngIf=\"bookForm.get('quantity').hasError('required')\"\n            >book quantity is required</mat-error\n          >\n        </mat-form-field>\n      </div>\n      <mat-form-field appearance=\"outline\">\n        <mat-label>Description</mat-label>\n        <textarea\n          required\n          matInput\n          style=\"overflow: hidden;\"\n          formControlName=\"description\"\n          autocomplete=\"off\"\n        ></textarea>\n        <mat-error *ngIf=\"bookForm.get('description').hasError('required')\"\n          >book description is required</mat-error\n        >\n      </mat-form-field>\n      <div fxLayout=\"column\">\n        <input\n          class=\"fileButton\"\n          type=\"file\"\n          formControlName=\"imageURL\"\n          autocomplete=\"off\"\n          (change)=\"onUploadBookImage($event)\"\n        />\n        <mat-error *ngIf=\"bookForm.get('imageURL').hasError('required')\"\n          >image must be uploaded</mat-error\n        >\n        <div fxLayoutAlign=\"end\">\n          <button\n            mat-raised-button\n            type=\"submit\"\n            [disableRipple]=\"true\"\n            [disabled]=\"!bookForm.valid\"\n          >\n            submit\n          </button>\n        </div>\n      </div>\n    </form>\n  </div>\n</mat-card>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/admin-login/admin-login.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/admin-login/admin-login.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  fxLayoutAlign=\"center center\"\n  class=\"container\"\n  style=\"\n    background-image: url('../../../assets/images/bookstore-wallpaper1.jpg');\n  \"\n  fxFill\n>\n<div fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n    <form [formGroup]=\"LoginForm\" >\n      <div>\n        <mat-card>\n          <mat-toolbar>\n            <span class=\"title-center\">{{ title }}</span>\n          </mat-toolbar>\n          <mat-form-field appearance=\"outline\">\n            <mat-label>Username</mat-label>\n            <input\n              type=\"text\"\n              formControlName=\"loginid\"\n              placeholder=\"username\" \n              autocomplete=\"off\"\n              maxlength=\"30\"\n              matInput\n              style=\"background: none\"\n              [ngClass]=\"{ 'is-invalid': submitted && f.loginid.errors }\"\n            />\n            <mat-icon style=\"color:black\" matSuffix>account_circle</mat-icon>\n            <mat-error *ngIf=\"LoginForm.get('loginid').hasError('required')\"\n              >*username is required</mat-error\n            >\n            </mat-form-field\n          ><br />\n  \n          <mat-form-field appearance=\"outline\">\n            <mat-label>Password</mat-label>\n            <input\n              matInput\n              [type]=\"hide ? 'password' : 'text'\"\n              formControlName=\"password\"\n              placeholder=\"password\"\n              autocomplete=\"off\"\n              maxlength=\"15\"\n              matInput\n              [ngClass]=\"{ 'is-invalid': submitted && f.password.errors }\"/>\n            <button\n              mat-icon-button\n              matSuffix\n              (click)=\"hide = !hide\"\n              [attr.aria-label]=\"'Hide password'\"\n              [attr.aria-pressed]=\"hide\">\n              <mat-icon style=\"color:black;\" matSuffix>{{\n                hide ? \"visibility_off\" : \"visibility\"}}</mat-icon>\n            </button>\n            <mat-error *ngIf=\"LoginForm.get('password').hasError('required')\">*password is required</mat-error>\n           \n            </mat-form-field>\n            <div>\n              <button mat-button  [routerLink]=\"['/forgotpassword']\">forgot password?</button>\n              <button mat-raised-button type=\"submit\" (click)=\"onSubmit()\">Next</button>\n             </div>\n            <div class=\"left\">\n            </div>\n           </mat-card><br/>\n        </div>\n    </form>\n  </div>\n </div> \n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/admin/admin.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/admin/admin.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <div>   \n    <mat-toolbar style=\"position: fixed ;z-index: 100;\" class=\"tool\" fxLayout=\"row\" fxLayoutAlign=\"space-around center\">\n        <div>\n                <img class=\"content\" src=\"../../../assets/images/education.svg\" />\n                <a class=\"content\" style=\"color: aliceblue\"\n                href=\"http://localhost:4200/admin-dashboard/sellers\"\n                > BookStore</a>\n        </div>\n            \n            <span >Welcome Admin</span>\n        <button  mat-icon-button style=\" color: aliceblue; outline: none\" matTooltip=\"Logout\" (click)=\"onLogout()\">\n            <mat-icon >logout</mat-icon>\n        </button>\n    </mat-toolbar>    \n</div><br><br><br>\n<router-outlet></router-outlet>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/book-review/book-review.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/book-review/book-review.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n  <div class=\"main-div\" fxLayout=\"row\" fxLayoutAlign=\"space-around center\">\n    <button mat-button  color=\"primary\" style=\"background: none\" *ngIf=\"rating!=5\" (click)=\"onRating(5)\">\n      <mat-icon>insert_emoticon</mat-icon>\n    </button>\n    <button mat-mini-fab  color=\"primary\" *ngIf=\"rating==5\">\n      <mat-icon>insert_emoticon</mat-icon>\n    </button>\n\n    <button mat-button style=\"color:rgb(43, 142, 223)\" *ngIf=\"rating!=4\" (click)=\"onRating(4)\">\n      <mat-icon>sentiment_satisfied_alt</mat-icon>\n    </button>\n    <button mat-mini-fab style=\"background-color:rgb(43, 142, 223)\" *ngIf=\"rating==4\">\n      <mat-icon>sentiment_satisfied_alt</mat-icon>\n    </button>\n\n    <button mat-button style=\"color:rgb(172, 157, 236)\" *ngIf=\"rating!=3\" (click)=\"onRating(3)\">\n      <mat-icon>sentiment_satisfied</mat-icon>\n    </button>\n    <button mat-mini-fab style=\"background-color:rgb(172, 157, 236)\" *ngIf=\"rating==3\">\n      <mat-icon>sentiment_satisfied</mat-icon>\n    </button>\n\n    <button mat-button color=\"accent\" *ngIf=\"rating!=2\" (click)=\"onRating(2)\">\n      <mat-icon>sentiment_dissatisfied</mat-icon>\n    </button>\n    <button mat-mini-fab color=\"accent\" *ngIf=\"rating==2\">\n      <mat-icon>sentiment_dissatisfied</mat-icon>\n    </button>\n\n    <button mat-button color=\"warn\" *ngIf=\"rating!=1\" (click)=\"onRating(1)\">\n      <mat-icon>sentiment_very_dissatisfied</mat-icon>\n    </button>\n    <button mat-mini-fab color=\"warn\" *ngIf=\"rating==1\">\n      <mat-icon>sentiment_very_dissatisfied</mat-icon>\n    </button>\n  </div>\n\n<div><span>Very Goog</span><span style=\"float: right\">Very Bad</span></div>\n<div fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n  <mat-form-field style=\"box-shadow: none;margin-top: 5%; width: 100%\">\n    <mat-label>Add Comment</mat-label>\n    <textarea matInput maxlength=\"200\" [(ngModel)]=\"review\" name=\"review\" placeholder=\"text\" style=\"overflow: hidden\"\n    cdkTextareaAutosize></textarea>\n  </mat-form-field>\n\n  <button mat-flat-button mat-dialog-close color=\"warn\" (click)=\"onSubmit()\">Submit</button>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/cart/cart.component.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/cart/cart.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  *ngIf=\"cartSize === 0\"\n  fxLayoutAlign=\"center center\"\n  fxLayout=\"column\"\n  fxLayoutGap=\"10px\"\n  style=\"padding-top: 15%;\"\n>\n  <img class=\"book-img\" src=\"../../../assets/images/education.svg\" />\n\n  <div style=\"font-weight: bold;\">\n    Your Cart Is Empty !\n  </div>\n  <div>\n    Add books to it now\n  </div>\n  <div>\n    <button\n      class=\"shop-now\"\n      mat-button\n      [disableRipple]=\"true\"\n      (click)=\"onShowNow()\"\n    >\n      Shop Now\n    </button>\n  </div>\n</div>\n<div\n  *ngIf=\"cartSize > 0\"\n  fxLayout=\"column\"\n  fxLayoutGap=\"2%\"\n  style=\"padding-left: 15%; padding-top: 10%;\"\n>\n  <!-- <div> -->\n  <mat-card>\n    <div fxLayout=\"column\">\n      <span class=\"My-cart\"> My Cart({{ cartSize }})</span>\n      <div\n        fxLayout=\"column\"\n        fxLayoutAlign=\"space-around start\"\n        *ngFor=\"let cartBook of cartBooks\"\n      >\n        <div class=\"book\" fxLayout=\"row\">\n          <div class=\"book-image\">\n            <img src=\"{{ cartBook.book.imageURL }}\" />\n          </div>\n\n          <div\n            fxLayout=\"column\"\n            fxLayoutAlign=\"start start\"\n            class=\"book-details\"\n            fxLayoutGap=\"6%\"\n          >\n            <span>{{ cartBook.book.bookName }}</span>\n            <span class=\"author-name\">by {{ cartBook.book.authorName }}</span>\n            <span>Rs. {{ cartBook.totalBookPrice }}</span>\n          </div>\n        </div>\n        <div\n          class=\"input-group\"\n          fxLayout=\"row\"\n          fxLayoutGap=\"2%\"\n          fxLayoutAlign=\"start center\"\n        >\n        <button\n        mat-mini-fab\n        class=\"button-minus\"\n        *ngIf=\"cartBook.bookQuantity==1\"\n        [disableRipple]=\"true\"\n        [disabled]= \"true\"\n        fxLayoutAlign=\"center start\"\n      >\n        <mat-icon\n          fxLayoutAlign=\"center center\"\n          style=\"color: black; font-size: xx-small;\"\n          >remove</mat-icon\n        >\n      </button>\n          <button\n            mat-mini-fab\n            class=\"button-minus\"\n            *ngIf=\"cartBook.bookQuantity>1\"\n            (click)=\"removeQuantity(cartBook)\"\n            [disableRipple]=\"true\"\n            fxLayoutAlign=\"center start\"\n          >\n            <mat-icon\n              fxLayoutAlign=\"center center\"\n              style=\"color: black; font-size: xx-small;\"\n              >remove</mat-icon\n            >\n          </button>\n            <input\n              mat-input\n              type=\"number\"\n              (input)=\"onKey($event,cartBook)\"\n              max=\"5\"\n              min=\"1\"\n              value=\"{{ cartBook.bookQuantity }}\"\n              class=\"quantity-field\"\n            />\n          <button\n            mat-mini-fab\n            class=\"button-plus\"\n            (click)=\"addQuantity(cartBook)\"\n            [disableRipple]=\"true\"\n            fxLayoutAlign=\"center start\"\n          >\n            <mat-icon\n              fxLayoutAlign=\"center center\"\n              style=\"color: black; font-size: xx-small;\"\n              >add</mat-icon\n            >\n          </button>\n          <button\n            mat-button\n            class=\"button-remove\"\n            (click)=\"removeFromCart(cartBook)\"\n            [disableRipple]=\"true\"\n            fxLayoutAlign=\"center center\"\n          >\n            Remove\n          </button>\n        </div>\n      </div>\n      <div fxLayoutAlign=\"end\">\n        <button\n          mat-button\n          (click)=\"onPlaceOrder()\"\n          class=\"button-placeorder\"\n          fxLayoutAlign=\"center center\"\n          [disableRipple]=\"true\"\n        >\n          <span style=\"font-size: small; height: 10px; color: white;\"\n            >PLACE ORDER</span\n          >\n        </button>\n      </div>\n    </div>\n  </mat-card>\n  <!-- </div> -->\n  <!-- <div> -->\n  <mat-card class=\"form\">\n    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Customer Details\n    <span fxLayoutAlign=\"end\" *ngIf=\"show\" (click)=\"onedit()\">Edit</span>\n    <ng-container *ngIf=\"show\">\n      <div style=\"margin: 0 auto; text-align: left;\">\n        <br />\n\n        <form [formGroup]=\"addressGroup\" (ngSubmit)=\"continue()\">\n          <mat-form-field appearance=\"outline\">\n            <mat-label>*Name</mat-label>\n            <input\n              matInput\n              placeholder=\"Placeholder\"\n              formControlName=\"name\"\n              id=\"name\"\n              required\n              #Myname\n              (input)=\"(Myname.value)\"\n              style=\"background: none;\"\n            /> </mat-form-field\n          ><br /><br />\n\n          <div class=\"row3\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Phone Number</mat-label>\n              <input\n                matInput\n                placeholder=\"Placeholder\"\n                formControlName=\"phone\"\n                id=\"phone\"\n                required\n                #Myphn\n                (input)=\"(Myphn.value)\"\n                style=\"background: none;\"\n              /> </mat-form-field\n            ><br /><br />\n          </div>\n          <mat-form-field appearance=\"outline\">\n            <mat-label>Pin code</mat-label>\n            <input\n              matInput\n              placeholder=\"Placeholder\"\n              formControlName=\"pincode\"\n              id=\"pincode\"\n              required\n              #Mypin\n              (input)=\"(Mypin.value)\"\n              style=\"background: none;\"\n            />\n          </mat-form-field>\n\n          <div class=\"row1\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>Locality</mat-label>\n              <input\n                matInput\n                placeholder=\"Placeholder\"\n                formControlName=\"locality\"\n                id=\"locality\"\n                required\n                #Mylocal\n                (input)=\"(Mylocal.value)\"\n                style=\"background: none;\"\n              /> </mat-form-field\n            ><br /><br />\n          </div>\n          <br /><br />\n\n          <mat-form-field appearance=\"outline\" fxFlexFill>\n            <mat-label>Address</mat-label>\n            <textarea\n              matInput\n              formControlName=\"address\"\n              required\n              #Myaddr\n              (input)=\"(Myaddr.value)\"\n              style=\"background: none;\"\n            ></textarea>\n          </mat-form-field>\n          <mat-form-field appearance=\"outline\">\n            <mat-label>City</mat-label>\n            <input\n              matInput\n              placeholder=\"Placeholder\"\n              formControlName=\"city\"\n              id=\"city\"\n              required\n              #Mycity\n              (input)=\"(Mycity.value)\"\n              style=\"background: none;\"\n            /> </mat-form-field\n          ><br />\n          <div class=\"row2\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>LandMark</mat-label>\n              <input\n                matInput\n                placeholder=\"Placeholder\"\n                formControlName=\"landmark\"\n                id=\"landmark\"\n                required\n                #landmark\n                (input)=\"(landmark.value)\"\n                style=\"background: none;\"\n              />\n            </mat-form-field>\n          </div>\n          <!-- <div class=\"row2\">\n            <mat-form-field appearance=\"outline\">\n              <mat-label>LandMark</mat-label>\n              <input\n                matInput\n                placeholder=\"Placeholder\"\n                formControlName=\"landmark\"\n                id=\"landmark\"\n                required\n               #landmark\n               (input)=\"landmark.value\"\n               style=\"background: none;\"\n              />\n            </mat-form-field>\n          </div>-->\n\n          <br /><br />\n          <mat-radio-group fxLayoutGap=\"5%\" formControlName=\"type\" required>\n            <mat-radio-button class=\"\" value=\"home\" (change)=\"selectAddrType($event)\">Home</mat-radio-button>\n            <mat-radio-button value=\"work\" (change)=\"selectAddrType($event)\">Work</mat-radio-button>\n            <mat-radio-button value=\"other\" (change)=\"selectAddrType($event)\">Other</mat-radio-button\n            > </mat-radio-group\n          ><br /><br />\n\n          <div fxLayoutAlign=\"end\">\n            <button\n              mat-button\n              class=\"button-placeorder\"\n              fxLayoutAlign=\"center center\"\n              [disableRipple]=\"true\"\n              [disabled]=\"addressGroup.invalid\"\n            >\n              <span style=\"font-size: small; height: 10px; color: white;\"\n                >Continue</span\n              >\n            </button>\n          </div>\n        </form>\n      </div>\n    </ng-container>\n  </mat-card>\n  <!-- </div>\n<div> -->\n  <mat-card>\n    <div fxLayout=\"column\">\n      <span class=\"My-cart\"> Order Summary</span>\n      <div\n        fxLayout=\"column\"\n        fxLayoutAlign=\"space-around start\"\n        *ngFor=\"let cartBook of cartBooks\"\n      >\n        <div class=\"book\" *ngIf=\"disp\" fxLayout=\"row\">\n          <div class=\"book-image\">\n            <img src=\"{{ cartBook.book.imageURL }}\" />\n          </div>\n\n          <div\n            fxLayout=\"column\" \n            fxLayoutAlign=\"start start\"\n            class=\"book-details\"\n            fxLayoutGap=\"6%\"\n          >\n            <span>{{ cartBook.book.bookName }}</span>\n            <span class=\"author-name\">by {{ cartBook.book.authorName }}</span>\n            <span>Rs. {{ cartBook.totalBookPrice }}</span>\n          </div>\n        </div>\n      </div>\n      <div class=\"total-price\" fxLayoutAlign=\"space-between center\">\n        <span *ngIf=\"disp\">  Total Price: Rs. {{totalPrice}}</span>\n        <button\n          mat-button\n          (click)=\"onCheckOut()\"\n          class=\"button-placeorder\"\n          fxLayoutAlign=\"center center\"\n          [disableRipple]=\"true\"\n          *ngIf=\"disp\"\n        >\n          <span style=\"font-size: small; height: 10px; color: white;\"\n            >CHECK OUT</span\n          >\n        </button>\n      </div>\n    </div>\n  </mat-card>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/dashboard/dashboard.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/dashboard/dashboard.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"width: 100%; height: 100%;\">\n  <mat-toolbar class=\"tool\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n    <div class=\"titleText\" fxLayout=\"row\" fxLayoutGap=\"2%\">\n      <img src=\"../../../assets/images/education.svg\" />\n      <a\n        routerLink=\"/dashboard/getallbooks\"\n        routerLinkActive=\"active\"\n        matTooltip=\"user Dashboard\"\n        style=\"color: white;\"\n      >\n        BookStore\n      </a>\n    </div>\n\n    <mat-card\n      class=\"search-mat-card\"\n      fxLayout=\"row\"\n      fxLayoutAlign=\"space-around center\"\n    >\n      <button mat-icon-button [disableRipple]=\"true\" matTooltip=\"search\">\n        <mat-icon class=\"searchIcon\">search</mat-icon>\n      </button>\n      <input\n        (input)=\"onKey($event)\"\n        class=\"searchInput\"\n        type=\"text\"\n        placeholder=\"Search..\"\n      />\n    </mat-card>\n    <button class=\"cart\" mat-icon-button (click)=\"onCart()\" matTooltip=\"Cart\">\n      Cart\n      <mat-icon matBadge=\"{{ cartCounter }}\" MatBadgeSize=\"small\"\n        >shopping_cart</mat-icon\n      ></button\n    ><br />\n\n    <button\n      mat-icon-button\n      [matMenuTriggerFor]=\"signoutmenu\"\n      disableRipple\n      style=\"outline: none;\"\n      matTooltip=\"profile\"\n    >\n      <img mat-card-avatar [src]=\"profile\" alt=\"profile\" class=\"profile\" />\n    </button>\n    <mat-menu\n      #signoutmenu=\"matMenu\"\n      (click)=\"$event.stopPropagation()\"\n      class=\"profilemenu\"\n      xPosition=\"after\"\n      yPosition=\"below\"\n    >\n      <div *ngIf=\"login; then loginblock; else notloggedblock\"></div>\n      <ng-template #loginblock>\n        <div fxLayoutAlign=\"space-around center\">\n          <img mat-card-avatar [src]=\"profile\" class=\"pic\" />\n          <div class=\"upload-img\">\n            <label for=\"file-input\">\n              <mat-icon class=\"icon\">camera_alt</mat-icon>\n            </label>\n            <input\n              type=\"file\"\n              (change)=\"OnSelectedFile($event)\"\n              class=\"fileuploadbtn\"\n              id=\"file-input\"\n            />\n          </div>\n        </div>\n        <div class=\"usertext\">\n          <div class=\"mat-subheading-1\">{{ this.username }}</div>\n          <div class=\"mat-subheading-1\">{{ this.usermail }}</div>\n        </div>\n        <mat-divider></mat-divider><br/>\n        <div class=\"editprofile\"  fxLayout=\"column\" fxLayoutAlign=\"center none\">\n          <button\n            class=\"edit\"\n            mat-button\n            class=\"editbutton\"\n            (click)=\"openDialogztoedit()\"\n            style=\"margin-bottom: 1%;\"\n          >\n          <mat-icon style=\"color: black\" matPrefix>edit</mat-icon>\n            Edit Profile</button\n          ><br />\n          <!--<mat-divider></mat-divider>-->\n          <button\n            class=\"edit\"\n            mat-button\n            class=\"editbutton\"\n            (click)=\"myorders()\"\n            style=\"margin-bottom: 1%;\"\n          >\n          <mat-icon style=\"color: black\" matPrefix>add_shopping_cart</mat-icon>\n            My orders\n          </button><br>\n         <!-- <mat-divider></mat-divider>-->\n          <button\n          class=\"edit\"\n         mat-button\n         class=\"editbutton\"\n          (click)=\"mywishlist()\"\n         >\n         <mat-icon style=\"color: black\" matPrefix>store</mat-icon>\n          My WishList</button\n        >\n      </div><br/>\n        <mat-divider></mat-divider>\n        <div class=\"logout\"  fxLayout=\"row\" fxLayoutAlign=\"center none\">\n          \n          <button id=\"logout\" mat-button (click)=\"Logout()\">\n              <mat-icon style=\"color: black\" matPrefix>perm_identity</mat-icon>  \n              Sign Out</button>\n        </div>\n      </ng-template>\n      <ng-template #notloggedblock>\n        <i><div style=\"padding-top: 8%;\" class=\"mat-headline\">Welcome</div> </i\n        ><br />\n        <mat-divider></mat-divider><br />\n        <div fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n          <button mat-button class=\"signup\" (click)=\"onsignup()\">\n            <mat-icon style=\"color: black\" matPrefix>account_circle</mat-icon>\n            Sign Up\n          </button\n          ><br />\n          <button mat-button class=\"log\" (click)=\"openDialog()\">\n              <mat-icon style=\"color: black\" matPrefix>how_to_reg</mat-icon>\n            Sign In\n          </button>\n        </div>\n      </ng-template>\n    </mat-menu>\n  </mat-toolbar>\n  <router-outlet></router-outlet><br><br><br>\n  </div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/display-books/display-books.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/display-books/display-books.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main-div\">\n  <div style=\"outline: none;\" fxLayout=\"row\" fxLayoutAlign=\"end\">\n    <button\n      mat-raised-button\n      class=\"addBookButton\"\n      fxLayoutAlign=\"center\"\n      [disableRipple]=\"true\"\n      (click)=\"openBookForm()\"\n    >\n      <span class=\"bookText\">Add Book</span>\n    </button>\n  </div>\n  <div\n    fxLayoutGap=\"40px\"\n    fxLayout.lt-sm=\"column\"\n    fxLayout.sm=\"row wrap\"\n    fxLayoutAlign.sm=\"start center\"\n    fxLayout.md=\"row wrap\"\n    fxLayoutAlign.md=\"start center\"\n    fxLayoutAlign.lt-sm=\"center center\"\n    fxLayout.lg=\"row wrap\"\n    fxLayoutAlign.lg=\"start center\"\n    fxLayout.gt-lg=\"row wrap\"\n  >\n    <div *ngFor=\"let book of books\" style=\"margin: 0px;\" fxLayout=\"row\">\n      <mat-card>\n        <div class=\"bookImageDiv\" fxLayoutAlign=\"center\">\n          <img src=\"{{ book.imageURL }}\" />\n        </div>\n\n        <div class=\"bookInfoDiv\" fxLayout=\"column\">\n          <div class=\"input-title\">\n            {{ book.bookName }}\n          </div>\n          <div fxlayout=\"row\" class=\"input-author\">\n            by {{ book.authorName }}\n          </div>\n          <!-- <div fxlayout=\"row\">\n            <span class=\"input-price-span\">Rs.</span>\n            <input\n              class=\"input-price\"\n              matInput\n              type=\"text\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"book.price\"\n              (click)=\"onUpdateBookForm(book)\"\n            />\n          </div> -->\n          <div fxLayout=\"row\">\n            <span class=\"input-price\">Rs.</span>\n            <input\n              class=\"input-price\"\n              matInput\n              type=\"text\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"book.price\"\n              (click)=\"onUpdateBookForm(book)\"\n            />\n          </div>\n          <div fxLayout=\"row\">\n            <span class=\"input-price\">Qty.</span>\n            <input\n              class=\"input-price\"\n              matInput\n              type=\"text\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"book.quantity\"\n              (click)=\"onUpdateBookForm(book)\"\n            />\n          </div>\n          <div class=\"input-price\" *ngIf=\"book.rejectionCounts > 0\">\n            Rejection: {{ book.rejectionCounts }}\n          </div>\n          <div fxLayout=\"row\" fxLayoutAlign=\"space-between\">\n            <button\n              class=\"approval-button\"\n              *ngIf=\"!book.approved && !book.approvalSent\"\n              mat-raised-button\n              fxLayoutAlign=\"center\"\n              [disableRipple]=\"true\"\n              (click)=\"onApproval(book.bookId)\"\n            >\n              APPROVAL\n            </button>\n            <button\n              class=\"sent-button\"\n              *ngIf=\"!book.approved && book.approvalSent\"\n              mat-raised-button\n              fxLayoutAlign=\"center\"\n              [disableRipple]=\"true\"\n            >\n              SENT\n            </button>\n            <button\n              class=\"approved-button\"\n              *ngIf=\"book.approved\"\n              mat-raised-button\n              fxLayoutAlign=\"center\"\n              [disableRipple]=\"true\"\n            >\n              APPROVED\n            </button>\n            <button\n              class=\"delete-button\"\n              mat-raised-button\n              fxLayoutAlign=\"center\"\n              [disableRipple]=\"true\"\n              \n            >\n              DELETE\n            </button>\n          </div>\n        </div>\n      </mat-card>\n      <div class=\"book-details\">\n        <h5>Book Details</h5>\n        <span class=\"input-price\">{{ book.description }}</span>\n      </div>\n    </div>\n    \n  </div>\n  <div class=\"paginator\" fxLayout = \"row\" fxLayoutAlign=\"center center\" fxLayoutGap = \"20px\">\n    <div><button class = \"page-buttons\" mat-mini-fab [disableRipple]=\"true\"><</button></div>\n    <div *ngFor=\"let page of pages\" >\n      <div  > <button (click)=\"onBooksByPage(page)\" class=\"page-number\"> {{page}}</button> </div>\n    </div>\n    <div><button class = \"page-buttons\" mat-mini-fab [disableRipple]=\"true\" >></button></div>\n    <!-- <mat-paginator   #paginator [length] = \"15\"\n      [pageIndex]=\"1\"\n       [pageSize] = \"8\"\n    >\n    </mat-paginator> -->\n  </div>  \n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/edit-profile/edit-profile.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/edit-profile/edit-profile.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h6 mat-dialog-title>Edit Profile</h6>\n<div class=\"container\" fxLayout=\"row\" fxLayoutGap=\"10%\">\n    <div  class=\"imgdiv\">\n        <label for=\"file-input\">\n        <div class=\"imagediv\">\n            <img src={{this.profile}} class=\"img\"/>\n        </div>\n        </label>\n    <!--<div class=\"change-img\">-->\n        \n           <!--<small class=\"changetext\">Change Photo</small>\n        </label>-->\n        <input type=\"file\" (change)=\"OnSelectedFile($event)\" class=\"fileuploadbtn\" id=\"file-input\"/>\n   <!-- </div>-->\n    </div>\n</div>\n<mat-card>\n    <table>\n        <tr><td>User Name </td><td>:</td><td><input [(ngModel)]=\"username\" class=\"input-field\" type=\"text\" class=\"emailfield\" readonly ></td></tr>\n        <mat-divider></mat-divider><br>\n        <tr><td>&nbsp;Password </td><td>:</td><td><input [(ngModel)]=\"password\" (click)=\"changeIcon()\" #pass class=\"input-field\" type=\"text\" [type]=\"hide ? 'password' : 'text'\"></td>\n            <button mat-icon-button matSuffix class=\"matbutton\" (click)=\"hide = !hide\" [attr.aria-label]=\"'Hide password'\" [attr.aria-pressed]=\"hide\">\n                <mat-icon *ngIf=\"editicon\" (click)=\"changeIcon()\">edit</mat-icon>\n                <mat-icon *ngIf=\"passicon\">{{hide ? 'visibility_off' : 'visibility'}}</mat-icon>\n            </button>\n        </tr>\n        <!--{{pass.className}}-->\n        <mat-divider></mat-divider><br>\n        <tr><td>Full Name </td><td>:&nbsp;&nbsp;</td><td><input [(ngModel)]=\"fullname\" class=\"input-field\" type=\"text\" ></td><mat-icon matSuffix class=\"icon\">edit</mat-icon></tr>\n        <mat-divider></mat-divider><br>\n        <tr><td>&nbsp;&nbsp;&nbsp;&nbsp;Email</td><td>:&nbsp;&nbsp;</td><td><input [(ngModel)]=\"usermail\" class=\"input-field\" class=\"emailfield\" type=\"text\" readonly></td><td></td></tr>\n        <mat-divider></mat-divider><br>\n        <tr><td>&nbsp;&nbsp;&nbsp;Mobile</td><td>:&nbsp;&nbsp;</td><td><input [(ngModel)]=\"mobile\" class=\"input-field\" class=\"emailfield\" type=\"text\"></td></tr>\n    </table>\n</mat-card>\n<div class=\"buttons\">\n    <button mat-button mat-dialog-close>Cancel</button>\n    <button mat-button mat-dialog-close (click)=\"update()\">Save</button>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/forgot-password/forgot-password.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/forgot-password/forgot-password.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  fxLayoutAlign=\"center center\"\n  style=\"\n    background-image: url('../../../assets/images/bookstore-wallpaper1.jpg');\n  \"\n  fxFill\n>\n\n<div class=\"container\" fxLayoutAlign=\"space-evenly center\" >\n    <mat-card  fxLayout=\"column\" fxFlex.lt-md=\"80%\" fxFlex.gt-sm=\"65%\" ngClass.gt-lg=\"lg\" >\n        <!-- <mat-card-title class=\"title\">Forgot Password</mat-card-title><br/> -->\n        <mat-toolbar ngClass.gt-lg=\"lg\">Forgot Password</mat-toolbar>\n        <form class=\"forgotpassword-form\" fxLayout = \"column\" [formGroup]=\"forgotPasswordForm\" (ngSubmit)=\"onSubmit()\">\n            <mat-form-field appearance=\"outline\">\n                <mat-label>EmailId</mat-label>\n                <input matInput type=\"email\" [formControl]=\"emailId\" placeholder=\"email-id\" autocomplete=\"off\" >\n                <mat-icon matSuffix>email</mat-icon>\n                <mat-error *ngIf=\"emailId.hasError('email') && !emailId.hasError('required')\">\n                    Please enter a valid email address\n                  </mat-error>\n                  <mat-error *ngIf=\"emailId.hasError('required')\">\n                    Email is <strong>required</strong>\n                  </mat-error>\n            </mat-form-field>\n            <mat-card-actions fxLayoutAlign=\"center\">  \n                <button mat-raised-button mat-dialog-close [disabled]=\"forgotPasswordForm.invalid\" type=\"submit\">submit</button>\n            </mat-card-actions>\n        </form>\n    </mat-card>\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/get-all-sellers/get-all-sellers.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/get-all-sellers/get-all-sellers.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"seller\" fxLayout=\"column\">\n    <app-admin></app-admin>\n    <table\n        class=\"table table-bordered\"\n        style=\"font-size: 80%; margin-top: 2%; width: 100%\"\n        *ngIf=\"found\">\n        <tr>\n            <th>Seller Id</th>\n            <th>Name</th>\n            <th>User Name</th>\n            <th>Action</th>\n        </tr>\n\n        <tr *ngFor=\"let user of users; let i = index\">\n            <td style=\"text-align: center\">{{i+1}}</td>\n            <td>{{user.name}}</td>\n            <td>{{user.userName}}</td>\n            <td style=\"text-align: center\" class=\"contact\">\n                <a\n                    mat-button\n                    class=\"contactButton\"\n                    style=\"color: brown\"\n                    href=\"http://localhost:4200/admin-dashboard/booksForVerification\"\n                    (click)=\"onLink(user)\">Verify Books</a>\n            </td>\n        </tr>\n    </table>\n\n    <div *ngIf=\"!found\" fxLayoutAlign=\"space-around center\">\n        <span style=\"position: absolute; background-color: whitesmoke; font-size: x-large\">No Seller For Verification</span>\n        <img src=\"../../../assets/images/UserNotFound.jpeg\" style=\"width: 50%\">\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/get-books-for-verification/get-books-for-verification.component.html":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/get-books-for-verification/get-books-for-verification.component.html ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n    class=\"main-div\"\n    \n    fxLayoutGap=\"40px\"\n    fxLayout.lt-sm=\"column\"\n    fxLayout.sm=\"row wrap\"\n    fxLayoutAlign.sm=\"start center\"\n    fxLayout.md=\"row wrap\"\n    fxLayoutAlign.md=\"start center\"\n    fxLayoutAlign.lt-sm=\"center center\"\n    fxLayout.lg=\"row wrap\"\n    fxLayoutAlign.lg=\"start center\"\n    fxLayout=\"row\"\n    fxLayoutAlign=\"space-around center\">\n    <div *ngFor=\"let book of books\" fxLayout=\"row\">\n        <mat-card>\n            <div\n                class=\"bookImageDiv\"\n                fxLayoutAlign=\"center\"\n                *ngIf=\"book.imageURL=='string'\">\n                <img src=\"../../../assets/images/bookstore-wallpaper.jpg\"/>\n            </div>\n            <div\n                class=\"bookImageDiv\"\n                fxLayoutAlign=\"center\"\n                *ngIf=\"book.imageURL!='string'\">\n                <img src={{book.imageURL}}/>\n            </div>\n\n            <div class=\"bookInfoDiv\" fxLayout=\"column\">\n                <input\n                    class=\"input-title\"\n                    matInput\n                    type=\"text\"\n                    autocomplete=\"off\"\n                    [(ngModel)]=\"book.bookName\"/>\n                <div fxlayout=\"row\">\n                    <span class=\"input-author-span\">By\n                        {{book.authorName}}</span>\n                </div>\n                <div fxlayout=\"row\">\n                    <span class=\"input-price-span\">Rs.{{book.price}}</span>\n                </div>\n                <div fxlayout=\"row\">\n                    <span class=\"input-price-span\">Quantity:\n                        {{book.quantity}}</span>\n                </div>\n                <div fxLayout=\"row\" fxLayoutAlign=\"space-between\">\n                    <button\n                        mat-raised-button\n                        style=\"color: aliceblue\"\n                        fxLayoutAlign=\"center\"\n                        [disableRipple]=\"true\"\n                        (click)=\"onApprove(book)\"\n                        *ngIf=\"click[book.bookId]!=book.bookId\">\n                        APPROVE\n                    </button>\n                    <button\n                        mat-button\n                        disabled\n                        style=\"color: aliceblue; background-color: #3371b5;\"\n                        fxLayoutAlign=\"center\"\n                        [disableRipple]=\"true\"\n                        *ngIf=\"click[book.bookId]==book.bookId && verify[book.bookId]=='true'\">\n                        APPROVED\n                    </button>\n                    <button\n                        mat-button\n                        disabled\n                        style=\"color: aliceblue\"\n                        fxLayoutAlign=\"center\"\n                        [disableRipple]=\"true\"\n                        *ngIf=\"click[book.bookId]==book.bookId && verify[book.bookId]=='false'\">\n                        APPROVE\n                    </button>\n\n                    <button\n                        mat-raised-button\n                        style=\"color: aliceblue;\"\n                        fxLayoutAlign=\"center\"\n                        [disableRipple]=\"true\"\n                        (click)=\"onReject(book)\"\n                        *ngIf=\"click[book.bookId]!=book.bookId\">\n                        REJECT\n                    </button>\n                    <button\n                        mat-button\n                        disabled\n                        style=\"color: aliceblue;background-color: #198010;\"\n                        fxLayoutAlign=\"center\"\n                        [disableRipple]=\"true\"\n                        *ngIf=\"click[book.bookId]==book.bookId && verify[book.bookId]=='false'\">\n                        REJECTED\n                    </button>\n                    <button\n                        mat-button\n                        disabled\n                        style=\"color: aliceblue\"\n                        fxLayoutAlign=\"center\"\n                        [disableRipple]=\"true\"\n                        *ngIf=\"click[book.bookId]==book.bookId && verify[book.bookId]=='true'\">\n                        REJECT\n                    </button>\n                </div>\n            </div>\n        </mat-card>\n        <div class=\"book-details\">\n            <h6><b>Book Details</b></h6>\n            <span>{{book.description}}</span>\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/getallbooks/getallbooks.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/getallbooks/getallbooks.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"whole-div\">\n  <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n    <div id=\"items\">\n      Books\n      <span id=\"active\"> ({{ countResult }} items) </span>\n    </div>\n\n    <div id=\"items1\">\n      <mat-form-field appearance=\"standard\">\n        <mat-label>Sort By Relevance</mat-label>\n        <select\n          matNativeControl\n          required\n          [ngModel]=\"selectedOption\"\n          (ngModelChange)=\"onChange($event)\"\n        >\n          <option value=\"high\">high to low</option>\n          <option value=\"low\">low to high</option>\n          <option value=\"NewArrivals\">New Arrivals</option>\n        </select>\n      </mat-form-field>\n    </div>\n  </div>\n  <div\n    fxLayoutGap=\"40px\"\n    fxLayout.lt-sm=\"column\"\n    fxLayout.sm=\"row wrap\"\n    fxLayoutAlign.sm=\"start center\"\n    fxLayout.md=\"row wrap\"\n    fxLayoutAlign.md=\"start center\"\n    fxLayoutAlign.lt-sm=\"center center\"\n    fxLayout.lg=\"row wrap\"\n    fxLayoutAlign.lg=\"start center\"\n  >\n    <div style=\"margin: 0px;\" fxLayout=\"row\" *ngFor=\"let book of books\">\n      <mat-card>\n        <div class=\"bookImageDiv\" fxLayoutAlign=\"center\">\n          <img src=\"{{ book.imageURL }}\" />\n          <mat-card class=\"centered\" *ngIf=\"book.quantity === 0\"\n            ><p class=\"text\">OUT OF STOCK</p></mat-card\n          >\n        </div>\n        <div class=\"bookInfoDiv\" fxLayout=\"column\">\n          <mat-card-content>\n            <div class=\"a\">\n              <mat-card-title>{{ book.bookName }}</mat-card-title>\n              <mat-card-subtitle>By {{ book.authorName }}</mat-card-subtitle>\n            </div>\n            <div class=\"price\">Rs.{{ book.price }}</div>\n          </mat-card-content>\n          <div class=\"left\" fxLayout=\"row\" fxLayoutAlign=\"space-around center\">\n            <button\n              mat-raised-button\n              fxLayoutAlign=\"center\"\n              color=\"primary\"\n              style=\"outline: none;\"\n              *ngIf=\"book.quantity > 0 && !checkAddedToCart(book.bookId)\"\n              (click)=\"addToCart(book)\"\n            >\n              ADD TO CART\n            </button>\n            <button\n              mat-raised-button\n              fxLayoutAlign=\"center\"\n              *ngIf=\"checkAddedToCart(book.bookId)\"\n              style=\"\n                width: 100%;\n                padding: 0%;\n                height: 32px;\n                margin-left: 0%;\n                outline: none;\n                background-color: #3371b5;\n              \"\n              (click)=\"addToCart(book)\"\n            >\n              ADDED TO CART\n            </button>\n            <button\n              mat-stroked-button\n              fxLayoutAlign=\"center\"\n              style=\"outline: none;\"\n              *ngIf=\"book.quantity > 0 && !checkAddedToCart(book.bookId)\"\n              (click)=\"onAddBookToWishList(book.bookId)\"\n              (click)=\"openDialog(book)\"\n            >\n              WISHLIST\n            </button>\n            <button\n              mat-stroked-button\n              *ngIf=\"book.quantity === 0\"\n              style=\"\n                width: 100%;\n                padding: 0%;\n                height: 32px;\n                margin-left: 0%;\n                outline: none;\n              \"\n              (click)=\"onAddBookToWishList(book.bookId)\"\n              (click)=\"openDialog(book)\"\n            >\n              WISHLIST\n            </button>\n          </div>\n        </div>\n      </mat-card>\n      <div class=\"book-details\">\n        <h6><b>Book Details</b></h6>\n        {{ book.description }}\n      </div>\n    </div>\n  </div><br><br>\n  <app-pagination    [totalRecords]=\"23\" [recordsPerPage]=\"8\"  (page) = \"getServerData($event)\"></app-pagination>\n</div>\n<!-- <div class=\"paginator\">\n  <mat-paginator   #paginator [length] = \"15\"\n    [pageIndex]=\"pageIndex\"\n     [pageSize] = \"8\"\n     (page) = \"getServerData($event)\">\n  </mat-paginator>\n  </div> -->\n\n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/getallwish-list/getallwish-list.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/getallwish-list/getallwish-list.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<mat-toolbar>\n    <mat-icon>card_giftcard</mat-icon>\n    <span class=\"title-left\">wishlist</span><a href=\"dashboard\" class=\"title-right\" >Continue Shopping</a>\n  </mat-toolbar><br><br>\n  \n  \n   <div fxLayout=\"row\"  fxLayoutAlign=\"space-around center\" *ngFor=\"let book of books\">\n   <div class=\"bookImageDiv\" style=\"vertical-align:-150px\" > \n      <img  src={{book.imageURL}}>\n    </div> \n     <span class=\"right\">\n         <div class=\"name\">\n        {{book.bookName}}\n         </div>\n        <div class=\"author\">\n        By: {{book.authorName}}\n        </div>\n        <div class=\"info\">\n        About: {{book.description}}\n        </div>\n        <div class=\"price\">\n        Rs.{{book.price}}\n        </div>\n  \n        <div class=\"box\" style=\"color: rgb(240, 233, 233);\">\n         <button mat-raised-button  fxLayoutAlign=\"center\"\n         [disableRipple]=\"true\"\n         (click)=\"onDeleteWishList(book.bookId)\"  >Delete WishList</button><br>  <button mat-stroked-button   fxLayoutAlign=\"center\" (click)=\"addToCart(book)\">Add To cart</button>\n        </div>  \n        <div class=\"divider\">\n        <mat-divider></mat-divider>       \n        </div>\n  </span> \n      </div>\n      \n      \n  \n  \n  \n  \n  \n  \n    \n  \n    \n  "

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/login/login.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/login/login.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  \n    \n      <div fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n          <mat-card>\n        <mat-toolbar>\n          <span class=\"title-center\">{{ title }}</span>\n        </mat-toolbar>\n        <form [formGroup]=\"LoginForm\">\n        <mat-form-field appearance=\"outline\">\n          <mat-label>UserId</mat-label>\n          <input\n            type=\"text\"\n            formControlName=\"loginid\"\n            placeholder=\"username or mail or phone\" \n            rows=\"3\"\n            maxlength=\"300\"\n            matInput\n            autocomplete=\"off\"\n            style=\"background: none\"\n            [ngClass]=\"{ 'is-invalid': submitted && f.loginid.errors }\"\n          />\n          <mat-icon matSuffix>account_circle</mat-icon>\n          <mat-error *ngIf=\"LoginForm.get('loginid').hasError('required')\"\n            >*username is required</mat-error\n          >\n          <mat-error *ngIf=\"LoginForm.get('loginid').hasError('minlength')\"\n            >*provide minimum 4 characters</mat-error\n          >\n          <mat-error *ngIf=\"LoginForm.get('loginid').hasError('maxlength')\"\n            >provide less than 15 characters</mat-error\n          > </mat-form-field\n        ><br />\n\n        <mat-form-field appearance=\"outline\">\n          <mat-label>Password</mat-label>\n          <input\n            matInput\n            [type]=\"hide ? 'password' : 'text'\"\n            formControlName=\"password\"\n            placeholder=\"password\"\n            rows=\"3\"\n            maxlength=\"300\"\n            matInput\n            style=\"background: none\"\n            [ngClass]=\"{ 'is-invalid': submitted && f.password.errors }\"/>\n          <button\n            mat-icon-button\n            matSuffix\n            (click)=\"hide = !hide\"\n            [attr.aria-label]=\"'Hide password'\"\n            [attr.aria-pressed]=\"hide\">\n            <mat-icon matSuffix>{{\n              hide ? \"visibility_off\" : \"visibility\"}}</mat-icon>\n          </button>\n          <mat-error *ngIf=\"LoginForm.get('password').hasError('required')\">*password is required</mat-error>\n          <mat-error *ngIf=\"LoginForm.get('password').hasError('minlength')\">provide a strong password</mat-error>\n          <mat-error *ngIf=\"LoginForm.get('password').hasError('maxlength')\">provide password less than 12 characters</mat-error> \n          </mat-form-field>\n          <div class=\"right\">\n            <button mat-button disableRipple onclick=\"this.blur()\" style=\"outline:none;\" (click)=\"opendialogforforgotpassowrd()\">forgot password?</button>\n          </div>\n          <div>\n            <mat-radio-group formControlName=\"userroles\" #roleselected>\n              <mat-radio-button class=\"firstRadiobutton\" value=\"vendor\">Author</mat-radio-button>\n              <mat-radio-button value=\"customer\">Reader</mat-radio-button>\n              <mat-error *ngIf=\"LoginForm.get('userroles').hasError('required') && roleselected.touched\">*role is required</mat-error><br/>\n            </mat-radio-group>\n          </div>\n          <div class=\"left\">\n            <button mat-button  mat-dialog-close onclick=\"this.blur()\" style=\"outline: none;\" [routerLink]=\"['/register']\">Sign up</button>\n            <div *ngIf=\"popup; then navigate;else popupbtn\"></div>\n            <ng-template #navigate>\n              <button mat-raised-button class=\"loginbutton\" (click)=\"onSubmit()\" type=\"submit\">Login</button>\n            </ng-template>\n            <ng-template #popupbtn>\n              <button mat-raised-button mat-dialog-close class=\"loginbutton\" (click)=\"onSubmit()\" type=\"submit\">Login</button>\n            </ng-template>\n          </div>\n        </form>\n        </mat-card>\n         </div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/myorders/myorders.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/myorders/myorders.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n    <div>    \n        <mat-toolbar class=\"tool\" fxLayout=\"row\" fxLayoutAlign=\"space-around center\">\n            <a href=\"http://localhost:4200/dashboard\" style=\"color: white;\"><span><img src=\"../../../assets/images/education.svg\" />BookStore</span></a>\n                <span>My Orders</span>\n            <div>\n            <button\n                mat-icon-button\n                [matMenuTriggerFor]=\"signoutmenu\"\n                disableRipple\n                style=\"outline: none;\"\n                >\n                <img  mat-card-avatar [src]=\"profile\" alt=\"profile\" class=\"profile\" style=\"width: 80%;height: 85%;border-radius: 50%;\" />\n            </button>\n            <mat-menu\n                #signoutmenu=\"matMenu\"\n                (click)=\"$event.stopPropagation()\"\n                class=\"profilemenu\"\n                xPosition=\"after\"\n                yPosition=\"below\"\n            >\n            <div>\n                <img mat-card-avatar [src]=\"profile\" class=\"pic\" />\n                <div class=\"upload-img\">\n                  <label for=\"file-input\">\n                    <mat-icon class=\"icon\">camera_alt</mat-icon>\n                  </label>\n                  <input\n                    type=\"file\"\n                    (change)=\"OnSelectedFile($event)\"\n                    class=\"fileuploadbtn\"\n                    id=\"file-input\"\n                  />\n                </div>\n              </div>\n              <div class=\"usertext\">\n                <div class=\"mat-subheading-1\">{{ this.username }}</div>\n                <div class=\"mat-subheading-1\">{{ this.usermail }}</div>\n                <br />\n              </div>\n              <mat-divider></mat-divider><br />\n              <div class=\"editprofile\">\n                <button\n                  class=\"edit\"\n                  mat-raised-button\n                  class=\"editbutton\"\n                  (click)=\"openDialogztoedit()\"\n                  style=\"margin-bottom: 1%;\"\n                >\n                  Edit Profile\n                </button><br/>\n              </div>\n              <br />\n              <mat-divider></mat-divider>\n              <div class=\"logout\"><br>\n                <button id=\"logout\" mat-button (click)=\"Logout()\">Sign Out</button>\n              </div>\n            </mat-menu>\n    </div>\n        </mat-toolbar>    \n    </div>\n    <div class=\"table-responsive\">\n        <table>\n            <tr>\n                <th>S No.</th>\n                <th>Book Name</th>\n                <th>Quantity</th>\n                <th>Total Price</th>\n                <th>Vendor Name</th>\n                <th>Review</th>\n            </tr>\n              <tr *ngFor=\"let book of orderedbooks;index as i\">\n                <td>{{i+1}}</td>\n                <td>{{book.bookName}}</td>\n                <td>{{book.qunatity}}</td>\n                <td>{{book.totelPrice}}</td>\n                <td>{{book.venderName}}</td>\n                <div *ngIf=\"book.review==0;then ReviewText;else rating\"></div>\n                <ng-template #ReviewText>\n                  <td (click)=\"openDialog(book)\"><button style=\"border: none;background-color: inherit;outline: none;color: rgb(179, 59, 59);\">Review</button></td>\n                </ng-template>\n                <ng-template #rating>\n                  <td (click)=\"openDialog(book)\"><button style=\"border: none;background-color: inherit;outline: none;color: rgb(179, 59, 59);\">{{book.review}}</button></td>\n                </ng-template>\n              </tr>\n        </table>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/pagination/pagination.component.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/pagination/pagination.component.html ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav aria-label=\"page navigation example\">  \n    <ul class=\"pagination\">  \n      <li class=\"page-item\"  (click)=\"onClickPage(activePage-1)\"><a class=\"page-link\" href=\"javascript:void(0);\">Previous</a></li>  \n      <li class=\"page-item\" [ngClass]=\"{'active': activePage === item}\" *ngFor=\"let item of pages\" (click)=\"onClickPage(item)\"><a class=\"page-link\" href=\"javascript:void(0);\">{{item}}</a></li>  \n      <li class=\"page-item\" (click)=\"onClickPage(activePage + 1)\"><a class=\"page-link\" href=\"javascript:void(0);\">Next</a></li>  \n    </ul>  \n  </nav>  \n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/register/register.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/register/register.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<div\n  fxLayoutAlign=\"center center\"\n  class=\"container\"\n  style=\"\n    background-image: url('../../../assets/images/bookstore-wallpaper1.jpg');\n  \"\n  fxFill\n>-->\n<div fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n    <mat-card fxLayout=\"column\" fxLayoutAlign=\"space-around\">\n        <mat-toolbar class=\"container\" flexLayout=\"row\">\n            <mat-toolbar-row fxLayoutAlign=\"center\">Registration Form</mat-toolbar-row>\n        </mat-toolbar>\n        <mat-form-field appearance=\"outline\">\n            <mat-label>Name</mat-label>\n            <input matInput maxlength=\"25\" type=\"text\" [formControl]=\"name\" placeholder=\"Name\" autocomplete=\"off\" class=\"input\" />\n            <mat-icon matSuffix>account_circle</mat-icon>\n        </mat-form-field>\n        <div *ngIf=\"name.hasError && (name.invalid || name.touched)\">\n            <small class=\"text-danger\" *ngIf=\"name.hasError('required') && name.touched\">&nbsp;&nbsp;Name is Required</small>\n            <small class=\"text-danger\" *ngIf=\"name.hasError('minlength')\">Min 3 chars</small>\n            <small class=\"text-danger\" *ngIf=\"name.hasError('pattern')\">Only alphabet are allowed</small>\n        </div>\n\n        <mat-form-field appearance=\"outline\">\n            <mat-label>Email Id</mat-label>\n            <input matInput maxlength=\"35\" [formControl]=\"email\" placeholder=\"Email Id\" autocomplete=\"off\" class=\"input\" />\n            <mat-icon matSuffix>email</mat-icon>\n        </mat-form-field>\n        <div *ngIf=\"email.hasError &&(email.invalid || email.touched)\">\n            <small class=\"text-danger\" *ngIf=\"email.hasError('required') && email.touched\">mail is required</small>\n            <small class=\"text-danger\" *ngIf=\"email.hasError('pattern') && email.dirty && email.invalid\">enter valid mail</small>\n        </div>\n\n        <mat-form-field appearance=\"outline\">\n            <mat-label>User Name</mat-label>\n            <input matInput maxlength=\"14\" type=\"text\" #MyUserName (input)=\"MyUserName.value\" [formControl]=\"username\" autocomplete=\"off\" placeholder=\"User Name\" class=\"input\" />\n            <mat-icon matSuffix>face</mat-icon>\n        </mat-form-field>\n        <div *ngIf=\"username.hasError && (username.invalid && username.touched)\">\n            <small class=\"text-danger\" *ngIf=\"username.hasError('required') && username.touched\">User name is required</small>\n            <small class=\"text-danger\" *ngIf=\"username.hasError('minlength')\">Minimum 8 charecters</small>\n            <small class=\"text-danger\" *ngIf=\"username.hasError('pattern') && username.invalid\">User name must start with capital & 1 number,1 symbol</small>\n        </div>\n\n        <mat-form-field appearance=\"outline\">\n            <mat-label>Password</mat-label>\n            <input matInput maxlength=\"16\" [type]=\"passwordType\" placeholder=\"Password\" autocomplete=\"off\" [formControl]=\"password\"\n                class=\"input\" />\n            <mat-icon matSuffix *ngIf=\"(!show)\" (click)=\"onclick()\">\n                visibility_off</mat-icon>\n            <mat-icon matSuffix *ngIf=\"(show)\" (click)=\"onclick()\">\n                visibility_on</mat-icon>\n        </mat-form-field>\n        <div *ngIf=\"password.hasError && (password.invalid || password.touched)\">\n            <small class=\"text-danger\" *ngIf=\"password.hasError('required') && password.touched\">password is required</small>\n            <small class=\"text-danger\" *ngIf=\"password.hasError('minlength')\">Min 8 chars</small>\n            <small class=\"text-danger\" *ngIf=\"password.hasError('pattern') && password.invalid\">Must start with Capital and must contain 1 num,1 special symbol</small>\n        </div>\n\n        <mat-form-field appearance=\"outline\">\n            <mat-label>Mobile Number</mat-label>\n            <input matInput type=\"number\"  onkeydown=\"javascript: return event.keyCode === 8 ||\n            event.keyCode === 46 ? true : !isNaN(Number(event.key))\" onKeyPress=\"if(this.value.length==10) return false;\"  placeholder=\"Mobile Number\" autocomplete=\"off\" [formControl]=\"phone\" class=\"input\" />\n            <mat-icon matSuffix>phone_android</mat-icon>\n        </mat-form-field>\n        <div *ngIf=\"phone.hasError && (phone.invalid || phone.touched)\">\n            <small class=\"text-danger\" *ngIf=\"phone.hasError('required') && phone.touched\">Phone number is required</small>\n            <small class=\"text-danger\" *ngIf=\"phone.hasError('pattern')\">Enter valid mobile number</small>\n        </div>\n        <mat-radio-group aria-label=\"Select an option\" fxLayoutGap=\"10%\" [(ngModel)]=\"radioval\">\n            <mat-radio-button value=\"3\">Author</mat-radio-button>\n            <mat-radio-button value=\"2\">Reader</mat-radio-button>\n        </mat-radio-group>\n        <div fxFlexAlign=\"end\" fxLayoutGap=\"25px\">\n            <a><button mat-button mattooltip=\"Login\" style=\"color:rgb(114, 10, 10);\" (click)=\"onLogin()\">have an Account?</button></a>\n            <button mat-raised-button mattooltip=\"Register\" class=\"regbutton\" (click)=\"onRegister()\">Register</button>\n        </div>\n    </mat-card>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/rejection/rejection.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/rejection/rejection.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n    <mat-toolbar\n        style=\"background-color: brown; height: 80%\"\n        fxLayout=\"row\"\n        fxLayoutAlign=\"space-around center\">\n        <span style=\"color: aliceblue\">Description</span>\n    </mat-toolbar>\n    <div fxLayout=\"column\" fxLayoutAlign=\"space-around center\" style=\"margin-top: 5%\">\n        <mat-form-field appearance=\"outline\" fxFlexFill=\"fxFlexFill\">\n            <mat-label>Description</mat-label>\n            <textarea\n                matInput=\"description\"\n                [formControl]=\"description\"\n                required\n                name=\"description\"\n                style=\"background: none;color: black\"></textarea>\n                <mat-error *ngIf=\"description.invalid\">{{getErrorMessage()}}</mat-error>\n        </mat-form-field>\n        <div>\n            <button\n                mat-flat-button=\"mat-flat-button\"\n                mat-dialog-close=\"mat-dialog-close\"\n                color=\"warn\"\n                [disabled]=\"description.invalid\"\n                (click)=\"onSubmit()\">Submit</button>\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/reset-password/reset-password.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/reset-password/reset-password.component.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div\n  fxLayoutAlign=\"center center\"\n  class=\"container\"\n  style=\"\n    background-image: url('../../../assets/images/bookstore-wallpaper1.jpg');\n  \"\n  fxFill\n>\n  <mat-card\n    class=\"mat-card-main\"\n    fxLayout=\"column\"\n    fxFlex.xs=\"100%\"\n    fxFlex.gt-xs=\"80%\"\n    fxFlex.gt-md=\"40%\"\n    fxLayoutGap=\"10px\"\n  >\n    <mat-toolbar>\n      <span class=\"title-center\">{{ title }}</span></mat-toolbar\n    >\n    <form\n      fxLayout=\"column\"\n      [formGroup]=\"resetPasswordForm\"\n      (ngSubmit)=\"onConfirm()\"\n    >\n      <mat-form-field appearance=\"outline\">\n        <mat-label>password</mat-label>\n        <input\n          matInput\n          [type]=\"hide ? 'password' : 'text'\"\n          placeholder=\"password\"\n          formControlName=\"password\"\n        />\n        <mat-error\n          *ngIf=\"resetPasswordForm.get('password').hasError('required')\"\n          >password is required</mat-error\n        >\n        <mat-error *ngIf=\"resetPasswordForm.get('password').hasError('pattern')\"\n          >password must have 1 lowercase,1 uppercase,1 character and 8\n          length</mat-error\n        >\n        <mat-icon matSuffix (click)=\"hide = !hide\">{{\n          hide ? \"visibility_off\" : \"visibility\"\n        }}</mat-icon>\n      </mat-form-field>\n      <mat-form-field appearance=\"outline\">\n        <mat-label>confirmPassword</mat-label>\n        <input\n          matInput\n          [type]=\"hide1 ? 'password' : 'text'\"\n          [class.is-invalid]=\"resetPasswordForm.errors?.mismatch\"\n          placeholder=\"confirm-password\"\n          formControlName=\"confirmPassword\"\n        />\n        <mat-error\n          *ngIf=\"resetPasswordForm.get('confirmPassword').hasError('required')\"\n          >password is required</mat-error\n        >\n        <small\n          *ngIf=\"\n            resetPasswordForm.hasError('mismatch') &&\n            resetPasswordForm.get('confirmPassword').touched\n          \"\n          style=\"color: red;\"\n          >passwords mismatch</small\n        >\n        <mat-icon matSuffix (click)=\"hide1 = !hide1\">\n          {{ hide1 ? \"visibility_off\" : \"visibility\" }}</mat-icon\n        >\n      </mat-form-field>\n      <button\n        mat-raised-button\n        fxFlexAlign=\"center\"\n        [disabled]=\"!resetPasswordForm.valid\"\n        type=\"submit\"\n      >\n        submit\n      </button>\n    </form>\n  </mat-card>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/review/review.component.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/review/review.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n  <div class=\"main-div\" fxLayout=\"row\" fxLayoutAlign=\"space-evenly center\">\n    <button mat-button  color=\"primary\" style=\"background: none\" *ngIf=\"rating!=5\" (click)=\"onRating(5)\">\n      <mat-icon>insert_emoticon</mat-icon>\n    </button>\n    <button mat-mini-fab  color=\"primary\" *ngIf=\"rating==5\">\n      <mat-icon>insert_emoticon</mat-icon>\n    </button>\n\n    <button mat-button style=\"color:rgb(43, 142, 223)\" *ngIf=\"rating!=4\" (click)=\"onRating(4)\">\n      <mat-icon>sentiment_satisfied_alt</mat-icon>\n    </button>\n    <button mat-mini-fab style=\"background-color:rgb(43, 142, 223)\" *ngIf=\"rating==4\">\n      <mat-icon>sentiment_satisfied_alt</mat-icon>\n    </button>\n\n    <button mat-button style=\"color:rgb(172, 157, 236)\" *ngIf=\"rating!=3\" (click)=\"onRating(3)\">\n      <mat-icon>sentiment_satisfied</mat-icon>\n    </button>\n    <button mat-mini-fab style=\"background-color:rgb(172, 157, 236)\" *ngIf=\"rating==3\">\n      <mat-icon>sentiment_satisfied</mat-icon>\n    </button>\n\n    <button mat-button color=\"accent\" *ngIf=\"rating!=2\" (click)=\"onRating(2)\">\n      <mat-icon>sentiment_dissatisfied</mat-icon>\n    </button>\n    <button mat-mini-fab color=\"accent\" *ngIf=\"rating==2\">\n      <mat-icon>sentiment_dissatisfied</mat-icon>\n    </button>\n\n    <button mat-button color=\"warn\" *ngIf=\"rating!=1\" (click)=\"onRating(1)\">\n      <mat-icon>sentiment_very_dissatisfied</mat-icon>\n    </button>\n    <button mat-mini-fab color=\"warn\" *ngIf=\"rating==1\">\n      <mat-icon>sentiment_very_dissatisfied</mat-icon>\n    </button>\n  </div>\n\n<div fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n  <mat-form-field style=\"box-shadow: none;margin-top: 5%; width: 100%\">\n    <mat-label>Add Comment</mat-label>\n    <textarea matInput maxlength=\"200\" [(ngModel)]=\"review\" name=\"review\" placeholder=\"text\" style=\"overflow: hidden\"\n    cdkTextareaAutosize></textarea>\n  </mat-form-field>\n\n  <button mat-flat-button mat-dialog-close color=\"warn\" (click)=\"onSubmit()\">Submit</button>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/success-page/success-page.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/success-page/success-page.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<br><br>\n<div class=\"main-div\" fxLayout=\"column\" fxLayoutAlign=\"space-around center\">\n\n    <div class=\"successImageDiv\" fxLayoutAlign=\"center\">\n        <img src=\"../../../assets/images/SuccessPage.JPG\"/>\n    </div>\n\n<span>Hurray!!!your order is confirmed</span>\n<span>the order id is #{{orderId}} save the order id for</span>\n<span>further communication...</span>\n<div fxLayout=\"column\" fxLayoutAlign=\"center-center\">\n    <table\n        class=\"table table-bordered\"\n        style=\"font-size: 60%; text-align: center; margin-top: 4%\">\n        <thead>\n            <tr>\n                <th scope=\"col\">Email us</th>\n                <th scope=\"col\">Contact us</th>\n                <th scope=\"col\">Address</th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr>\n                <td>admin@bookstore.com</td>\n                <td>+919999999999</td>\n                <td>DLF, Hyderabad</td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n<div fxLayout=\"row\" fxLayoutAlign=\"space-around center\" style=\"margin-top: 2%\">\n    <div style=\"margin-left: -3%\">\n        <button\n            mat-raised-button\n            style=\"background-color: rgb(115, 115, 226); color: aliceblue\" [routerLink]=\"['/dashboard']\">Continue Shopping</button>\n    </div>\n    <div style=\"margin-left: 3%\">\n        <button\n            mat-raised-button\n            color=\"warn\"\n            style=\"width: 130%\"\n            (click)=\"openDialog()\">Add Review</button>\n    </div>\n</div>\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/update-book/update-book.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/update-book/update-book.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card fxLayout=\"column\" fxLayoutGap=\"2%\" ngClass.lt-lg=\"mat-card-lt-md\">\n  <mat-toolbar fxLayoutAlign=\"center center\"\n    ><span>Update Book Form </span>\n  </mat-toolbar>\n  <div>\n    <form\n      [formGroup]=\"updateBookForm\"\n      fxLayout=\"column\"\n      (ngSubmit)=\"onFormSubmit()\"\n    >\n      <mat-form-field appearance=\"outline\" class=\"priceInput\">\n        <mat-label>Amount</mat-label>\n        <input\n          required\n          matInput\n          type=\"number\"\n          class=\"example-right-align\"\n          min=\"0\"\n          autocomplete=\"off\"\n          formControlName=\"price\"\n          [(ngModel)]=\"data.price\"\n        />\n        <mat-error *ngIf=\"updateBookForm.get('price').hasError('min')\"\n          >Amount should not be less than zero</mat-error\n        >\n        <mat-error *ngIf=\"updateBookForm.get('price').hasError('required')\"\n          >book price is required</mat-error\n        >\n        <span matPrefix>₹&nbsp;</span>\n      </mat-form-field>\n      <mat-form-field appearance=\"outline\" class=\"quantityInput\">\n        <mat-label>Quantity</mat-label>\n        <input\n          matInput\n          required\n          type=\"number\"\n          min=\"1\"\n          autocomplete=\"off\"\n          formControlName=\"quantity\"\n          [(ngModel)]=\"data.quantity\"\n        />\n        <mat-error *ngIf=\"updateBookForm.get('quantity').hasError('min')\"\n          >Quantity should not be less than one</mat-error\n        >\n        <mat-error *ngIf=\"updateBookForm.get('quantity').hasError('required')\"\n          >book quantity is required</mat-error\n        >\n      </mat-form-field>\n      <div fxLayoutAlign=\"end\">\n        <button\n          mat-raised-button\n          type=\"submit\"\n          [disableRipple]=\"true\"\n          [disabled]=\"!updateBookForm.valid\"\n        >\n          submit\n        </button>\n      </div>\n    </form>\n  </div>\n</mat-card>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/vendor-dashboard/vendor-dashboard.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/vendor-dashboard/vendor-dashboard.component.html ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"width: 100%; height: 100%;\">\n  <mat-toolbar fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n    <div class=\"titleText\" fxLayoutGap=\"3%\">\n      <img src=\"../../../assets/images/education.svg\" />\n      <a\n        href=\"http://localhost:4200/vendor-dashboard/display-books\"\n        style=\"color: white;\"\n        >BookStore</a\n      >\n    </div>\n    <mat-card\n      class=\"search-mat-card\"\n      fxLayout=\"row\"\n      fxLayoutAlign=\"space-around center\"\n    >\n      <button mat-icon-button [disableRipple]=\"true\" matTooltip=\"search\">\n        <mat-icon class=\"searchIcon\">search</mat-icon>\n      </button>\n      <input\n        (input)=\"onKey($event)\"\n        class=\"searchInput\"\n        type=\"text\"\n        placeholder=\"Search...\"\n      />\n    </mat-card>\n    <span class=\"spanClass\"></span>\n    <button\n      mat-icon-button\n      matTooltip=\"Account\"\n      [disableRipple]=\"true\"\n      [matMenuTriggerFor]=\"profileMenu\"\n    >\n      <img\n        *ngIf=\"!isProfileAvailable\"\n        mat-card-avatar\n        src=\"../../../assets/images/user.png\"\n        class=\"profile\"\n      />\n      <img\n        *ngIf=\"isProfileAvailable\"\n        mat-card-avatar\n        src=\"{{ this.profile }}\"\n        class=\"profile\"\n      />\n    </button>\n    <mat-menu #profileMenu=\"matMenu\" xPosition=\"before\">\n      <div fxLayoutAlign=\"center\" style=\"padding: 2%;\">\n        <img\n          *ngIf=\"!isProfileAvailable\"\n          mat-card-avatar\n          src=\"../../../assets/images/user.png\"\n          class=\"profile\"\n        />\n        <img\n          *ngIf=\"isProfileAvailable\"\n          mat-card-avatar\n          src=\"{{ this.profile }}\"\n          class=\"profile\"\n        />\n      </div>\n      <div class=\"usertext\" fxLayout=\"column\" fxLayoutAlign=\"center\">\n        <span fxLayoutAlign=\"center\">{{ username }}</span>\n        <span fxLayoutAlign=\"center\" style=\"padding: 2%;\">{{ usermail }}</span>\n      </div>\n      <div fxLayout=\"column\" fxLayoutGap=\"4%\">\n        <mat-divider></mat-divider>\n        <div fxLayoutAlign=\"center\">\n          <button\n            style=\"color: black;\"\n            class=\"edit\"\n            mat-button\n            [disableRipple]=\"true\"\n            class=\"editbutton\"\n            (click)=\"openDialogztoedit()\"\n          >\n            Edit Profile\n          </button>\n        </div>\n        <mat-divider></mat-divider>\n        <div class=\"logout\" fxLayoutAlign=\"center\">\n          <button\n            mat-button\n            [disableRipple]=\"true\"\n            id=\"logout\"\n            style=\"color: black;\"\n            (click)=\"Logout()\"\n          >\n            Sign Out\n          </button>\n        </div>\n      </div>\n    </mat-menu>\n  </mat-toolbar>\n  <!-- <mat-card\n    fxLayout=\"column\"\n    fxLayoutAlign=\"center center\"\n    fxLayoutGap=\"1%\"\n    ngClass.lt-md=\"mainContainer-lt-md\n      \"\n    ngClass.gt-sm=\"mainContainer-lg\"\n  >\n    <span class=\"mainSellingSpan\">Start Selling Books-Online</span>\n    <span class=\"subSellingSpan\">Sell On BookStore</span>\n\n    <button\n      mat-raised-button\n      class=\"addBookButton\"\n      fxLayoutAlign=\"center\"\n      [disableRipple]=\"true\"\n      (click)=\"openBookForm()\"\n    >\n      <span class=\"bookText\">Add Book</span>\n    </button>\n  </mat-card> -->\n\n  <router-outlet></router-outlet>\n  <br /><br />\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/verication-success-page/verication-success-page.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/verication-success-page/verication-success-page.component.html ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div fxLayout=\"column\" class=\"container\">\n    <div class=\"successImg\">\n        <div fxLayoutAlign=\"center center\" fxLayout=\"column\">\n            <span class=\"mat-title\">Online Bookstore Application</span>\n            <img src=\"../../../assets/images/tick.png\" style=\"width: 30%;height: 40%;\"><br>\n        </div>\n    </div>\n    <div class=\"successMsg\">\n        <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\n            <span class=\"mat-headline\" style=\"color: green;\">Congratulations! Your Verification Successfully Done!</span>\n            <button mat-raised-button style=\"background-color: rgb(179, 59, 59);color:white;\" (click)=\"onclick()\">Continue.</button>\n        </div>\n    </div>\n\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/verification/verification.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/verification/verification.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div fxLayoutAlign=\"center center\" class=\"container\" >\n    <mat-card  style=\"background:white;\" fxLayout=\"column\">\n        <mat-card-title fxFlexAlign=\"centre\">Book Store Account verification</mat-card-title><br>\n        <mat-card-content>\n            <mat-card-actions fxFlexAlign=\"centre\" >\n                <button mat-raised-button  type=\"submit\" (click)=\"onVerify()\" >click here to verify</button>\n            </mat-card-actions>\n        </mat-card-content>\n    </mat-card>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/view-wishlist/view-wishlist.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/view-wishlist/view-wishlist.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-toolbar>\n  <span class=\"title-left\">added To list</span>\n</mat-toolbar>\n<h3 mat-dialog-title>book added to   <span class=\"span\">WishList</span></h3><br>\n\n<div fxLayout=\"row\" fxLayoutAlign=\"space-around center\">\n<div class=\"bookImageDiv\" style=\"vertical-align:-150px\" > \n   <img  src={{data.bookImage}}>\n   </div> \n  <span class=\"right\">\n      <div class=\"name\">\n     {{data.bookname}}\n      </div>\n     <div class=\"author\">\n     By: {{data.bookauthor}}\n     </div>\n     <div class=\"info\">\n     About: {{data.bookinfo}}\n     </div>\n     <div class=\"price\">\n     Rs.{{data.bookprice}}\n     </div>\n     </span>\n</div>\n\n<mat-divider></mat-divider><br><br>\n\n<div class=\"box\" style=\"color: rgb(240, 233, 233);\">\n  <div class=\"left\"   fxLayout=\"row\" fxLayoutAlign=\"space-around center\" >\n  <button mat-raised-button    [mat-dialog-close] [routerLink]=\"['viewallWishList']\" >View WishList</button>   <button mat-stroked-button   [mat-dialog-close]  [routerLink]=\"['dashboard']\">Continue Shopping</button>\n</div>  \n</div>\n\n\n\n\n             \n"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule, routingComponents */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routingComponents", function() { return routingComponents; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_register_register_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/register/register.component */ "./src/app/components/register/register.component.ts");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _components_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/forgot-password/forgot-password.component */ "./src/app/components/forgot-password/forgot-password.component.ts");
/* harmony import */ var _components_verification_verification_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/verification/verification.component */ "./src/app/components/verification/verification.component.ts");
/* harmony import */ var _components_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/reset-password/reset-password.component */ "./src/app/components/reset-password/reset-password.component.ts");
/* harmony import */ var _components_admin_admin_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/admin/admin.component */ "./src/app/components/admin/admin.component.ts");
/* harmony import */ var _components_vendor_dashboard_vendor_dashboard_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/vendor-dashboard/vendor-dashboard.component */ "./src/app/components/vendor-dashboard/vendor-dashboard.component.ts");
/* harmony import */ var _components_add_book_add_book_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/add-book/add-book.component */ "./src/app/components/add-book/add-book.component.ts");
/* harmony import */ var _components_display_books_display_books_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/display-books/display-books.component */ "./src/app/components/display-books/display-books.component.ts");
/* harmony import */ var _components_update_book_update_book_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/update-book/update-book.component */ "./src/app/components/update-book/update-book.component.ts");
/* harmony import */ var _components_get_all_sellers_get_all_sellers_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/get-all-sellers/get-all-sellers.component */ "./src/app/components/get-all-sellers/get-all-sellers.component.ts");
/* harmony import */ var _components_get_books_for_verification_get_books_for_verification_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/get-books-for-verification/get-books-for-verification.component */ "./src/app/components/get-books-for-verification/get-books-for-verification.component.ts");
/* harmony import */ var _components_admin_login_admin_login_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/admin-login/admin-login.component */ "./src/app/components/admin-login/admin-login.component.ts");
/* harmony import */ var _components_cart_cart_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components/cart/cart.component */ "./src/app/components/cart/cart.component.ts");
/* harmony import */ var _components_success_page_success_page_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./components/success-page/success-page.component */ "./src/app/components/success-page/success-page.component.ts");
/* harmony import */ var _components_getallbooks_getallbooks_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/getallbooks/getallbooks.component */ "./src/app/components/getallbooks/getallbooks.component.ts");
/* harmony import */ var _components_view_wishlist_view_wishlist_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components/view-wishlist/view-wishlist.component */ "./src/app/components/view-wishlist/view-wishlist.component.ts");
/* harmony import */ var _components_myorders_myorders_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components/myorders/myorders.component */ "./src/app/components/myorders/myorders.component.ts");
/* harmony import */ var _components_getallwish_list_getallwish_list_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components/getallwish-list/getallwish-list.component */ "./src/app/components/getallwish-list/getallwish-list.component.ts");
/* harmony import */ var _components_verication_success_page_verication_success_page_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./components/verication-success-page/verication-success-page.component */ "./src/app/components/verication-success-page/verication-success-page.component.ts");
























const routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'register', component: _components_register_register_component__WEBPACK_IMPORTED_MODULE_3__["RegisterComponent"] },
    { path: 'login', component: _components_login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"] },
    { path: 'forgotpassword', component: _components_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_6__["ForgotPasswordComponent"] },
    { path: 'verification/:token', component: _components_verification_verification_component__WEBPACK_IMPORTED_MODULE_7__["VerificationComponent"] },
    { path: 'resetpassword/:token', component: _components_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_8__["ResetPasswordComponent"] },
    { path: 'verificationSuccess/:token', component: _components_verication_success_page_verication_success_page_component__WEBPACK_IMPORTED_MODULE_23__["VericationSuccessPageComponent"] },
    { path: 'admin-dashboard/sellers', component: _components_get_all_sellers_get_all_sellers_component__WEBPACK_IMPORTED_MODULE_14__["GetAllSellersComponent"] },
    { path: 'successPage', component: _components_success_page_success_page_component__WEBPACK_IMPORTED_MODULE_18__["SuccessPageComponent"] },
    { path: 'viewWishList', component: _components_view_wishlist_view_wishlist_component__WEBPACK_IMPORTED_MODULE_20__["ViewWishlistComponent"] },
    { path: 'myorders', component: _components_myorders_myorders_component__WEBPACK_IMPORTED_MODULE_21__["MyordersComponent"] },
    { path: 'viewallWishList', component: _components_getallwish_list_getallwish_list_component__WEBPACK_IMPORTED_MODULE_22__["GetallwishListComponent"] },
    {
        path: 'getallbooks',
        component: _components_getallbooks_getallbooks_component__WEBPACK_IMPORTED_MODULE_19__["GetallbooksComponent"],
    },
    // {
    //   path: 'admin-dashboard/booksForVerification',
    //   component: GetBooksForVerificationComponent,
    // },
    { path: 'addbook', component: _components_add_book_add_book_component__WEBPACK_IMPORTED_MODULE_11__["AddBookComponent"] },
    { path: 'updateBook', component: _components_update_book_update_book_component__WEBPACK_IMPORTED_MODULE_13__["UpdateBookComponent"] },
    { path: 'admin-login', component: _components_admin_login_admin_login_component__WEBPACK_IMPORTED_MODULE_16__["AdminLoginComponent"] },
    { path: 'successPage', component: _components_success_page_success_page_component__WEBPACK_IMPORTED_MODULE_18__["SuccessPageComponent"] },
    {
        path: 'dashboard',
        component: _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__["DashboardComponent"],
        children: [
            { path: '', redirectTo: 'getallbooks', pathMatch: 'full' },
            {
                path: 'getallbooks',
                component: _components_getallbooks_getallbooks_component__WEBPACK_IMPORTED_MODULE_19__["GetallbooksComponent"],
            },
            { path: 'cart', component: _components_cart_cart_component__WEBPACK_IMPORTED_MODULE_17__["CartComponent"] },
            { path: 'successPage', component: _components_success_page_success_page_component__WEBPACK_IMPORTED_MODULE_18__["SuccessPageComponent"] },
        ],
    },
    {
        path: 'admin-dashboard',
        component: _components_admin_admin_component__WEBPACK_IMPORTED_MODULE_9__["AdminComponent"],
        children: [
            { path: '', redirectTo: 'sellers', pathMatch: 'full' },
            { path: 'sellers', component: _components_get_all_sellers_get_all_sellers_component__WEBPACK_IMPORTED_MODULE_14__["GetAllSellersComponent"] },
            {
                path: 'booksForVerification',
                component: _components_get_books_for_verification_get_books_for_verification_component__WEBPACK_IMPORTED_MODULE_15__["GetBooksForVerificationComponent"],
            },
        ],
    },
    {
        path: 'vendor-dashboard',
        component: _components_vendor_dashboard_vendor_dashboard_component__WEBPACK_IMPORTED_MODULE_10__["VendorDashboardComponent"],
        children: [
            { path: '', redirectTo: 'display-books', pathMatch: 'full' },
            {
                path: 'display-books',
                component: _components_display_books_display_books_component__WEBPACK_IMPORTED_MODULE_12__["DisplayBooksComponent"],
            },
        ],
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { onSameUrlNavigation: 'reload' })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AppRoutingModule);

const routingComponents = [
    _components_register_register_component__WEBPACK_IMPORTED_MODULE_3__["RegisterComponent"],
    _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__["DashboardComponent"],
    _components_login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"],
    _components_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_6__["ForgotPasswordComponent"],
    _components_verification_verification_component__WEBPACK_IMPORTED_MODULE_7__["VerificationComponent"],
    _components_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_8__["ResetPasswordComponent"],
    _components_admin_admin_component__WEBPACK_IMPORTED_MODULE_9__["AdminComponent"],
    _components_cart_cart_component__WEBPACK_IMPORTED_MODULE_17__["CartComponent"],
    _components_get_all_sellers_get_all_sellers_component__WEBPACK_IMPORTED_MODULE_14__["GetAllSellersComponent"],
];


/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AppComponent = class AppComponent {
    constructor() {
        this.title = 'bookStoreApp';
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
        styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");
/* harmony import */ var _components_register_register_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/register/register.component */ "./src/app/components/register/register.component.ts");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/esm2015/toolbar.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/esm2015/card.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/esm2015/form-field.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm2015/input.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/radio */ "./node_modules/@angular/material/esm2015/radio.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm2015/flex-layout.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm2015/table.js");
/* harmony import */ var _angular_material_badge__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/badge */ "./node_modules/@angular/material/esm2015/badge.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _components_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/forgot-password/forgot-password.component */ "./src/app/components/forgot-password/forgot-password.component.ts");
/* harmony import */ var _components_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components/reset-password/reset-password.component */ "./src/app/components/reset-password/reset-password.component.ts");
/* harmony import */ var _components_verification_verification_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components/verification/verification.component */ "./src/app/components/verification/verification.component.ts");
/* harmony import */ var src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/services/encr-decr.service */ "./src/services/encr-decr.service.ts");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/esm2015/checkbox.js");
/* harmony import */ var _components_admin_admin_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./components/admin/admin.component */ "./src/app/components/admin/admin.component.ts");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");
/* harmony import */ var src_services_http_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! src/services/http.service */ "./src/services/http.service.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm2015/dialog.js");
/* harmony import */ var _components_login_login_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./components/login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _components_vendor_dashboard_vendor_dashboard_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./components/vendor-dashboard/vendor-dashboard.component */ "./src/app/components/vendor-dashboard/vendor-dashboard.component.ts");
/* harmony import */ var _components_add_book_add_book_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./components/add-book/add-book.component */ "./src/app/components/add-book/add-book.component.ts");
/* harmony import */ var _components_display_books_display_books_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./components/display-books/display-books.component */ "./src/app/components/display-books/display-books.component.ts");
/* harmony import */ var _components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./components/edit-profile/edit-profile.component */ "./src/app/components/edit-profile/edit-profile.component.ts");
/* harmony import */ var src_services_vendor_service__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! src/services/vendor.service */ "./src/services/vendor.service.ts");
/* harmony import */ var _components_get_all_sellers_get_all_sellers_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./components/get-all-sellers/get-all-sellers.component */ "./src/app/components/get-all-sellers/get-all-sellers.component.ts");
/* harmony import */ var _components_get_books_for_verification_get_books_for_verification_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./components/get-books-for-verification/get-books-for-verification.component */ "./src/app/components/get-books-for-verification/get-books-for-verification.component.ts");
/* harmony import */ var _components_getallbooks_getallbooks_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./components/getallbooks/getallbooks.component */ "./src/app/components/getallbooks/getallbooks.component.ts");
/* harmony import */ var _components_update_book_update_book_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./components/update-book/update-book.component */ "./src/app/components/update-book/update-book.component.ts");
/* harmony import */ var _components_admin_login_admin_login_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./components/admin-login/admin-login.component */ "./src/app/components/admin-login/admin-login.component.ts");
/* harmony import */ var _components_cart_cart_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./components/cart/cart.component */ "./src/app/components/cart/cart.component.ts");
/* harmony import */ var _components_review_review_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./components/review/review.component */ "./src/app/components/review/review.component.ts");
/* harmony import */ var _components_success_page_success_page_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./components/success-page/success-page.component */ "./src/app/components/success-page/success-page.component.ts");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm2015/table.js");
/* harmony import */ var src_services_review_service__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! src/services/review.service */ "./src/services/review.service.ts");
/* harmony import */ var _components_view_wishlist_view_wishlist_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./components/view-wishlist/view-wishlist.component */ "./src/app/components/view-wishlist/view-wishlist.component.ts");
/* harmony import */ var _components_myorders_myorders_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./components/myorders/myorders.component */ "./src/app/components/myorders/myorders.component.ts");
/* harmony import */ var _components_book_review_book_review_component__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./components/book-review/book-review.component */ "./src/app/components/book-review/book-review.component.ts");
/* harmony import */ var _components_getallwish_list_getallwish_list_component__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./components/getallwish-list/getallwish-list.component */ "./src/app/components/getallwish-list/getallwish-list.component.ts");
/* harmony import */ var _components_verication_success_page_verication_success_page_component__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./components/verication-success-page/verication-success-page.component */ "./src/app/components/verication-success-page/verication-success-page.component.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm2015/ngx-spinner.js");
/* harmony import */ var _components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./components/pagination/pagination.component */ "./src/app/components/pagination/pagination.component.ts");
/* harmony import */ var _components_rejection_rejection_component__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./components/rejection/rejection.component */ "./src/app/components/rejection/rejection.component.ts");






















































let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
            _components_register_register_component__WEBPACK_IMPORTED_MODULE_6__["RegisterComponent"],
            _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_25__["DashboardComponent"],
            _components_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_19__["ForgotPasswordComponent"],
            _components_login_login_component__WEBPACK_IMPORTED_MODULE_28__["LoginComponent"],
            _components_reset_password_reset_password_component__WEBPACK_IMPORTED_MODULE_20__["ResetPasswordComponent"],
            _components_verification_verification_component__WEBPACK_IMPORTED_MODULE_21__["VerificationComponent"],
            _components_admin_admin_component__WEBPACK_IMPORTED_MODULE_24__["AdminComponent"],
            _components_vendor_dashboard_vendor_dashboard_component__WEBPACK_IMPORTED_MODULE_29__["VendorDashboardComponent"],
            _components_add_book_add_book_component__WEBPACK_IMPORTED_MODULE_30__["AddBookComponent"],
            _components_display_books_display_books_component__WEBPACK_IMPORTED_MODULE_31__["DisplayBooksComponent"],
            _components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_32__["EditProfileComponent"],
            _components_get_all_sellers_get_all_sellers_component__WEBPACK_IMPORTED_MODULE_34__["GetAllSellersComponent"],
            _components_get_books_for_verification_get_books_for_verification_component__WEBPACK_IMPORTED_MODULE_35__["GetBooksForVerificationComponent"],
            _components_getallbooks_getallbooks_component__WEBPACK_IMPORTED_MODULE_36__["GetallbooksComponent"],
            _components_update_book_update_book_component__WEBPACK_IMPORTED_MODULE_37__["UpdateBookComponent"],
            _components_admin_login_admin_login_component__WEBPACK_IMPORTED_MODULE_38__["AdminLoginComponent"],
            _components_cart_cart_component__WEBPACK_IMPORTED_MODULE_39__["CartComponent"],
            _components_review_review_component__WEBPACK_IMPORTED_MODULE_40__["ReviewComponent"],
            _components_success_page_success_page_component__WEBPACK_IMPORTED_MODULE_41__["SuccessPageComponent"],
            _components_view_wishlist_view_wishlist_component__WEBPACK_IMPORTED_MODULE_44__["ViewWishlistComponent"],
            _components_myorders_myorders_component__WEBPACK_IMPORTED_MODULE_45__["MyordersComponent"],
            _components_book_review_book_review_component__WEBPACK_IMPORTED_MODULE_46__["BookReviewComponent"],
            _components_getallwish_list_getallwish_list_component__WEBPACK_IMPORTED_MODULE_47__["GetallwishListComponent"],
            _components_verication_success_page_verication_success_page_component__WEBPACK_IMPORTED_MODULE_48__["VericationSuccessPageComponent"],
            _components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_50__["PaginationComponent"],
            _components_rejection_rejection_component__WEBPACK_IMPORTED_MODULE_51__["RejectionComponent"],
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__["BrowserAnimationsModule"],
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormFieldModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_10__["MatInputModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ReactiveFormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_17__["HttpClientModule"],
            _angular_material_card__WEBPACK_IMPORTED_MODULE_8__["MatCardModule"],
            _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_7__["MatToolbarModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatIconModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatButtonModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatTooltipModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatMenuModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatExpansionModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatSidenavModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatListModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatSnackBarModule"],
            _angular_material_radio__WEBPACK_IMPORTED_MODULE_12__["MatRadioModule"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_27__["MatDialogModule"],
            _angular_flex_layout__WEBPACK_IMPORTED_MODULE_13__["FlexLayoutModule"],
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_23__["MatCheckboxModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatProgressSpinnerModule"],
            _angular_material_table__WEBPACK_IMPORTED_MODULE_14__["MatTableModule"],
            _angular_material_badge__WEBPACK_IMPORTED_MODULE_15__["MatBadgeModule"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_49__["NgxSpinnerModule"],
            _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatPaginatorModule"]
        ],
        entryComponents: [
            _components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_32__["EditProfileComponent"],
            _components_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_19__["ForgotPasswordComponent"],
            _components_review_review_component__WEBPACK_IMPORTED_MODULE_40__["ReviewComponent"],
            _components_book_review_book_review_component__WEBPACK_IMPORTED_MODULE_46__["BookReviewComponent"],
            _components_rejection_rejection_component__WEBPACK_IMPORTED_MODULE_51__["RejectionComponent"]
        ],
        providers: [
            src_services_user_service__WEBPACK_IMPORTED_MODULE_18__["UserService"],
            src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_22__["EncrDecrService"],
            src_services_http_service__WEBPACK_IMPORTED_MODULE_26__["HttpService"],
            src_services_vendor_service__WEBPACK_IMPORTED_MODULE_33__["VendorService"],
            _angular_cdk_table__WEBPACK_IMPORTED_MODULE_42__["CdkColumnDef"],
            src_services_review_service__WEBPACK_IMPORTED_MODULE_43__["ReviewService"],
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]],
    })
], AppModule);



/***/ }),

/***/ "./src/app/components/add-book/add-book.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/components/add-book/add-book.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "mat-card {\n  width: 100%;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  overflow: auto;\n}\n\n.titleInput,\n.authorInput,\n.priceInput,\n.quantityInput {\n  width: 48%;\n}\n\nmat-toolbar {\n  background-color: brown;\n}\n\n::-webkit-input-placeholder {\n  font-size: 90%;\n}\n\n::-moz-placeholder {\n  font-size: 90%;\n}\n\n::-ms-input-placeholder {\n  font-size: 90%;\n}\n\n::placeholder {\n  font-size: 90%;\n}\n\n.mat-card-lt-md {\n  width: 100%;\n}\n\nbutton {\n  background-color: brown;\n  outline: none;\n}\n\nmat-error {\n  font-size: x-small;\n}\n\n.fileButton {\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9hZGQtYm9vay9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxhZGQtYm9va1xcYWRkLWJvb2suY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvYWRkLWJvb2svYWRkLWJvb2suY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0EsMkJBQUE7RUFBQSx3QkFBQTtFQUFBLG1CQUFBO0VBQ0EsY0FBQTtBQ0NGOztBRENBOzs7O0VBSUUsVUFBQTtBQ0VGOztBREFBO0VBQ0UsdUJBQUE7QUNHRjs7QUREQTtFQUNFLGNBQUE7QUNJRjs7QURMQTtFQUNFLGNBQUE7QUNJRjs7QURMQTtFQUNFLGNBQUE7QUNJRjs7QURMQTtFQUNFLGNBQUE7QUNJRjs7QURGQTtFQUNFLFdBQUE7QUNLRjs7QURIQTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtBQ01GOztBREpBO0VBQ0Usa0JBQUE7QUNPRjs7QURMQTtFQUVFLGFBQUE7QUNPRiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvYWRkLWJvb2svYWRkLWJvb2suY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJtYXQtY2FyZCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IGZpdC1jb250ZW50O1xuICBvdmVyZmxvdzogYXV0bztcbn1cbi50aXRsZUlucHV0LFxuLmF1dGhvcklucHV0LFxuLnByaWNlSW5wdXQsXG4ucXVhbnRpdHlJbnB1dCB7XG4gIHdpZHRoOiA0OCU7XG59XG5tYXQtdG9vbGJhciB7XG4gIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xufVxuOjpwbGFjZWhvbGRlciB7XG4gIGZvbnQtc2l6ZTogOTAlO1xufVxuLm1hdC1jYXJkLWx0LW1kIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5idXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbiAgb3V0bGluZTogbm9uZTtcbn1cbm1hdC1lcnJvciB7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbn1cbi5maWxlQnV0dG9uIHtcbiAgLy8gd2lkdGg6IDUwJTtcbiAgb3V0bGluZTogbm9uZTtcbn1cbiIsIm1hdC1jYXJkIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogZml0LWNvbnRlbnQ7XG4gIG92ZXJmbG93OiBhdXRvO1xufVxuXG4udGl0bGVJbnB1dCxcbi5hdXRob3JJbnB1dCxcbi5wcmljZUlucHV0LFxuLnF1YW50aXR5SW5wdXQge1xuICB3aWR0aDogNDglO1xufVxuXG5tYXQtdG9vbGJhciB7XG4gIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xufVxuXG46OnBsYWNlaG9sZGVyIHtcbiAgZm9udC1zaXplOiA5MCU7XG59XG5cbi5tYXQtY2FyZC1sdC1tZCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG5idXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxubWF0LWVycm9yIHtcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xufVxuXG4uZmlsZUJ1dHRvbiB7XG4gIG91dGxpbmU6IG5vbmU7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/add-book/add-book.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/add-book/add-book.component.ts ***!
  \***********************************************************/
/*! exports provided: AddBookComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddBookComponent", function() { return AddBookComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var src_services_vendor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/vendor.service */ "./src/services/vendor.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");






let AddBookComponent = class AddBookComponent {
    constructor(vendorService, snackBar, messageService, dialogRef, data) {
        this.vendorService = vendorService;
        this.snackBar = snackBar;
        this.messageService = messageService;
        this.dialogRef = dialogRef;
        this.data = data;
        this.isProfile = 'false';
        this.book = {
            bookName: null,
            authorName: null,
            price: null,
            quantity: null,
            description: null,
            imageURL: null,
        };
        this.bookForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            bookName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            authorName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            price: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            quantity: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[0-9]*$')]),
            description: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            imageURL: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](this.bookImageUrl, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
        });
    }
    ngOnInit() { }
    onFormSubmit() {
        this.dialogRef.close();
        this.book.bookName = this.bookForm.value.bookName;
        this.book.authorName = this.bookForm.value.authorName;
        this.book.price = this.bookForm.value.price;
        this.book.quantity = this.bookForm.value.quantity;
        this.book.description = this.bookForm.value.description;
        this.book.imageURL = this.bookImageUrl;
        this.vendorService.addBook(this.book).subscribe((data) => {
            if (data.status === 201) {
                this.messageService.changeMessage(1);
                this.messageService.onBooksCount();
                this.snackBar.open(data.message, 'ok', {
                    duration: 2000,
                });
            }
        }, (error) => {
            this.snackBar.open(error.message, 'cancel', {
                duration: 2000,
            });
        });
    }
    onUploadBookImage(event) {
        if (event.target.files.length > 0) {
            this.file = event.target.files[0];
            const formData = new FormData();
            formData.append('file', this.file);
            this.file.inProgress = true;
            this.vendorService
                .uploadBookImage(formData, this.isProfile)
                .subscribe((data) => {
                if (data.status === 200) {
                    this.bookImageUrl = data.data;
                    console.log(data);
                    console.log(this.bookImageUrl);
                }
            });
        }
    }
};
AddBookComponent.ctorParameters = () => [
    { type: src_services_vendor_service__WEBPACK_IMPORTED_MODULE_3__["VendorService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_5__["MessageService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatDialogRef"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_material__WEBPACK_IMPORTED_MODULE_4__["MAT_DIALOG_DATA"],] }] }
];
AddBookComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-book',
        template: __webpack_require__(/*! raw-loader!./add-book.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/add-book/add-book.component.html"),
        styles: [__webpack_require__(/*! ./add-book.component.scss */ "./src/app/components/add-book/add-book.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_4__["MAT_DIALOG_DATA"]))
], AddBookComponent);



/***/ }),

/***/ "./src/app/components/admin-login/admin-login.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/components/admin-login/admin-login.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".my-card {\n  width: 300px;\n  outline: none;\n  border: none;\n  display: flex;\n  padding: 10px;\n  flex-wrap: wrap;\n  box-sizing: border-box;\n  justify-content: center;\n  box-shadow: 0 4px 8px 0 #b33b3b, 0 6px 20px 0 rgba(241, 37, 37, 0.19);\n  border-radius: 13px;\n}\n\n.mat-toolbar {\n  background-color: #b33b3b;\n}\n\n.title-center {\n  flex: 1 1 auto;\n  text-align: center;\n}\n\n.mat-form-field {\n  width: 100%;\n  padding-top: 5%;\n  color: black;\n}\n\n.mat-radio-button {\n  margin: 0 3px 0 3px;\n  padding: 12px;\n  margin-top: 0px;\n}\n\n.right {\n  margin-top: -9%;\n  margin-left: 49%;\n  color: #2da1c1;\n}\n\ninput[type=text] {\n  background-color: whitesmoke;\n}\n\n.a {\n  font-size: medium;\n  text-decoration: none;\n}\n\n.container-fluid {\n  margin-left: 35%;\n  padding: 0px;\n}\n\n.mat-raised-button {\n  margin-top: 10px;\n  background-color: #b33b3b;\n  color: aliceblue;\n  margin-left: 70px;\n}\n\n.mat-button {\n  color: #b33b3b;\n  margin-bottom: -50%;\n  border-radius: 30px;\n  height: 40px;\n}\n\n.mat-card {\n  margin-top: 20px;\n}\n\n.container {\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9hZG1pbi1sb2dpbi9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxhZG1pbi1sb2dpblxcYWRtaW4tbG9naW4uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvYWRtaW4tbG9naW4vYWRtaW4tbG9naW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFFQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EscUVBQUE7RUFDQSxtQkFBQTtBQ0FKOztBREVFO0VBQ0UseUJBQUE7QUNDSjs7QURDRTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQ0VKOztBRGtCRTtFQUNFLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQ2ZKOztBRG1CRTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUNoQko7O0FEa0JFO0VBQ0MsZUFBQTtFQUNELGdCQUFBO0VBQ0EsY0FBQTtBQ2ZGOztBRHFCRTtFQUNDLDRCQUFBO0FDbEJIOztBRHNCRTtFQUNFLGlCQUFBO0VBQ0EscUJBQUE7QUNuQko7O0FEc0JFO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0FDbkJKOztBRHNCRTtFQUNFLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FDbkJKOztBRHVCRTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ3BCSjs7QUQ4QkU7RUFDRSxnQkFBQTtBQzNCSjs7QUQ4QkU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDM0JKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9hZG1pbi1sb2dpbi9hZG1pbi1sb2dpbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5teS1jYXJkIHtcbiAgICB3aWR0aDogMzAwcHg7XG4gICAgb3V0bGluZTogbm9uZTtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgLy9tYXJnaW4tcmlnaHQ6IDIwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgIHJnYigxNzksIDU5LCA1OSksMCA2cHggMjBweCAwIHJnYmEoMjQxLCAzNywgMzcsIDAuMTkpO1xuICAgIGJvcmRlci1yYWRpdXM6IDEzcHg7XG4gIH1cbiAgLm1hdC10b29sYmFyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTc5LCA1OSwgNTkpO1xuICB9XG4gIC50aXRsZS1jZW50ZXIge1xuICAgIGZsZXg6IDEgMSBhdXRvO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICAvLyBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5NTlweCkge1xuICAvLyAgIC8qIENvbHVtbiBHYXAgKi9cbiAgLy8gICAubXktY2FyZCB7XG4gIC8vICAgICBtYXJnaW4tcmlnaHQ6IDUwcHg7XG4gIC8vICAgfVxuICAvLyB9XG4gIFxuICAvLyBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1OTlweCkge1xuICAvLyAgIC5teS1jYXJkIHtcbiAgLy8gICAgIGRpc3BsYXk6IGZsZXg7XG4gIC8vICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAvLyAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAvLyAgIH1cbiAgLy8gfVxuICBcbiAgLy8gIC5leGFtcGxlLWNvbnRhaW5lciAubWF0LWZvcm0tZmllbGQgKyAubWF0LWZvcm0tZmllbGQge1xuICAvLyAgICAgIG1hcmdpbi1sZWZ0OiA4cHg7XG4gIC8vICAgIH1cbiAgLm1hdC1mb3JtLWZpZWxkIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nLXRvcDogNSU7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIC8vIHBhZGRpbmc6IDAuNDM3NXJlbSAwO1xuICB9XG4gIFxuICAubWF0LXJhZGlvLWJ1dHRvbiB7XG4gICAgbWFyZ2luOiAwIDNweCAwIDNweDtcbiAgICBwYWRkaW5nOjEycHg7XG4gICAgbWFyZ2luLXRvcDowcHg7XG4gIH1cbiAgLnJpZ2h0IHtcbiAgIG1hcmdpbi10b3A6LTklO1xuICBtYXJnaW4tbGVmdDo0OSU7XG4gIGNvbG9yOiAjMmRhMWMxO1xuICB9XG4gIFxuICBcbiAgXG4gIFxuICBpbnB1dFt0eXBlPXRleHRdIHtcbiAgIGJhY2tncm91bmQtY29sb3I6d2hpdGVzbW9rZTtcbiAgfVxuICBcbiAgXG4gIC5he1xuICAgIGZvbnQtc2l6ZTogbWVkaXVtO1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgIH1cbiAgXG4gIC5jb250YWluZXItZmx1aWQge1xuICAgIG1hcmdpbi1sZWZ0OiAzNSU7XG4gICAgcGFkZGluZzogMHB4O1xuICB9XG4gIFxuICAubWF0LXJhaXNlZC1idXR0b24ge1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE3OSwgNTksIDU5KTtcbiAgICBjb2xvcjogYWxpY2VibHVlO1xuICAgIG1hcmdpbi1sZWZ0OiA3MHB4O1xuICAgIH1cbiAgXG4gIFxuICAubWF0LWJ1dHRvbntcbiAgICBjb2xvcjogIHJnYigxNzksIDU5LCA1OSk7XG4gICAgbWFyZ2luLWJvdHRvbTogLTUwJTtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAgIGhlaWdodDo0MHB4O1xuICB9XG4gIFxuICBcbiAgXG4gIFxuICBcbiAgXG4gIFxuICBcbiAgLm1hdC1jYXJkIHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICB9XG4gIFxuICAuY29udGFpbmVyIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgfSIsIi5teS1jYXJkIHtcbiAgd2lkdGg6IDMwMHB4O1xuICBvdXRsaW5lOiBub25lO1xuICBib3JkZXI6IG5vbmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwICNiMzNiM2IsIDAgNnB4IDIwcHggMCByZ2JhKDI0MSwgMzcsIDM3LCAwLjE5KTtcbiAgYm9yZGVyLXJhZGl1czogMTNweDtcbn1cblxuLm1hdC10b29sYmFyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2IzM2IzYjtcbn1cblxuLnRpdGxlLWNlbnRlciB7XG4gIGZsZXg6IDEgMSBhdXRvO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5tYXQtZm9ybS1maWVsZCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLXRvcDogNSU7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLm1hdC1yYWRpby1idXR0b24ge1xuICBtYXJnaW46IDAgM3B4IDAgM3B4O1xuICBwYWRkaW5nOiAxMnB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG5cbi5yaWdodCB7XG4gIG1hcmdpbi10b3A6IC05JTtcbiAgbWFyZ2luLWxlZnQ6IDQ5JTtcbiAgY29sb3I6ICMyZGExYzE7XG59XG5cbmlucHV0W3R5cGU9dGV4dF0ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xufVxuXG4uYSB7XG4gIGZvbnQtc2l6ZTogbWVkaXVtO1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbi5jb250YWluZXItZmx1aWQge1xuICBtYXJnaW4tbGVmdDogMzUlO1xuICBwYWRkaW5nOiAwcHg7XG59XG5cbi5tYXQtcmFpc2VkLWJ1dHRvbiB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNiMzNiM2I7XG4gIGNvbG9yOiBhbGljZWJsdWU7XG4gIG1hcmdpbi1sZWZ0OiA3MHB4O1xufVxuXG4ubWF0LWJ1dHRvbiB7XG4gIGNvbG9yOiAjYjMzYjNiO1xuICBtYXJnaW4tYm90dG9tOiAtNTAlO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5cbi5tYXQtY2FyZCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbi5jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/admin-login/admin-login.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/admin-login/admin-login.component.ts ***!
  \*****************************************************************/
/*! exports provided: AdminLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminLoginComponent", function() { return AdminLoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/services/encr-decr.service */ "./src/services/encr-decr.service.ts");







let AdminLoginComponent = class AdminLoginComponent {
    constructor(formBuilder, route, router, userService, snackBar, dialog, encrDecr) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.snackBar = snackBar;
        this.dialog = dialog;
        this.encrDecr = encrDecr;
        this.hide = true;
        this.loading = false;
        this.submitted = false;
        this.title = 'Login';
        this.error = '';
    }
    ngOnInit() {
        this.LoginForm = this.formBuilder.group({
            loginid: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(4),
                ],
            ],
            password: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(12),
                ],
            ],
            userroles: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
        });
        this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
    }
    get f() {
        return this.LoginForm.controls;
    }
    onSubmit() {
        this.submitted = true;
        this.role1 = 1;
        console.log('ROLE:', this.role1);
        const data = {
            loginId: this.LoginForm.get('loginid').value,
            password: this.encrDecr.set('123456$#@$^@1ERF', this.LoginForm.get('password').value),
            role: this.role1
        };
        this.loading = true;
        this.userService.login(data).subscribe((response) => {
            if (response.status === 200) {
                localStorage.setItem('token', response.token);
                if (this.role1 === 1) {
                    this.router.navigate(['admin-dashboard/sellers']);
                }
                this.logsuccess = true;
                this.snackBar.open(response.message, 'ok', { duration: 5000 });
            }
        }, (error) => {
            console.log('error', error.error.message);
            this.loading = false;
            this.snackBar.open(error.error.message, 'ok', { duration: 2000 });
        });
    }
};
AdminLoginComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatDialog"] },
    { type: src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_6__["EncrDecrService"] }
];
AdminLoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-admin-login',
        template: __webpack_require__(/*! raw-loader!./admin-login.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/admin-login/admin-login.component.html"),
        styles: [__webpack_require__(/*! ./admin-login.component.scss */ "./src/app/components/admin-login/admin-login.component.scss")]
    })
], AdminLoginComponent);



/***/ }),

/***/ "./src/app/components/admin/admin.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/components/admin/admin.component.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-div {\n  width: device-width;\n}\n\n.tool {\n  background-color: #b33b3b;\n  width: device-width;\n  height: 55px;\n  color: aliceblue;\n}\n\n.logo {\n  position: absolute;\n  color: aliceblue;\n  margin-top: 1.2%;\n  margin-left: 15%;\n}\n\n@media only screen and (max-width: 600px) {\n  .content {\n    font-size: 80%;\n    width: 20%;\n  }\n\n  mat-icon {\n    font-size: 120%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9hZG1pbi9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxhZG1pblxcYWRtaW4uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvYWRtaW4vYWRtaW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBQTtBQ0NKOztBREdBO0VBQ0kseUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0FKOztBREdBO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUNBSjs7QURHQTtFQUNFO0lBQ0UsY0FBQTtJQUNBLFVBQUE7RUNBRjs7RURFQTtJQUNFLGVBQUE7RUNDRjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9hZG1pbi9hZG1pbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluLWRpdntcbiAgICB3aWR0aDogZGV2aWNlLXdpZHRoO1xuICAgIC8vIHdpZHRoOjkyJTtcbiAgICAvLyBtYXJnaW4tbGVmdDogNCU7XG59XG4udG9vbHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTc5LCA1OSwgNTkpO1xuICAgIHdpZHRoOiBkZXZpY2Utd2lkdGg7XG4gICAgaGVpZ2h0OiA1NXB4O1xuICAgIGNvbG9yOiBhbGljZWJsdWU7XG4gICAgXG4gfVxuLmxvZ297XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGNvbG9yOmFsaWNlYmx1ZTtcbiAgICBtYXJnaW4tdG9wOiAxLjIlO1xuICAgIG1hcmdpbi1sZWZ0OiAxNSVcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2MDBweCkge1xuICAuY29udGVudHtcbiAgICBmb250LXNpemU6IDgwJTtcbiAgICB3aWR0aDogMjAlO1xuICB9XG4gIG1hdC1pY29ue1xuICAgIGZvbnQtc2l6ZTogMTIwJTtcbiAgfVxuICAvLyBzcGFue1xuICAvLyAgIGZvbnQtc2l6ZTogMTAwJTtcbiAgLy8gfVxuICBcbiAgICBcbiAgXG59XG4gICIsIi5tYWluLWRpdiB7XG4gIHdpZHRoOiBkZXZpY2Utd2lkdGg7XG59XG5cbi50b29sIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2IzM2IzYjtcbiAgd2lkdGg6IGRldmljZS13aWR0aDtcbiAgaGVpZ2h0OiA1NXB4O1xuICBjb2xvcjogYWxpY2VibHVlO1xufVxuXG4ubG9nbyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgbWFyZ2luLXRvcDogMS4yJTtcbiAgbWFyZ2luLWxlZnQ6IDE1JTtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2MDBweCkge1xuICAuY29udGVudCB7XG4gICAgZm9udC1zaXplOiA4MCU7XG4gICAgd2lkdGg6IDIwJTtcbiAgfVxuXG4gIG1hdC1pY29uIHtcbiAgICBmb250LXNpemU6IDEyMCU7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/admin/admin.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/components/admin/admin.component.ts ***!
  \*****************************************************/
/*! exports provided: AdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminComponent", function() { return AdminComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/admin.service */ "./src/services/admin.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");





let AdminComponent = class AdminComponent {
    constructor(service, router, messageService) {
        this.service = service;
        this.router = router;
        this.messageService = messageService;
    }
    ngOnInit() {
        this.messageService.adminBookMessage();
        this.messageService.adminSellerMessage();
    }
    onLogout() {
        this.service.logout().subscribe();
        localStorage.clear();
        this.router.navigate(['admin-login']);
    }
    navigateTo() {
        this.router.navigate(['/admin-dashboard']);
    }
};
AdminComponent.ctorParameters = () => [
    { type: src_services_admin_service__WEBPACK_IMPORTED_MODULE_2__["AdminService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_4__["MessageService"] }
];
AdminComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-admin',
        template: __webpack_require__(/*! raw-loader!./admin.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/admin/admin.component.html"),
        styles: [__webpack_require__(/*! ./admin.component.scss */ "./src/app/components/admin/admin.component.scss")]
    })
], AdminComponent);



/***/ }),

/***/ "./src/app/components/book-review/book-review.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/components/book-review/book-review.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "button {\n  outline: none;\n}\n\n@media screen and (max-width: 1000px) {\n  .main-div {\n    width: 250px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9ib29rLXJldmlldy9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxib29rLXJldmlld1xcYm9vay1yZXZpZXcuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvYm9vay1yZXZpZXcvYm9vay1yZXZpZXcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FDQ0o7O0FEQ0E7RUFDSTtJQUNFLFlBQUE7RUNFSjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9ib29rLXJldmlldy9ib29rLXJldmlldy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJ1dHRvbntcbiAgICBvdXRsaW5lOiBub25lO1xufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTAwMHB4KSB7XG4gICAgLm1haW4tZGl2e1xuICAgICAgd2lkdGg6IDI1MHB4O1xuICAgIH1cbn1cbiIsImJ1dHRvbiB7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEwMDBweCkge1xuICAubWFpbi1kaXYge1xuICAgIHdpZHRoOiAyNTBweDtcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/book-review/book-review.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/book-review/book-review.component.ts ***!
  \*****************************************************************/
/*! exports provided: BookReviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookReviewComponent", function() { return BookReviewComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_review_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/review.service */ "./src/services/review.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let BookReviewComponent = class BookReviewComponent {
    constructor(service, snackbar, router) {
        this.service = service;
        this.snackbar = snackbar;
        this.router = router;
    }
    ngOnInit() { }
    onRating(value) {
        this.rating = value;
    }
    onSubmit() {
        console.log(this.rating);
        console.log(this.review);
        console.log("Book Review");
        /*this.service.addReviewApp(this.review, this.rating, localStorage.getItem('token')).subscribe((data) => {
          this.rating = data.data.rating;
          this.review = data.data.review;
          if(result.staus==200)
          {
          }
        });*/
        this.service.addReview(this.review, this.rating).subscribe((result) => {
            console.log("successfully added rating", result);
            if (result.status == 200) {
                localStorage.setItem('bookRating', this.rating);
                this.snackbar.open("Thank you for your valueble feedback", "ok", { duration: 5000 });
            }
        });
    }
};
BookReviewComponent.ctorParameters = () => [
    { type: src_services_review_service__WEBPACK_IMPORTED_MODULE_2__["ReviewService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
BookReviewComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-book-review',
        template: __webpack_require__(/*! raw-loader!./book-review.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/book-review/book-review.component.html"),
        styles: [__webpack_require__(/*! ./book-review.component.scss */ "./src/app/components/book-review/book-review.component.scss")]
    })
], BookReviewComponent);



/***/ }),

/***/ "./src/app/components/cart/cart.component.scss":
/*!*****************************************************!*\
  !*** ./src/app/components/cart/cart.component.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "mat-card {\n  width: 60%;\n}\n\n.My-cart {\n  margin-left: 4%;\n}\n\n.book {\n  margin-left: 4%;\n  margin-top: 4%;\n  width: 40%;\n  height: 120px;\n}\n\nimg {\n  width: 100%;\n  height: 100%;\n}\n\n.book-image {\n  width: 100px;\n  height: 120px;\n}\n\n.book-details {\n  margin-left: 14%;\n  font-size: 14px;\n}\n\nspan.author-name {\n  text-align: left;\n  font: Regular 10px/12px Lato;\n  letter-spacing: 0px;\n  color: #9d9d9d;\n  opacity: 1;\n  font-size: 10px;\n}\n\n.button-minus,\n.button-plus {\n  outline: none;\n  background-color: #fafafa;\n  border: 1px solid #a19f9f;\n  opacity: 1;\n  height: 24px;\n  width: 24px;\n  box-shadow: initial;\n}\n\n.button-minus::ng-deep .mat-button-wrapper,\n.button-plus::ng-deep .mat-button-wrapper {\n  line-height: 14px;\n  padding: 0;\n}\n\n.button-minus::ng-deep .mat-button-wrapper .mat-icon,\n.button-plus::ng-deep .mat-button-wrapper .mat-icon {\n  font-size: 14px;\n}\n\nmat-mini-fab {\n  height: 24px;\n}\n\n.button-remove {\n  outline: none;\n  border: none;\n  background-color: white;\n  padding: 0px;\n  opacity: 1;\n  border: none;\n  font-size: 70%;\n  height: 16px;\n}\n\ninput.quantity-field {\n  width: 20%;\n  font-size: 70%;\n  height: 4vh;\n  text-align: center;\n  outline: none;\n  background: #ffffff 0% 0% no-repeat padding-box;\n  border: 1px solid #dbdbdb;\n  border-radius: 1px;\n  opacity: 1;\n}\n\ninput::-webkit-outer-spin-button,\ninput::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n\n.input-group {\n  margin-left: 25%;\n  width: 40%;\n}\n\n.button-placeorder {\n  height: 100%;\n  width: 23%;\n  font-size: medium;\n  outline: none;\n  background-color: #3371b5;\n  border: none;\n}\n\n.row3 {\n  float: right;\n  margin-top: -74px;\n}\n\n.row1 {\n  float: right;\n  margin-top: -50px;\n}\n\n.row2 {\n  float: right;\n  margin-top: -50px;\n}\n\n.mat-form-field {\n  width: 300px;\n  height: 10px;\n}\n\n.child1 {\n  width: 10%;\n  height: 110px;\n}\n\n.child2 {\n  margin-top: 3%;\n  padding-left: 2%;\n}\n\n#check {\n  font-size: small;\n  color: white;\n}\n\n.book-img {\n  background-color: #a03037;\n  width: 90px;\n  height: 90px;\n}\n\n.shop-now {\n  background-color: #a03037;\n  color: white;\n}\n\n.matInput {\n  background: none;\n}\n\n.total-price {\n  margin-left: 4%;\n  margin-top: 4%;\n}\n\n@media only screen and (max-width: 720px) {\n  .form {\n    width: 240px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .mat-form-field {\n    width: 100px;\n    height: 4px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .row3 {\n    float: right;\n    margin-top: -74px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .mat-radio-group {\n    font-size: 10px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jYXJ0L0M6XFxVc2Vyc1xca2FtYW5cXERlc2t0b3BcXGZpbmFsIHByb2plY3RzXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3RlclxcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXIvc3JjXFxhcHBcXGNvbXBvbmVudHNcXGNhcnRcXGNhcnQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvY2FydC9jYXJ0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsVUFBQTtBQ0NGOztBRENBO0VBQ0UsZUFBQTtBQ0VGOztBREFBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtBQ0dGOztBRERBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUNJRjs7QURGQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FDS0Y7O0FESEE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7QUNNRjs7QURKQTtFQUNFLGdCQUFBO0VBQ0EsNEJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtBQ09GOztBRExBOztFQUVFLGFBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUNRRjs7QURQRTs7RUFDRSxpQkFBQTtFQUNBLFVBQUE7QUNVSjs7QURSSTs7RUFDRSxlQUFBO0FDV047O0FEUEE7RUFDRSxZQUFBO0FDVUY7O0FEUkE7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUNXRjs7QURUQTtFQUNFLFVBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLCtDQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUNZRjs7QURWQTs7RUFFRSx3QkFBQTtFQUNBLFNBQUE7QUNhRjs7QURYQTtFQUNFLGdCQUFBO0VBQ0EsVUFBQTtBQ2NGOztBRFpBO0VBQ0UsWUFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7QUNlRjs7QURGQTtFQUNFLFlBQUE7RUFDQyxpQkFBQTtBQ0tIOztBREZBO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0FDS0Y7O0FER0E7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7QUNBRjs7QURJQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0FDREY7O0FEU0E7RUFDRSxVQUFBO0VBQ0EsYUFBQTtBQ05GOztBRFFBO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0FDTEY7O0FET0E7RUFDRSxnQkFBQTtFQUVBLFlBQUE7QUNMRjs7QURPQTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNKRjs7QURNQTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtBQ0hGOztBREtBO0VBQ0UsZ0JBQUE7QUNGRjs7QURJQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDREY7O0FES0E7RUFDRTtJQUNFLFlBQUE7RUNGRjtBQUNGOztBREtDO0VBQ0M7SUFDRSxZQUFBO0lBQ0EsV0FBQTtFQ0hGO0FBQ0Y7O0FET0E7RUFDRTtJQUNFLFlBQUE7SUFDQSxpQkFBQTtFQ0xGO0FBQ0Y7O0FEUUM7RUFDQTtJQUNELGVBQUE7RUNORTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9jYXJ0L2NhcnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJtYXQtY2FyZCB7XG4gIHdpZHRoOiA2MCU7XG59XG4uTXktY2FydCB7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbn1cbi5ib29rIHtcbiAgbWFyZ2luLWxlZnQ6IDQlO1xuICBtYXJnaW4tdG9wOiA0JTtcbiAgd2lkdGg6IDQwJTtcbiAgaGVpZ2h0OiAxMjBweDtcbn1cbmltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG4uYm9vay1pbWFnZSB7XG4gIHdpZHRoOiAxMDBweDtcbiAgaGVpZ2h0OiAxMjBweDtcbn1cbi5ib29rLWRldGFpbHMge1xuICBtYXJnaW4tbGVmdDogMTQlO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5zcGFuLmF1dGhvci1uYW1lIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udDogUmVndWxhciAxMHB4LzEycHggTGF0bztcbiAgbGV0dGVyLXNwYWNpbmc6IDBweDtcbiAgY29sb3I6ICM5ZDlkOWQ7XG4gIG9wYWNpdHk6IDE7XG4gIGZvbnQtc2l6ZTogMTBweDtcbn1cbi5idXR0b24tbWludXMsXG4uYnV0dG9uLXBsdXMge1xuICBvdXRsaW5lOiBub25lO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmFmYWZhO1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMTYxLCAxNTksIDE1OSk7XG4gIG9wYWNpdHk6IDE7XG4gIGhlaWdodDogMjRweDtcbiAgd2lkdGg6IDI0cHg7XG4gIGJveC1zaGFkb3c6IGluaXRpYWw7XG4gICY6Om5nLWRlZXAgLm1hdC1idXR0b24td3JhcHBlciB7XG4gICAgbGluZS1oZWlnaHQ6IDE0cHg7XG4gICAgcGFkZGluZzogMDtcblxuICAgIC5tYXQtaWNvbiB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgfVxuICB9XG59XG5tYXQtbWluaS1mYWIge1xuICBoZWlnaHQ6IDI0cHg7XG59XG4uYnV0dG9uLXJlbW92ZSB7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGJvcmRlcjogbm9uZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDBweDtcbiAgb3BhY2l0eTogMTtcbiAgYm9yZGVyOiBub25lO1xuICBmb250LXNpemU6IDcwJTtcbiAgaGVpZ2h0OiAxNnB4O1xufVxuaW5wdXQucXVhbnRpdHktZmllbGQge1xuICB3aWR0aDogMjAlO1xuICBmb250LXNpemU6IDcwJTtcbiAgaGVpZ2h0OiA0dmg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgb3V0bGluZTogbm9uZTtcbiAgYmFja2dyb3VuZDogI2ZmZmZmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkYmRiZGI7XG4gIGJvcmRlci1yYWRpdXM6IDFweDtcbiAgb3BhY2l0eTogMTtcbn1cbmlucHV0Ojotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uLFxuaW5wdXQ6Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b24ge1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gIG1hcmdpbjogMDtcbn1cbi5pbnB1dC1ncm91cCB7XG4gIG1hcmdpbi1sZWZ0OiAyNSU7XG4gIHdpZHRoOiA0MCU7XG59XG4uYnV0dG9uLXBsYWNlb3JkZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAyMyU7XG4gIGZvbnQtc2l6ZTogbWVkaXVtO1xuICBvdXRsaW5lOiBub25lO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzM3MWI1O1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi8vIC5mb3Jte1xuLy8gICBtYXJnaW4tdG9wOiAyNSU7XG4vLyB9XG5cbi8vIC5yb3cge1xuLy8gICBmbG9hdDogcmlnaHQ7XG4vLyAgIG1hcmdpbi10b3A6IC03M3B4O1xuLy8gICAvL21hcmdpbi1yaWdodDogMTIwcHg7XG4vLyB9XG5cbi5yb3czIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICAgbWFyZ2luLXRvcDogLTc0cHg7XG4gXG59XG4ucm93MSB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogLTUwcHg7XG4gICAvLyBtYXJnaW4tcmlnaHQ6IDEyMHB4O1xufVxuLy8gLnJvdzEge1xuLy8gICBmbG9hdDogcmlnaHQ7XG4vLyAgIG1hcmdpbi10b3A6IDFweDtcbi8vICAvLyBtYXJnaW4tcmlnaHQ6IDEyMHB4O1xuLy8gfVxuLnJvdzIge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IC01MHB4O1xuICAvL21hcmdpbi1yaWdodDogMTIwcHg7XG59XG5cbi5tYXQtZm9ybS1maWVsZCB7XG4gIHdpZHRoOiAzMDBweDtcbiAgaGVpZ2h0OiAxMHB4O1xufVxuXG4vLyAub3JkZXJNYXRcbi8vIHtcbi8vICAgbWFyZ2luLXRvcDogNzAlO1xuLy8gICAvL2JveC1zaGFkb3c6IDBweCAycHggOHB4IDBweDtcbi8vIH1cbi5jaGlsZDEge1xuICB3aWR0aDogMTAlO1xuICBoZWlnaHQ6IDExMHB4O1xufVxuLmNoaWxkMiB7XG4gIG1hcmdpbi10b3A6IDMlO1xuICBwYWRkaW5nLWxlZnQ6IDIlO1xufVxuI2NoZWNrIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbiAgLy9oZWlnaHQ6IDIwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi5ib29rLWltZyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNhMDMwMzc7XG4gIHdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG59XG4uc2hvcC1ub3cge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTAzMDM3O1xuICBjb2xvcjogd2hpdGU7XG59XG4ubWF0SW5wdXR7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG59XG4udG90YWwtcHJpY2V7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbiAgbWFyZ2luLXRvcDogNCU7XG59XG5cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAuZm9ybXtcbiAgICB3aWR0aDogMjQwcHg7XG4gIH1cbn1cblxuIEBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzIwcHgpIHtcbiAgLm1hdC1mb3JtLWZpZWxke1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBoZWlnaHQ6IDRweDsgIFxuICBcbiAgfVxufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5yb3cze1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBtYXJnaW4tdG9wOi03NHB4O1xuICAgIFxuICB9XG59XG4gQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuIC5tYXQtcmFkaW8tZ3JvdXB7XG5mb250LXNpemU6IDEwcHg7XG4gfVxuIH1cbiIsIm1hdC1jYXJkIHtcbiAgd2lkdGg6IDYwJTtcbn1cblxuLk15LWNhcnQge1xuICBtYXJnaW4tbGVmdDogNCU7XG59XG5cbi5ib29rIHtcbiAgbWFyZ2luLWxlZnQ6IDQlO1xuICBtYXJnaW4tdG9wOiA0JTtcbiAgd2lkdGg6IDQwJTtcbiAgaGVpZ2h0OiAxMjBweDtcbn1cblxuaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmJvb2staW1hZ2Uge1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTIwcHg7XG59XG5cbi5ib29rLWRldGFpbHMge1xuICBtYXJnaW4tbGVmdDogMTQlO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbnNwYW4uYXV0aG9yLW5hbWUge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250OiBSZWd1bGFyIDEwcHgvMTJweCBMYXRvO1xuICBsZXR0ZXItc3BhY2luZzogMHB4O1xuICBjb2xvcjogIzlkOWQ5ZDtcbiAgb3BhY2l0eTogMTtcbiAgZm9udC1zaXplOiAxMHB4O1xufVxuXG4uYnV0dG9uLW1pbnVzLFxuLmJ1dHRvbi1wbHVzIHtcbiAgb3V0bGluZTogbm9uZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2ExOWY5ZjtcbiAgb3BhY2l0eTogMTtcbiAgaGVpZ2h0OiAyNHB4O1xuICB3aWR0aDogMjRweDtcbiAgYm94LXNoYWRvdzogaW5pdGlhbDtcbn1cbi5idXR0b24tbWludXM6Om5nLWRlZXAgLm1hdC1idXR0b24td3JhcHBlcixcbi5idXR0b24tcGx1czo6bmctZGVlcCAubWF0LWJ1dHRvbi13cmFwcGVyIHtcbiAgbGluZS1oZWlnaHQ6IDE0cHg7XG4gIHBhZGRpbmc6IDA7XG59XG4uYnV0dG9uLW1pbnVzOjpuZy1kZWVwIC5tYXQtYnV0dG9uLXdyYXBwZXIgLm1hdC1pY29uLFxuLmJ1dHRvbi1wbHVzOjpuZy1kZWVwIC5tYXQtYnV0dG9uLXdyYXBwZXIgLm1hdC1pY29uIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG5tYXQtbWluaS1mYWIge1xuICBoZWlnaHQ6IDI0cHg7XG59XG5cbi5idXR0b24tcmVtb3ZlIHtcbiAgb3V0bGluZTogbm9uZTtcbiAgYm9yZGVyOiBub25lO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMHB4O1xuICBvcGFjaXR5OiAxO1xuICBib3JkZXI6IG5vbmU7XG4gIGZvbnQtc2l6ZTogNzAlO1xuICBoZWlnaHQ6IDE2cHg7XG59XG5cbmlucHV0LnF1YW50aXR5LWZpZWxkIHtcbiAgd2lkdGg6IDIwJTtcbiAgZm9udC1zaXplOiA3MCU7XG4gIGhlaWdodDogNHZoO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGJhY2tncm91bmQ6ICNmZmZmZmYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGJkYmRiO1xuICBib3JkZXItcmFkaXVzOiAxcHg7XG4gIG9wYWNpdHk6IDE7XG59XG5cbmlucHV0Ojotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uLFxuaW5wdXQ6Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b24ge1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gIG1hcmdpbjogMDtcbn1cblxuLmlucHV0LWdyb3VwIHtcbiAgbWFyZ2luLWxlZnQ6IDI1JTtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLmJ1dHRvbi1wbGFjZW9yZGVyIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMjMlO1xuICBmb250LXNpemU6IG1lZGl1bTtcbiAgb3V0bGluZTogbm9uZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzMzNzFiNTtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4ucm93MyB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogLTc0cHg7XG59XG5cbi5yb3cxIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAtNTBweDtcbn1cblxuLnJvdzIge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IC01MHB4O1xufVxuXG4ubWF0LWZvcm0tZmllbGQge1xuICB3aWR0aDogMzAwcHg7XG4gIGhlaWdodDogMTBweDtcbn1cblxuLmNoaWxkMSB7XG4gIHdpZHRoOiAxMCU7XG4gIGhlaWdodDogMTEwcHg7XG59XG5cbi5jaGlsZDIge1xuICBtYXJnaW4tdG9wOiAzJTtcbiAgcGFkZGluZy1sZWZ0OiAyJTtcbn1cblxuI2NoZWNrIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uYm9vay1pbWcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTAzMDM3O1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiA5MHB4O1xufVxuXG4uc2hvcC1ub3cge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTAzMDM3O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5tYXRJbnB1dCB7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG59XG5cbi50b3RhbC1wcmljZSB7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbiAgbWFyZ2luLXRvcDogNCU7XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzIwcHgpIHtcbiAgLmZvcm0ge1xuICAgIHdpZHRoOiAyNDBweDtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAubWF0LWZvcm0tZmllbGQge1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBoZWlnaHQ6IDRweDtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAucm93MyB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIG1hcmdpbi10b3A6IC03NHB4O1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5tYXQtcmFkaW8tZ3JvdXAge1xuICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/cart/cart.component.ts":
/*!***************************************************!*\
  !*** ./src/app/components/cart/cart.component.ts ***!
  \***************************************************/
/*! exports provided: CartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartComponent", function() { return CartComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_cart_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/cart.service */ "./src/services/cart.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../login/login.component */ "./src/app/components/login/login.component.ts");









let CartComponent = class CartComponent {
    constructor(cartService, snackBar, messageService, fb, userService, route, dialog) {
        this.cartService = cartService;
        this.snackBar = snackBar;
        this.messageService = messageService;
        this.fb = fb;
        this.userService = userService;
        this.route = route;
        this.dialog = dialog;
        this.show = false;
        this.buttonName = 'Show';
        this.cartBooks = [];
        this.bookSum = [];
        this.image = './assets/images/bookstore-wallpaper.jpg';
        this.disp = false;
        this.addressGroup = this.fb.group({
            name: [],
            phone: [],
            pincode: [],
            locality: [],
            address: [],
            city: [],
            landmark: [],
            type: [],
        });
    }
    ngOnInit() {
        this.messageService.cartMessage.subscribe((data) => {
            this.cartBooks = [];
            this.totalPrice = 0;
            this.displayBooksInCart(data);
            localStorage.setItem('cartSize', String(this.cartSize));
        });
        this.cartSize = Number(localStorage.getItem('cartSize'));
        this.messageService.quantityMessage.subscribe((data) => {
            this.onUpdateQuantity(data);
            localStorage.setItem('cartSize', String(this.cartSize));
        });
    }
    ngOnChanges() {
        this.messageService.onCartRefresh();
    }
    removeFromCart(cartBook) {
        if (localStorage.getItem('token') === null &&
            localStorage.getItem('cart') != null) {
            this.cart = JSON.parse(localStorage.getItem('cart'));
            this.cart.cartBooks.forEach((element) => {
                if (element.book.bookId === cartBook.book.bookId) {
                    this.cart.totalBooksInCart =
                        this.cart.totalBooksInCart - element.bookQuantity;
                    this.cart.cartBooks.splice(this.cart.cartBooks.indexOf(element), 1);
                }
            });
            localStorage.setItem('cart', JSON.stringify(this.cart));
            console.log(localStorage.getItem('cartSize'));
            localStorage.setItem('cartSize', String(this.cart.totalBooksInCart));
            this.messageService.cartBooks();
            this.messageService.onCartRefresh();
            this.snackBar.open('Book Removed From Cart', 'ok', {
                duration: 2000,
            });
        }
        else {
            this.cartService.removeFromCart(cartBook.cartBookId).subscribe((data) => {
                if (data.status === 200) {
                    localStorage.setItem('cartSize', data.data.totalBooksInCart);
                    this.messageService.cartBooks();
                    this.messageService.onCartCount();
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
            }, (error) => {
                this.snackBar.open(error.error.message, 'ok', {
                    duration: 2000,
                });
            });
        }
    }
    displayBooksInCart(data) {
        if (localStorage.getItem('token') === null) {
            this.cartSize = data.totalBooksInCart;
            this.cart = data.cartBooks.forEach((cartBookData) => {
                this.cartBooks.push(cartBookData);
                // console.log(cartBookData);
                // this.totalPrice = this.totalPrice + cartBookData.totalBookPrice;
            });
        }
        else {
            if (data.status === 200) {
                this.cartSize = data.data.totalBooksInCart;
                data.data.cartBooks.forEach((cartBookData) => {
                    console.log(cartBookData);
                    this.totalPrice = this.totalPrice + cartBookData.totalBookPrice;
                    this.cartBooks.push(cartBookData);
                });
            }
        }
    }
    addQuantity(cartBook) {
        if (localStorage.getItem('token') === null &&
            localStorage.getItem('cart') != null) {
            this.cart = JSON.parse(localStorage.getItem('cart'));
            if (this.cart.totalBooksInCart < 5) {
                this.cart.cartBooks.forEach((element) => {
                    if (element.book.bookId === cartBook.book.bookId) {
                        if (element.bookQuantity < cartBook.book.quantity) {
                            element.bookQuantity++;
                            element.totalBookPrice += cartBook.book.price;
                            this.cart.totalBooksInCart++;
                        }
                        else {
                            this.snackBar.open('Book Out Of Stock', 'ok', { duration: 2000 });
                        }
                    }
                });
                localStorage.setItem('cart', JSON.stringify(this.cart));
                localStorage.setItem('cartSize', String(this.cart.totalBooksInCart));
                this.messageService.cartBooks();
                this.messageService.onCartRefresh();
                this.snackBar.open('Book Quantity Increased', 'ok', {
                    duration: 2000,
                });
            }
            else {
                this.snackBar.open('Cart is full', 'ok', { duration: 2000 });
            }
        }
        else {
            this.cartService.addQuantity(cartBook.cartBookId).subscribe((data) => {
                if (data.status === 200) {
                    localStorage.setItem('cartSize', String(data.data.totalBooksInCart));
                    this.messageService.cartBooks();
                    this.messageService.onCartCount();
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
            }, (error) => {
                this.snackBar.open(error.error.message, 'ok', {
                    duration: 20000,
                });
            });
        }
    }
    onPlaceOrder() {
        if (localStorage.getItem('token') === null) {
            this.dialog.open(_login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"]);
        }
        this.show = true;
        this.checkAddressExistornot();
        // this.snackBar.open('Order Placed', 'ok', {
        //   duration: 2000
        // });
    }
    continue() {
        this.cartService.displayBooksInCart().subscribe((response) => {
            console.log('book in cart:', response);
            this.bookSum = response.data.cartBooks;
            this.bookSum.forEach(function (val) {
                console.log('book1:', val);
                console.log('name:', val.book.bookName);
            });
        });
        this.disp = true;
    }
    removeQuantity(cartBook) {
        if (localStorage.getItem('token') === null &&
            localStorage.getItem('cart') != null) {
            this.cart = JSON.parse(localStorage.getItem('cart'));
            if (this.cart.totalBooksInCart > 0) {
                this.cart.cartBooks.forEach((element) => {
                    if (element.book.bookId === cartBook.book.bookId) {
                        if (element.bookQuantity > 1) {
                            element.bookQuantity--;
                            element.totalBookPrice -= cartBook.book.price;
                            this.cart.totalBooksInCart--;
                        }
                        else {
                            this.snackBar.open('Cart items cant be less than 1', 'ok', {
                                duration: 2000,
                            });
                        }
                    }
                });
                localStorage.setItem('cart', JSON.stringify(this.cart));
                localStorage.setItem('cartSize', String(this.cart.totalBooksInCart));
                this.messageService.cartBooks();
                this.messageService.onCartRefresh();
                this.snackBar.open('Book Quantity Decreased', 'ok', {
                    duration: 2000,
                });
            }
            else {
                this.snackBar.open('No Items In cart To remove quantity', 'ok', {
                    duration: 2000,
                });
            }
        }
        else {
            this.cartService.removeQuantity(cartBook.cartBookId).subscribe((data) => {
                if (data.status === 200) {
                    localStorage.setItem('cartSize', data.data.totalBooksInCart);
                    this.messageService.cartBooks();
                    this.messageService.onCartCount();
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
            }, (error) => {
                this.snackBar.open(error.error.message, 'ok', {
                    duration: 20000,
                });
            });
        }
    }
    onCheckOut() {
        const data = {
            name: this.addressGroup.get('name').value,
            phoneNumber: this.addressGroup.get('phone').value,
            pincode: this.addressGroup.get('pincode').value,
            locality: this.addressGroup.get('locality').value,
            address: this.addressGroup.get('address').value,
            city: this.addressGroup.get('city').value,
            landmark: this.addressGroup.get('landmark').value,
            addressType: this.addressGroup.get('type').value
        };
        this.userService.Address(data).subscribe((result) => {
            if (result.status == 200) {
                this.snackBar.open('address added', 'ok', { duration: 5000 });
            }
        });
        this.userService.onCheckOut().subscribe((data) => {
            if (data.status === 200) {
                this.messageService.onCartCount();
                localStorage.setItem('orderId', data.data.orderId);
                this.snackBar.open(data.message, 'ok', {
                    duration: 2000,
                });
                this.route.navigate(['/dashboard/successPage']);
            }
        }, (error) => {
            this.snackBar.open(error.error.message, 'ok', {
                duration: 2000,
            });
        });
    }
    onShowNow() {
        this.route.navigate(['/dashboard/getallbooks']);
    }
    onKey(event, cartBook) {
        if (localStorage.getItem('token') === null && localStorage.getItem('cart') !== null) {
            this.quantity = 0;
            this.quantity = Number(event.target.value);
            if (this.quantity === 0 || event.target.value === '') {
                this.snackBar.open('Cart Items Can not be less than one', 'cancel', {
                    duration: 2000
                });
            }
            else {
                this.cart = JSON.parse(localStorage.getItem('cart'));
                this.cart.totalBooksInCart = this.cart.totalBooksInCart - cartBook.bookQuantity;
                if ((this.cart.totalBooksInCart + this.quantity) < 6) {
                    this.cart.cartBooks.forEach(element => {
                        if (element.book.bookId === cartBook.book.bookId) {
                            if (Number(cartBook.book.quantity) > this.quantity) {
                                element.bookQuantity = this.quantity;
                                element.totalBookPrice = element.book.price * this.quantity;
                                this.cart.totalBooksInCart = this.cart.totalBooksInCart + this.quantity;
                            }
                            else {
                                this.snackBar.open('Book Out Of Stock', 'ok', {
                                    duration: 2000
                                });
                            }
                        }
                    });
                    localStorage.setItem('cart', JSON.stringify(this.cart));
                    localStorage.setItem('cartSize', String(this.cart.totalBooksInCart));
                    this.messageService.cartBooks();
                    this.messageService.onCartRefresh();
                    this.snackBar.open('Quantity Updated SuccessFully', 'ok', {
                        duration: 2000,
                    });
                }
                else {
                    this.messageService.cartBooks();
                    this.messageService.onCartRefresh();
                    this.snackBar.open('Cart Books Exceeded limit of 5 Books', 'ok', {
                        duration: 2000
                    });
                }
            }
        }
        if (localStorage.getItem('token') !== null) {
            this.messageService.onUpdateQuantity(event, cartBook.cartBookId);
        }
    }
    onUpdateQuantity(data) {
        if (data.status === 200) {
            this.cartSize = data.totalBooksInCart;
            this.messageService.cartBooks();
            this.messageService.onCartCount();
            this.snackBar.open(data.message, 'ok', {
                duration: 2000
            });
        }
        else if (data.status === 417) {
            this.messageService.cartBooks();
            this.snackBar.open(data.error.message, 'cancel', {
                duration: 2000
            });
        }
        else if (data.status === 404) {
            this.messageService.cartBooks();
            this.snackBar.open(data.error.message, 'cancel', {
                duration: 2000
            });
        }
    }
    checkAddressExistornot() {
        this.userService.getAddress('home').subscribe((result) => {
            if (result.status == 200) {
                console.log("Entered to get home address");
                console.log("home address:", result);
                this.addAddress(result.data);
            }
        }, (error => {
            console.log("Entered to get work address");
            this.userService.getAddress('work').subscribe((response) => {
                if (response.status == 200) {
                    console.log("office Address:", response);
                    this.addAddress(response.data);
                }
            }, (error => {
                this.snackBar.open('you have not provided any address,Please fill your address', 'ok', { duration: 5000 });
            }));
        }));
    }
    addAddress(addr) {
        console.log("address in add address:", addr);
        this.addressGroup.get('name').setValue(addr.name);
        this.addressGroup.get('phone').setValue(addr.phoneNumber);
        this.addressGroup.get('pincode').setValue(addr.pincode);
        this.addressGroup.get('locality').setValue(addr.locality);
        this.addressGroup.get('address').setValue(addr.address);
        this.addressGroup.get('city').setValue(addr.city);
        this.addressGroup.get('landmark').setValue(addr.landmark);
        this.addressGroup.get('type').setValue(addr.addressType);
        this.addressGroup.disable();
    }
    onedit() {
        console.log("to enable fiedls");
        this.addressGroup.enable();
    }
    selectAddrType(event) {
        this.addressGroup.reset();
        this.addressGroup.get('type').setValue(event.value);
        this.userService.getAddress(event.value).subscribe((result) => {
            if (result.status == 200)
                this.addAddress(result.data);
        }, (error) => {
            this.snackBar.open(error.error.message, 'ok', { duration: 3000 });
        });
    }
};
CartComponent.ctorParameters = () => [
    { type: src_services_cart_service__WEBPACK_IMPORTED_MODULE_2__["CartServiceService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_4__["MessageService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] }
];
CartComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cart',
        template: __webpack_require__(/*! raw-loader!./cart.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/cart/cart.component.html"),
        styles: [__webpack_require__(/*! ./cart.component.scss */ "./src/app/components/cart/cart.component.scss")]
    })
], CartComponent);



/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".dashboard {\n  top: 0px;\n  left: 0px;\n  width: 1366px;\n  height: 1322px;\n  border: 1px solid #e2e2e2;\n  opacity: 1;\n  background: #ffffff 0% 0% no-repeat padding-box;\n}\n\n.mat-icon:hover {\n  color: blanchedalmond;\n}\n\n.pic:hover {\n  color: blanchedalmond;\n}\n\n.footer {\n  position: fixed;\n  left: 0;\n  bottom: 0;\n  width: 100%;\n  background-color: black;\n  color: white;\n  height: 40px;\n  padding-left: 17%;\n  font-size: 16px;\n}\n\n.left {\n  float: right;\n  height: -10px;\n  width: 15%;\n  margin-top: -47%;\n  margin-right: -20%;\n  border-color: white;\n}\n\n.mat-icon {\n  color: white;\n}\n\n.mat-paginator {\n  padding-bottom: 30%;\n}\n\n.box {\n  width: 100%;\n  height: 100%;\n  padding: 25%;\n  border: 1px solid whitesmoke;\n  border-radius: 1px;\n  border-color: lightgray;\n}\n\n.logo {\n  position: absolute;\n  color: aliceblue;\n  margin-top: 1.5%;\n  margin-left: 15%;\n}\n\n.cartname {\n  position: absolute;\n  color: aliceblue;\n  margin-top: 1.5%;\n  margin-left: 64%;\n}\n\n.loginText {\n  position: absolute;\n  color: aliceblue;\n  margin-top: 1.5%;\n  margin-left: 75%;\n}\n\n.mattool {\n  height: 30px;\n  margin-left: 300px;\n  width: 450px;\n  align-content: space-around;\n}\n\n.input {\n  height: 20px;\n  border: none;\n  outline: none;\n  position: absolute;\n  margin-left: 350px;\n  margin-top: 2px;\n}\n\n.mysearch {\n  position: absolute;\n  border: none;\n  outline: none;\n  margin-left: 300px;\n}\n\nspan {\n  margin-left: 250px;\n}\n\n.cart {\n  margin-left: 4%;\n  padding-right: 5%;\n  background-color: none;\n  outline: none;\n  color: aliceblue;\n  margin-right: 3%;\n}\n\n.login {\n  margin-left: 6%;\n  background-color: none;\n  outline: none;\n  color: aliceblue;\n}\n\n.profile {\n  margin-left: 8px;\n}\n\n::ng-deep .profilemenu {\n  width: 300px;\n  height: 340px;\n}\n\n.mat-headline,\n.mat-subheading-1 {\n  margin-top: 50%;\n  text-align: center;\n  padding: 0px;\n  margin: 0px;\n}\n\n.signup,\n.log {\n  width: 50%;\n}\n\n.signup :hover,\n.log :hover {\n  background: none;\n}\n\n.fileuploadbtn {\n  width: 0px;\n  height: 0px;\n  display: none;\n  visibility: hidden;\n}\n\n.icon {\n  color: black;\n  margin-left: -79px;\n}\n\n.pic {\n  width: 50px;\n  height: 50px;\n  color: brown;\n  position: absolute;\n  border: 1px red solid;\n  margin-top: -12px;\n}\n\n.upload-img {\n  position: relative;\n  margin-left: 50%;\n  padding-top: 13%;\n}\n\n.editbutton {\n  color: black;\n  left: 25%;\n  width: 50%;\n}\n\n.divfooter {\n  width: 1366px;\n  border: 1px solid #e2e2e2;\n  opacity: 1;\n}\n\n.matfooter {\n  height: 55px;\n  background-color: #b33b3b;\n  color: white;\n  background-color: black;\n  padding-left: 17%;\n  padding-top: 2px;\n}\n\n.span.small {\n  font-size: 5px;\n}\n\n.mat-badge-content {\n  background: white;\n  color: #a03037;\n}\n\n.search {\n  color: black;\n}\n\n.tool {\n  width: 100%;\n  height: 64px;\n  background-color: #a03037;\n  top: 0;\n  position: fixed;\n  z-index: 100;\n}\n\n.titleText {\n  margin-left: 6%;\n  color: white;\n  margin-right: 3%;\n}\n\n@media only screen and (max-width: 720px) {\n  .titleText {\n    font-size: 15px;\n    margin-left: -2%;\n    color: white;\n    margin-right: 16px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .search-mat-card {\n    margin-right: 10px;\n    width: 30px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .cart {\n    font-size: 14px;\n    margin-right: 25px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .mat-icon {\n    font-size: 18px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .searchInput {\n    margin-left: -15px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .searchIcon {\n    font-size: 17px;\n    margin-right: 3px;\n  }\n}\n\n.searchIcon {\n  opacity: 0.5;\n  color: black;\n}\n\n.searchIcon:hover {\n  opacity: 1;\n}\n\n.searchInput {\n  height: 50%;\n  width: 90%;\n  border: none;\n  outline: none;\n  font-size: 18px;\n  font-family: \"Times New Roman\", Times, serif;\n  font-style: normal;\n  color: dimgrey;\n}\n\n.search-mat-card {\n  margin-left: -3%;\n  width: 50%;\n  height: 54%;\n  padding: 0px;\n}\n\nbutton {\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9kYXNoYm9hcmQvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcZGFzaGJvYXJkXFxkYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUdFLFFBQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtFQUNBLFVBQUE7RUFDQSwrQ0FBQTtBQ0RGOztBRElBO0VBQ0UscUJBQUE7QUNERjs7QURJQTtFQUNFLHFCQUFBO0FDREY7O0FER0E7RUFDRSxlQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQ0FGOztBRE1BO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDSEY7O0FES0E7RUFDRSxZQUFBO0FDRkY7O0FESUE7RUFDRSxtQkFBQTtBQ0RGOztBRElBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FDREY7O0FESUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0RGOztBREdBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUNBRjs7QURFQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7QUNDRjs7QURDQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDRUY7O0FEQUE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUNHRjs7QUREQTtFQUNFLGtCQUFBO0FDSUY7O0FERkE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDS0Y7O0FESEE7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7QUNNRjs7QURKQTtFQUNFLGdCQUFBO0FDT0Y7O0FETEE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQ1FGOztBRE5BOztFQUVFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDU0Y7O0FEUEE7O0VBRUUsVUFBQTtBQ1VGOztBRFJDOztFQUNHLGdCQUFBO0FDV0o7O0FETEE7RUFDRSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQ1FGOztBRE5BO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FDU0Y7O0FEUEE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0VBRUEsaUJBQUE7QUNTRjs7QURQQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ1VGOztBRFJBO0VBRUUsWUFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FDVUY7O0FESkE7RUFDRSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxVQUFBO0FDT0Y7O0FESkE7RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FDT0Y7O0FESkE7RUFDRSxjQUFBO0FDT0Y7O0FETEE7RUFDRSxpQkFBQTtFQUNBLGNBQUE7QUNRRjs7QURMQTtFQUNFLFlBQUE7QUNRRjs7QURKQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxNQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNPRjs7QURKQTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNPRjs7QURMQTtFQUNFO0lBQ0UsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VDUUY7QUFDRjs7QURGQTtFQUNFO0lBQ0Usa0JBQUE7SUFDQSxXQUFBO0VDSUY7QUFDRjs7QURGQTtFQUNFO0lBQ0UsZUFBQTtJQUNBLGtCQUFBO0VDSUY7QUFDRjs7QURBQTtFQUNFO0lBQ0EsZUFBQTtFQ0VBO0FBQ0Y7O0FEQ0E7RUFDQTtJQUNDLGtCQUFBO0VDQ0M7QUFDRjs7QURFQTtFQUNBO0lBQ0UsZUFBQTtJQUNBLGlCQUFBO0VDQUE7QUFDRjs7QURRQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0FDTkY7O0FEUUE7RUFDRSxVQUFBO0FDTEY7O0FET0E7RUFDRSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLDRDQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDSkY7O0FETUE7RUFDRSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0hGOztBREtBO0VBQ0UsYUFBQTtBQ0ZGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9kYXNoYm9hcmQvZGFzaGJvYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRhc2hib2FyZCB7XG4gIC8vIHdpZHRoOjkyJTtcbiAgLy8gbWFyZ2luLWxlZnQ6IDQlO1xuICB0b3A6IDBweDtcbiAgbGVmdDogMHB4O1xuICB3aWR0aDogMTM2NnB4O1xuICBoZWlnaHQ6IDEzMjJweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UyZTJlMjtcbiAgb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZDogI2ZmZmZmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XG59XG5cbi5tYXQtaWNvbjpob3ZlciB7XG4gIGNvbG9yOiBibGFuY2hlZGFsbW9uZDtcbn1cblxuLnBpYzpob3ZlciB7XG4gIGNvbG9yOiBibGFuY2hlZGFsbW9uZDtcbn1cbi5mb290ZXIge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGxlZnQ6IDA7XG4gIGJvdHRvbTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtY29sb3I6YmxhY2s7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgaGVpZ2h0OiA0MHB4O1xuICBwYWRkaW5nLWxlZnQ6IDE3JTtcbiAgZm9udC1zaXplOiAxNnB4O1xuXG59XG5cblxuXG4ubGVmdCB7XG4gIGZsb2F0OiByaWdodDtcbiAgaGVpZ2h0OiAtMTBweDtcbiAgd2lkdGg6IDE1JTtcbiAgbWFyZ2luLXRvcDogLTQ3JTtcbiAgbWFyZ2luLXJpZ2h0OiAtMjAlO1xuICBib3JkZXItY29sb3I6IHdoaXRlO1xufVxuLm1hdC1pY29uIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuLm1hdC1wYWdpbmF0b3Ige1xuICBwYWRkaW5nLWJvdHRvbTogMzAlO1xufVxuXG4uYm94IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogMjUlO1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZXNtb2tlO1xuICBib3JkZXItcmFkaXVzOiAxcHg7XG4gIGJvcmRlci1jb2xvcjogbGlnaHRncmF5O1xufVxuXG4ubG9nbyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgbWFyZ2luLXRvcDogMS41JTtcbiAgbWFyZ2luLWxlZnQ6IDE1JTtcbn1cbi5jYXJ0bmFtZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgbWFyZ2luLXRvcDogMS41JTtcbiAgbWFyZ2luLWxlZnQ6IDY0JTtcbn1cbi5sb2dpblRleHQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGNvbG9yOiBhbGljZWJsdWU7XG4gIG1hcmdpbi10b3A6IDEuNSU7XG4gIG1hcmdpbi1sZWZ0OiA3NSU7XG59XG5cbi5tYXR0b29sIHtcbiAgaGVpZ2h0OiAzMHB4O1xuICBtYXJnaW4tbGVmdDogMzAwcHg7XG4gIHdpZHRoOiA0NTBweDtcbiAgYWxpZ24tY29udGVudDogc3BhY2UtYXJvdW5kO1xufVxuLmlucHV0IHtcbiAgaGVpZ2h0OiAyMHB4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbWFyZ2luLWxlZnQ6IDM1MHB4O1xuICBtYXJnaW4tdG9wOiAycHg7XG59XG4ubXlzZWFyY2gge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgbWFyZ2luLWxlZnQ6IDMwMHB4O1xufVxuc3BhbiB7XG4gIG1hcmdpbi1sZWZ0OiAyNTBweDtcbn1cbi5jYXJ0IHtcbiAgbWFyZ2luLWxlZnQ6IDQlO1xuICBwYWRkaW5nLXJpZ2h0OiA1JTtcbiAgYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgbWFyZ2luLXJpZ2h0OiAzJTtcbn1cbi5sb2dpbiB7XG4gIG1hcmdpbi1sZWZ0OiA2JTtcbiAgYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbn1cbi5wcm9maWxlIHtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbn1cbjo6bmctZGVlcCAucHJvZmlsZW1lbnUge1xuICB3aWR0aDogMzAwcHg7XG4gIGhlaWdodDogMzQwcHg7XG59XG4ubWF0LWhlYWRsaW5lLFxuLm1hdC1zdWJoZWFkaW5nLTEge1xuICBtYXJnaW4tdG9wOiA1MCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMHB4O1xuICBtYXJnaW46IDBweDtcbn1cbi5zaWdudXAsXG4ubG9nIHtcbiAgd2lkdGg6IDUwJTtcbiAgXG4gOmhvdmVye1xuICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gIH1cbn1cblxuXG5cbi5maWxldXBsb2FkYnRuIHtcbiAgd2lkdGg6IDBweDtcbiAgaGVpZ2h0OiAwcHg7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcbn1cbi5pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogLTc5cHg7XG59XG4ucGljIHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbiAgY29sb3I6IGJyb3duO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvcmRlcjogMXB4IHJlZCBzb2xpZDtcbiAgLy8gbGVmdDogMzUlO1xuICBtYXJnaW4tdG9wOiAtMTJweDtcbn1cbi51cGxvYWQtaW1nIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtYXJnaW4tbGVmdDogNTAlO1xuICBwYWRkaW5nLXRvcDogMTMlO1xufVxuLmVkaXRidXR0b24ge1xuICAvL2JhY2tncm91bmQtY29sb3I6IHJnYigxNzksIDU5LCA1OSk7XG4gIGNvbG9yOiBibGFjaztcbiAgbGVmdDogMjUlO1xuICB3aWR0aDogNTAlO1xufVxuLy8gI2xvZ291dCB7XG4vLyAgIGxlZnQ6IDAlO1xuLy8gfVxuXG4uZGl2Zm9vdGVyIHtcbiAgd2lkdGg6IDEzNjZweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UyZTJlMjtcbiAgb3BhY2l0eTogMTtcbn1cblxuLm1hdGZvb3RlciB7XG4gIGhlaWdodDogNTVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE3OSwgNTksIDU5KTtcbiAgY29sb3I6IHdoaXRlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgcGFkZGluZy1sZWZ0OiAxNyU7XG4gIHBhZGRpbmctdG9wOiAycHg7XG59XG5cbi5zcGFuLnNtYWxsIHtcbiAgZm9udC1zaXplOiA1cHg7XG59XG4ubWF0LWJhZGdlLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgY29sb3I6ICNhMDMwMzc7XG59XG5cbi5zZWFyY2gge1xuICBjb2xvcjogYmxhY2s7XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi50b29sIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgdG9wOiAwO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHotaW5kZXg6IDEwMDtcbn1cblxuLnRpdGxlVGV4dCB7XG4gIG1hcmdpbi1sZWZ0OiA2JTtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tcmlnaHQ6IDMlO1xufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAudGl0bGVUZXh0IHtcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IC0yJTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xuICB9XG59XG5cblxuXG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzIwcHgpIHtcbiAgLnNlYXJjaC1tYXQtY2FyZHtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7ICBcbiAgICB3aWR0aDogMzBweDtcbiAgIH0gXG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5jYXJ0e1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDI1cHg7XG4gIH1cbn1cblxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5tYXQtaWNvbntcbiAgZm9udC1zaXplOiAxOHB4O1xufVxufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4uc2VhcmNoSW5wdXR7XG4gbWFyZ2luLWxlZnQ6IC0xNXB4O1xuXG59XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4uc2VhcmNoSWNvbntcbiAgZm9udC1zaXplOiAxN3B4O1xuICBtYXJnaW4tcmlnaHQ6IDNweDtcbn1cbn1cblxuXG5cblxuXG5cbi5zZWFyY2hJY29uIHtcbiAgb3BhY2l0eTogMC41O1xuICBjb2xvcjogYmxhY2s7XG59XG4uc2VhcmNoSWNvbjpob3ZlciB7XG4gIG9wYWNpdHk6IDE7XG59XG4uc2VhcmNoSW5wdXQge1xuICBoZWlnaHQ6IDUwJTtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtZmFtaWx5OiAnVGltZXMgTmV3IFJvbWFuJywgVGltZXMsIHNlcmlmO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGNvbG9yOiBkaW1ncmV5O1xufVxuLnNlYXJjaC1tYXQtY2FyZCB7XG4gIG1hcmdpbi1sZWZ0OiAtMyU7XG4gIHdpZHRoOiA1MCU7XG4gIGhlaWdodDogNTQlO1xuICBwYWRkaW5nOiAwcHg7XG59XG5idXR0b24ge1xuICBvdXRsaW5lOiBub25lO1xufSIsIi5kYXNoYm9hcmQge1xuICB0b3A6IDBweDtcbiAgbGVmdDogMHB4O1xuICB3aWR0aDogMTM2NnB4O1xuICBoZWlnaHQ6IDEzMjJweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UyZTJlMjtcbiAgb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZDogI2ZmZmZmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XG59XG5cbi5tYXQtaWNvbjpob3ZlciB7XG4gIGNvbG9yOiBibGFuY2hlZGFsbW9uZDtcbn1cblxuLnBpYzpob3ZlciB7XG4gIGNvbG9yOiBibGFuY2hlZGFsbW9uZDtcbn1cblxuLmZvb3RlciB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgaGVpZ2h0OiA0MHB4O1xuICBwYWRkaW5nLWxlZnQ6IDE3JTtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ubGVmdCB7XG4gIGZsb2F0OiByaWdodDtcbiAgaGVpZ2h0OiAtMTBweDtcbiAgd2lkdGg6IDE1JTtcbiAgbWFyZ2luLXRvcDogLTQ3JTtcbiAgbWFyZ2luLXJpZ2h0OiAtMjAlO1xuICBib3JkZXItY29sb3I6IHdoaXRlO1xufVxuXG4ubWF0LWljb24ge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5tYXQtcGFnaW5hdG9yIHtcbiAgcGFkZGluZy1ib3R0b206IDMwJTtcbn1cblxuLmJveCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBhZGRpbmc6IDI1JTtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGVzbW9rZTtcbiAgYm9yZGVyLXJhZGl1czogMXB4O1xuICBib3JkZXItY29sb3I6IGxpZ2h0Z3JheTtcbn1cblxuLmxvZ28ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGNvbG9yOiBhbGljZWJsdWU7XG4gIG1hcmdpbi10b3A6IDEuNSU7XG4gIG1hcmdpbi1sZWZ0OiAxNSU7XG59XG5cbi5jYXJ0bmFtZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgbWFyZ2luLXRvcDogMS41JTtcbiAgbWFyZ2luLWxlZnQ6IDY0JTtcbn1cblxuLmxvZ2luVGV4dCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgbWFyZ2luLXRvcDogMS41JTtcbiAgbWFyZ2luLWxlZnQ6IDc1JTtcbn1cblxuLm1hdHRvb2wge1xuICBoZWlnaHQ6IDMwcHg7XG4gIG1hcmdpbi1sZWZ0OiAzMDBweDtcbiAgd2lkdGg6IDQ1MHB4O1xuICBhbGlnbi1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG59XG5cbi5pbnB1dCB7XG4gIGhlaWdodDogMjBweDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi1sZWZ0OiAzNTBweDtcbiAgbWFyZ2luLXRvcDogMnB4O1xufVxuXG4ubXlzZWFyY2gge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgbWFyZ2luLWxlZnQ6IDMwMHB4O1xufVxuXG5zcGFuIHtcbiAgbWFyZ2luLWxlZnQ6IDI1MHB4O1xufVxuXG4uY2FydCB7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbiAgcGFkZGluZy1yaWdodDogNSU7XG4gIGJhY2tncm91bmQtY29sb3I6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGNvbG9yOiBhbGljZWJsdWU7XG4gIG1hcmdpbi1yaWdodDogMyU7XG59XG5cbi5sb2dpbiB7XG4gIG1hcmdpbi1sZWZ0OiA2JTtcbiAgYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbn1cblxuLnByb2ZpbGUge1xuICBtYXJnaW4tbGVmdDogOHB4O1xufVxuXG46Om5nLWRlZXAgLnByb2ZpbGVtZW51IHtcbiAgd2lkdGg6IDMwMHB4O1xuICBoZWlnaHQ6IDM0MHB4O1xufVxuXG4ubWF0LWhlYWRsaW5lLFxuLm1hdC1zdWJoZWFkaW5nLTEge1xuICBtYXJnaW4tdG9wOiA1MCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMHB4O1xuICBtYXJnaW46IDBweDtcbn1cblxuLnNpZ251cCxcbi5sb2cge1xuICB3aWR0aDogNTAlO1xufVxuLnNpZ251cCA6aG92ZXIsXG4ubG9nIDpob3ZlciB7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG59XG5cbi5maWxldXBsb2FkYnRuIHtcbiAgd2lkdGg6IDBweDtcbiAgaGVpZ2h0OiAwcHg7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcbn1cblxuLmljb24ge1xuICBjb2xvcjogYmxhY2s7XG4gIG1hcmdpbi1sZWZ0OiAtNzlweDtcbn1cblxuLnBpYyB7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGNvbG9yOiBicm93bjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3JkZXI6IDFweCByZWQgc29saWQ7XG4gIG1hcmdpbi10b3A6IC0xMnB4O1xufVxuXG4udXBsb2FkLWltZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLWxlZnQ6IDUwJTtcbiAgcGFkZGluZy10b3A6IDEzJTtcbn1cblxuLmVkaXRidXR0b24ge1xuICBjb2xvcjogYmxhY2s7XG4gIGxlZnQ6IDI1JTtcbiAgd2lkdGg6IDUwJTtcbn1cblxuLmRpdmZvb3RlciB7XG4gIHdpZHRoOiAxMzY2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlMmUyZTI7XG4gIG9wYWNpdHk6IDE7XG59XG5cbi5tYXRmb290ZXIge1xuICBoZWlnaHQ6IDU1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNiMzNiM2I7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gIHBhZGRpbmctbGVmdDogMTclO1xuICBwYWRkaW5nLXRvcDogMnB4O1xufVxuXG4uc3Bhbi5zbWFsbCB7XG4gIGZvbnQtc2l6ZTogNXB4O1xufVxuXG4ubWF0LWJhZGdlLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgY29sb3I6ICNhMDMwMzc7XG59XG5cbi5zZWFyY2gge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi50b29sIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgdG9wOiAwO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHotaW5kZXg6IDEwMDtcbn1cblxuLnRpdGxlVGV4dCB7XG4gIG1hcmdpbi1sZWZ0OiA2JTtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tcmlnaHQ6IDMlO1xufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC50aXRsZVRleHQge1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBtYXJnaW4tbGVmdDogLTIlO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzIwcHgpIHtcbiAgLnNlYXJjaC1tYXQtY2FyZCB7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIHdpZHRoOiAzMHB4O1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5jYXJ0IHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAyNXB4O1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5tYXQtaWNvbiB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5zZWFyY2hJbnB1dCB7XG4gICAgbWFyZ2luLWxlZnQ6IC0xNXB4O1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC5zZWFyY2hJY29uIHtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAzcHg7XG4gIH1cbn1cbi5zZWFyY2hJY29uIHtcbiAgb3BhY2l0eTogMC41O1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5zZWFyY2hJY29uOmhvdmVyIHtcbiAgb3BhY2l0eTogMTtcbn1cblxuLnNlYXJjaElucHV0IHtcbiAgaGVpZ2h0OiA1MCU7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LWZhbWlseTogXCJUaW1lcyBOZXcgUm9tYW5cIiwgVGltZXMsIHNlcmlmO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGNvbG9yOiBkaW1ncmV5O1xufVxuXG4uc2VhcmNoLW1hdC1jYXJkIHtcbiAgbWFyZ2luLWxlZnQ6IC0zJTtcbiAgd2lkdGg6IDUwJTtcbiAgaGVpZ2h0OiA1NCU7XG4gIHBhZGRpbmc6IDBweDtcbn1cblxuYnV0dG9uIHtcbiAgb3V0bGluZTogbm9uZTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.ts ***!
  \*************************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm2015/dialog.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login/login.component */ "./src/app/components/login/login.component.ts");
/* harmony import */ var _edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../edit-profile/edit-profile.component */ "./src/app/components/edit-profile/edit-profile.component.ts");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var src_services_admin_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/services/admin.service */ "./src/services/admin.service.ts");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");









let DashboardComponent = class DashboardComponent {
    constructor(userService, router, dialog, Adminservice, messageService) {
        this.userService = userService;
        this.router = router;
        this.dialog = dialog;
        this.Adminservice = Adminservice;
        this.messageService = messageService;
        this.isProfile = 'true';
        this.profile = './assets/images/user.png';
        if (localStorage.getItem('token') === null) {
            this.login = false;
            this.profile = './assets/images/user.png';
        }
        else {
            this.login = true;
            this.username = localStorage.getItem('name');
            this.usermail = localStorage.getItem('email');
            if (localStorage.getItem('image') === 'null') {
                this.profile = './assets/images/user.png';
            }
            else {
                this.profile = localStorage.getItem('image');
            }
        }
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
        this.mySubscription = this.router.events.subscribe((event) => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                this.router.navigated = false;
            }
        });
    }
    ngOnInit() {
        this.messageService.onCartCount();
        if (localStorage.getItem('cartSize') !== null && localStorage.getItem('token') === null) {
            this.cartCounter = Number(localStorage.getItem('cartSize'));
        }
        else if (localStorage.getItem('token') !== null) {
            this.messageService.cartCountMessage.subscribe((data) => {
                this.cartCount(data);
            });
        }
        this.messageService.onGetAllBooks();
        this.messageService.cartBooks();
    }
    cartCount(data) {
        if (data.status === 200) {
            this.cartCounter = data.data;
        }
    }
    openDialogztoedit() {
        this.dialog.open(_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_5__["EditProfileComponent"]);
    }
    openDialog() {
        localStorage.setItem('popup', 'false');
        const dialogConfig = new _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogConfig"]();
        dialogConfig.height = '75%';
        this.dialog.open(_login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"], {
            panelClass: 'custom-modalbox',
        });
    }
    onKey(event) {
        this.messageService.searchUserBook(event);
        this.isCart = false;
    }
    onCart() {
        this.messageService.onCartRefresh();
    }
    onSuccess() {
        this.isSuccess = true;
        this.router.navigate(['/dashboard/successPage']);
    }
    onBookStore() {
        this.isCart = false;
        this.router.navigate(['/dashboard/getallbooks']);
    }
    onLogin() {
        this.router.navigate(['/login']);
    }
    onsignup() {
        this.router.navigate(['/register']);
    }
    Logout() {
        this.Adminservice.logout().subscribe();
        localStorage.clear();
        this.router.navigate(['/dashboard']);
    }
    OnSelectedFile(event) {
        if (event.target.files.length > 0) {
            this.file = event.target.files[0];
            const formData = new FormData();
            formData.append('file', this.file);
            this.file.inProgress = true;
            this.userService
                .uploadProfie(formData, this.isProfile)
                .subscribe((result) => {
                if (result.status === 200) {
                    localStorage.setItem('image', result.data);
                    this.profile = result.data;
                }
            });
        }
    }
    AddToCart(count) {
        this.cartCounter = count;
    }
    myorders() {
        console.log('my orders');
        this.router.navigate(['/myorders']);
    }
    mywishlist() {
        this.router.navigate(['viewallWishList']);
    }
};
DashboardComponent.ctorParameters = () => [
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] },
    { type: src_services_admin_service__WEBPACK_IMPORTED_MODULE_7__["AdminService"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_8__["MessageService"] }
];
DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-dashboard',
        template: __webpack_require__(/*! raw-loader!./dashboard.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/dashboard/dashboard.component.html"),
        styles: [__webpack_require__(/*! ./dashboard.component.scss */ "./src/app/components/dashboard/dashboard.component.scss")]
    })
], DashboardComponent);



/***/ }),

/***/ "./src/app/components/display-books/display-books.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/components/display-books/display-books.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "mat-card {\n  margin-top: 20px;\n  width: 200px;\n  padding: 0%;\n}\n\nmat-card:hover {\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n}\n\n.bookImageDiv {\n  background-color: #f5f5f5;\n}\n\nimg {\n  padding: 10%;\n  width: 140px;\n  height: 160px;\n}\n\n.bookInfoDiv {\n  padding: 4% 10% 10% 10%;\n}\n\n.span-title {\n  font-size: small;\n  font-weight: 500;\n  font-family: sans-serif;\n}\n\n.span-author {\n  font-size: xx-small;\n  font-weight: lighter;\n  font-family: sans-serif;\n}\n\n.span-price {\n  font-size: x-small;\n  font-weight: 500;\n  font-family: sans-serif;\n}\n\n.input-title {\n  font-size: small;\n  font-weight: 500;\n  border: none;\n  outline: none;\n}\n\n.input-author {\n  font-size: xx-small;\n  border: none;\n  outline: none;\n}\n\n.input-author-span {\n  font-size: xx-small;\n  border: none;\n  outline: none;\n}\n\n.input-price {\n  font-size: x-small;\n  font-weight: 500;\n  border: none;\n  outline: none;\n}\n\n.input-price-span {\n  font-size: x-small;\n  font-weight: 500;\n  border: none;\n  outline: none;\n}\n\n.approval-button {\n  height: 32px;\n  width: 70px;\n  font-size: x-small;\n  background-color: #a03037;\n  color: white;\n  padding: 0px;\n  margin-top: 3%;\n  border: none;\n  outline: none;\n}\n\n.delete-button {\n  height: 32px;\n  width: 70px;\n  font-size: x-small;\n  background-color: #a03037;\n  color: white;\n  padding: 0px;\n  margin-top: 3%;\n  border: none;\n  outline: none;\n}\n\n.sent-button {\n  height: 32px;\n  width: 70px;\n  font-size: x-small;\n  background-color: #3371b5;\n  color: white;\n  padding: 0px;\n  margin-top: 3%;\n  border: none;\n  outline: none;\n}\n\n.approved-button {\n  height: 32px;\n  width: 70px;\n  font-size: x-small;\n  background-color: #054927;\n  color: white;\n  padding: 0px;\n  margin-top: 3%;\n  border: none;\n  outline: none;\n}\n\n.book-details {\n  display: none;\n  position: absolute;\n}\n\nmat-card:hover + .book-details {\n  display: block;\n  margin-top: 2%;\n  position: absolute;\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n  width: 18%;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  background-color: whitesmoke;\n  margin-left: 12%;\n  z-index: 1;\n  padding: 2%;\n}\n\n.main-div {\n  width: 100%;\n  padding-top: 80px;\n  padding-left: 10%;\n  padding-right: 10%;\n  padding-bottom: 2%;\n}\n\n:host ::ng-deep .custom-spinner circle {\n  stroke: #a03037;\n  margin: 0 auto;\n}\n\n@media only screen and (min-width: 600px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 16%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 823px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 23%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 736px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 20%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 731px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 20%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 812px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 23%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 768px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 21%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 640px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 15%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (min-width: 3000) {\n  .main-div {\n    background-color: 0;\n    padding-left: 15%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    flex-flow: row wrap;\n    width: 100%;\n  }\n}\n\n.bookText {\n  font-size: 90%;\n  color: white;\n}\n\n.addBookButton {\n  color: white;\n  width: 15%;\n  background-color: #a03037;\n  outline: none;\n}\n\n.paginator {\n  padding-top: 4%;\n}\n\n.page-buttons {\n  outline: none;\n  background: #FFFFFF 0% 0% no-repeat padding-box;\n  border: 1px solid #E2E2E2;\n  opacity: 1;\n  color: black;\n  box-shadow: none;\n}\n\n.page-number {\n  height: 37px;\n  width: 37px;\n  border: none;\n  outline: none;\n  opacity: 0.5;\n  background-color: white;\n}\n\n.page-number:hover {\n  height: 37px;\n  width: 37px;\n  border: none;\n  outline: none;\n  opacity: 1;\n}\n\n.page-number:active {\n  height: 37px;\n  width: 37px;\n  border: none;\n  outline: none;\n  opacity: 1;\n  background-color: #8F2B2F;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9kaXNwbGF5LWJvb2tzL0M6XFxVc2Vyc1xca2FtYW5cXERlc2t0b3BcXGZpbmFsIHByb2plY3RzXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3RlclxcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXIvc3JjXFxhcHBcXGNvbXBvbmVudHNcXGRpc3BsYXktYm9va3NcXGRpc3BsYXktYm9va3MuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZGlzcGxheS1ib29rcy9kaXNwbGF5LWJvb2tzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQ0NGOztBRENBO0VBQ0Usa0ZBQUE7QUNFRjs7QURDQTtFQUNFLHlCQUFBO0FDRUY7O0FERUE7RUFDRSxZQUFBO0VBR0EsWUFBQTtFQUNBLGFBQUE7QUNERjs7QURHQTtFQUNFLHVCQUFBO0FDQUY7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUNDRjs7QURDQTtFQUNFLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtBQ0VGOztBREFBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FDR0Y7O0FEREE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNJRjs7QURGQTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNLRjs7QURIQTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNNRjs7QURKQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ09GOztBRExBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDUUY7O0FETkE7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1NGOztBRFBBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNVRjs7QURSQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDV0Y7O0FEVEE7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1lGOztBRFZBO0VBQ0UsYUFBQTtFQUNBLGtCQUFBO0FDYUY7O0FEWEE7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0ZBQUE7RUFHQSxVQUFBO0VBRUEsMkJBQUE7RUFBQSx3QkFBQTtFQUFBLG1CQUFBO0VBRUEsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FDVUY7O0FEUkE7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNXRjs7QURUQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDWUY7O0FEVkE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsV0FBQTtFQ2FGO0FBQ0Y7O0FEWEE7RUFDRTtJQUNFLG1CQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsbUJBQUE7SUFDQSxXQUFBO0VDYUY7QUFDRjs7QURYQTtFQUNFLGNBQUE7RUFDQSxZQUFBO0FDYUY7O0FEWEE7RUFDRSxZQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0VBRUEsYUFBQTtBQ2FGOztBRFZBO0VBQ0UsZUFBQTtBQ2FGOztBRFhBO0VBQ0UsYUFBQTtFQUNBLCtDQUFBO0VBQ0EseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDY0Y7O0FEWkE7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0FDZUY7O0FEYkE7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtBQ2dCRjs7QURkQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0EseUJBQUE7QUNpQkYiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2Rpc3BsYXktYm9va3MvZGlzcGxheS1ib29rcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIm1hdC1jYXJkIHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgd2lkdGg6IDIwMHB4O1xuICBwYWRkaW5nOiAwJTtcbn1cbm1hdC1jYXJkOmhvdmVyIHtcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSg3MCwgNzEsIDcwLCAwLjIpLFxuICAgIDAgNnB4IDIwcHggMCByZ2JhKDI5LCAyOSwgMjksIDAuMTkpO1xufVxuLmJvb2tJbWFnZURpdiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjU7XG59XG5tYXQtY2FyZC1kaXY6aG92ZXIge1xufVxuaW1nIHtcbiAgcGFkZGluZzogMTAlO1xuICAvLyAgIHdpZHRoOiA4MCU7XG4gIC8vICAgaGVpZ2h0OiAzMHZoO1xuICB3aWR0aDogMTQwcHg7XG4gIGhlaWdodDogMTYwcHg7XG59XG4uYm9va0luZm9EaXYge1xuICBwYWRkaW5nOiA0JSAxMCUgMTAlIDEwJTtcbn1cbi5zcGFuLXRpdGxlIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG4uc3Bhbi1hdXRob3Ige1xuICBmb250LXNpemU6IHh4LXNtYWxsO1xuICBmb250LXdlaWdodDogbGlnaHRlcjtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG4uc3Bhbi1wcmljZSB7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG4uaW5wdXQtdGl0bGUge1xuICBmb250LXNpemU6IHNtYWxsO1xuICBmb250LXdlaWdodDogNTAwO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uaW5wdXQtYXV0aG9yIHtcbiAgZm9udC1zaXplOiB4eC1zbWFsbDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuLmlucHV0LWF1dGhvci1zcGFuIHtcbiAgZm9udC1zaXplOiB4eC1zbWFsbDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuLmlucHV0LXByaWNlIHtcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xuICBmb250LXdlaWdodDogNTAwO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uaW5wdXQtcHJpY2Utc3BhbiB7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuLmFwcHJvdmFsLWJ1dHRvbiB7XG4gIGhlaWdodDogMzJweDtcbiAgd2lkdGg6IDcwcHg7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAwcHg7XG4gIG1hcmdpbi10b3A6IDMlO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uZGVsZXRlLWJ1dHRvbiB7XG4gIGhlaWdodDogMzJweDtcbiAgd2lkdGg6IDcwcHg7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAwcHg7XG4gIG1hcmdpbi10b3A6IDMlO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uc2VudC1idXR0b24ge1xuICBoZWlnaHQ6IDMycHg7XG4gIHdpZHRoOiA3MHB4O1xuICBmb250LXNpemU6IHgtc21hbGw7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzMzcxYjU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMHB4O1xuICBtYXJnaW4tdG9wOiAzJTtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuLmFwcHJvdmVkLWJ1dHRvbiB7XG4gIGhlaWdodDogMzJweDtcbiAgd2lkdGg6IDcwcHg7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzA1NDkyNztcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAwcHg7XG4gIG1hcmdpbi10b3A6IDMlO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uYm9vay1kZXRhaWxzIHtcbiAgZGlzcGxheTogbm9uZTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxubWF0LWNhcmQ6aG92ZXIgKyAuYm9vay1kZXRhaWxzIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi10b3A6IDIlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoNzAsIDcxLCA3MCwgMC4yKSxcbiAgICAwIDZweCAyMHB4IDAgcmdiYSgyOSwgMjksIDI5LCAwLjE5KTtcbiAgLy8gYWxpZ24tc2VsZjogY2VudGVyO1xuICB3aWR0aDogMTglO1xuICAvLyBtaW4taGVpZ2h0OiAxMDBweDtcbiAgaGVpZ2h0OiBmaXQtY29udGVudDtcbiAgLy8gbWFyZ2luLXRvcDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcbiAgbWFyZ2luLWxlZnQ6IDEyJTtcbiAgei1pbmRleDogMTtcbiAgcGFkZGluZzogMiU7XG59XG4ubWFpbi1kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy10b3A6IDgwcHg7XG4gIHBhZGRpbmctbGVmdDogMTAlO1xuICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gIHBhZGRpbmctYm90dG9tOiAyJTtcbn1cbjpob3N0IDo6bmctZGVlcCAuY3VzdG9tLXNwaW5uZXIgY2lyY2xlIHtcbiAgc3Ryb2tlOiAjYTAzMDM3O1xuICBtYXJnaW46IDAgYXV0bztcbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNjAwcHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbigkY29sb3I6ICMwMDAwMDApO1xuICAgIHBhZGRpbmctbGVmdDogMTYlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA4MjNweCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuKCRjb2xvcjogIzAwMDAwMCk7XG4gICAgcGFkZGluZy1sZWZ0OiAyMyU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDczNnB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW4oJGNvbG9yOiAjMDAwMDAwKTtcbiAgICBwYWRkaW5nLWxlZnQ6IDIwJTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogNzMxcHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbigkY29sb3I6ICMwMDAwMDApO1xuICAgIHBhZGRpbmctbGVmdDogMjAlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA4MTJweCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuKCRjb2xvcjogIzAwMDAwMCk7XG4gICAgcGFkZGluZy1sZWZ0OiAyMyU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDc2OHB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW4oJGNvbG9yOiAjMDAwMDAwKTtcbiAgICBwYWRkaW5nLWxlZnQ6IDIxJTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogNjQwcHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbigkY29sb3I6ICMwMDAwMDApO1xuICAgIHBhZGRpbmctbGVmdDogMTUlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMzAwMCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuKCRjb2xvcjogIzAwMDAwMCk7XG4gICAgcGFkZGluZy1sZWZ0OiAxNSU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICBmbGV4LWZsb3c6IHJvdyB3cmFwO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG4uYm9va1RleHQge1xuICBmb250LXNpemU6IDkwJTtcbiAgY29sb3I6IHdoaXRlO1xufVxuLmFkZEJvb2tCdXR0b24ge1xuICBjb2xvcjogd2hpdGU7XG4gIHdpZHRoOiAxNSU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNhMDMwMzc7XG4gIC8vIGJvcmRlci1yYWRpdXM6IDJ2dztcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLnBhZ2luYXRvcntcbiAgcGFkZGluZy10b3A6IDQlO1xufVxuLnBhZ2UtYnV0dG9uc3tcbiAgb3V0bGluZTogbm9uZTtcbiAgYmFja2dyb3VuZDogI0ZGRkZGRiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNFMkUyRTI7XG4gIG9wYWNpdHk6IDE7XG4gIGNvbG9yOiBibGFjaztcbiAgYm94LXNoYWRvdzogbm9uZTtcbn1cbi5wYWdlLW51bWJlcntcbiAgaGVpZ2h0OiAzN3B4O1xuICB3aWR0aDogMzdweDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xuICBvcGFjaXR5OiAwLjU7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xufVxuLnBhZ2UtbnVtYmVyOmhvdmVye1xuICBoZWlnaHQ6IDM3cHg7XG4gIHdpZHRoOiAzN3B4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG4gIG9wYWNpdHk6IDE7XG59XG4ucGFnZS1udW1iZXI6YWN0aXZle1xuICBoZWlnaHQ6IDM3cHg7XG4gIHdpZHRoOiAzN3B4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG4gIG9wYWNpdHk6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6ICM4RjJCMkYgO1xufSIsIm1hdC1jYXJkIHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgd2lkdGg6IDIwMHB4O1xuICBwYWRkaW5nOiAwJTtcbn1cblxubWF0LWNhcmQ6aG92ZXIge1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDcwLCA3MSwgNzAsIDAuMiksIDAgNnB4IDIwcHggMCByZ2JhKDI5LCAyOSwgMjksIDAuMTkpO1xufVxuXG4uYm9va0ltYWdlRGl2IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbn1cblxuaW1nIHtcbiAgcGFkZGluZzogMTAlO1xuICB3aWR0aDogMTQwcHg7XG4gIGhlaWdodDogMTYwcHg7XG59XG5cbi5ib29rSW5mb0RpdiB7XG4gIHBhZGRpbmc6IDQlIDEwJSAxMCUgMTAlO1xufVxuXG4uc3Bhbi10aXRsZSB7XG4gIGZvbnQtc2l6ZTogc21hbGw7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufVxuXG4uc3Bhbi1hdXRob3Ige1xuICBmb250LXNpemU6IHh4LXNtYWxsO1xuICBmb250LXdlaWdodDogbGlnaHRlcjtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG5cbi5zcGFuLXByaWNlIHtcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbn1cblxuLmlucHV0LXRpdGxlIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uaW5wdXQtYXV0aG9yIHtcbiAgZm9udC1zaXplOiB4eC1zbWFsbDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uaW5wdXQtYXV0aG9yLXNwYW4ge1xuICBmb250LXNpemU6IHh4LXNtYWxsO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbi5pbnB1dC1wcmljZSB7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uaW5wdXQtcHJpY2Utc3BhbiB7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uYXBwcm92YWwtYnV0dG9uIHtcbiAgaGVpZ2h0OiAzMnB4O1xuICB3aWR0aDogNzBweDtcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTAzMDM3O1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDBweDtcbiAgbWFyZ2luLXRvcDogMyU7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLmRlbGV0ZS1idXR0b24ge1xuICBoZWlnaHQ6IDMycHg7XG4gIHdpZHRoOiA3MHB4O1xuICBmb250LXNpemU6IHgtc21hbGw7XG4gIGJhY2tncm91bmQtY29sb3I6ICNhMDMwMzc7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMHB4O1xuICBtYXJnaW4tdG9wOiAzJTtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uc2VudC1idXR0b24ge1xuICBoZWlnaHQ6IDMycHg7XG4gIHdpZHRoOiA3MHB4O1xuICBmb250LXNpemU6IHgtc21hbGw7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzMzcxYjU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMHB4O1xuICBtYXJnaW4tdG9wOiAzJTtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uYXBwcm92ZWQtYnV0dG9uIHtcbiAgaGVpZ2h0OiAzMnB4O1xuICB3aWR0aDogNzBweDtcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDU0OTI3O1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDBweDtcbiAgbWFyZ2luLXRvcDogMyU7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLmJvb2stZGV0YWlscyB7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cblxubWF0LWNhcmQ6aG92ZXIgKyAuYm9vay1kZXRhaWxzIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi10b3A6IDIlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoNzAsIDcxLCA3MCwgMC4yKSwgMCA2cHggMjBweCAwIHJnYmEoMjksIDI5LCAyOSwgMC4xOSk7XG4gIHdpZHRoOiAxOCU7XG4gIGhlaWdodDogZml0LWNvbnRlbnQ7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlc21va2U7XG4gIG1hcmdpbi1sZWZ0OiAxMiU7XG4gIHotaW5kZXg6IDE7XG4gIHBhZGRpbmc6IDIlO1xufVxuXG4ubWFpbi1kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy10b3A6IDgwcHg7XG4gIHBhZGRpbmctbGVmdDogMTAlO1xuICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gIHBhZGRpbmctYm90dG9tOiAyJTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5jdXN0b20tc3Bpbm5lciBjaXJjbGUge1xuICBzdHJva2U6ICNhMDMwMzc7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDYwMHB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE2JTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogODIzcHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAwO1xuICAgIHBhZGRpbmctbGVmdDogMjMlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA3MzZweCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAyMCU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDczMXB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDIwJTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogODEycHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAwO1xuICAgIHBhZGRpbmctbGVmdDogMjMlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA3NjhweCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAyMSU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDY0MHB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE1JTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDMwMDApIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAwO1xuICAgIHBhZGRpbmctbGVmdDogMTUlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgZmxleC1mbG93OiByb3cgd3JhcDtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuLmJvb2tUZXh0IHtcbiAgZm9udC1zaXplOiA5MCU7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmFkZEJvb2tCdXR0b24ge1xuICBjb2xvcjogd2hpdGU7XG4gIHdpZHRoOiAxNSU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNhMDMwMzc7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbi5wYWdpbmF0b3Ige1xuICBwYWRkaW5nLXRvcDogNCU7XG59XG5cbi5wYWdlLWJ1dHRvbnMge1xuICBvdXRsaW5lOiBub25lO1xuICBiYWNrZ3JvdW5kOiAjRkZGRkZGIDAlIDAlIG5vLXJlcGVhdCBwYWRkaW5nLWJveDtcbiAgYm9yZGVyOiAxcHggc29saWQgI0UyRTJFMjtcbiAgb3BhY2l0eTogMTtcbiAgY29sb3I6IGJsYWNrO1xuICBib3gtc2hhZG93OiBub25lO1xufVxuXG4ucGFnZS1udW1iZXIge1xuICBoZWlnaHQ6IDM3cHg7XG4gIHdpZHRoOiAzN3B4O1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG4gIG9wYWNpdHk6IDAuNTtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG59XG5cbi5wYWdlLW51bWJlcjpob3ZlciB7XG4gIGhlaWdodDogMzdweDtcbiAgd2lkdGg6IDM3cHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgb3BhY2l0eTogMTtcbn1cblxuLnBhZ2UtbnVtYmVyOmFjdGl2ZSB7XG4gIGhlaWdodDogMzdweDtcbiAgd2lkdGg6IDM3cHg7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgb3BhY2l0eTogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzhGMkIyRjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/display-books/display-books.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/display-books/display-books.component.ts ***!
  \*********************************************************************/
/*! exports provided: DisplayBooksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DisplayBooksComponent", function() { return DisplayBooksComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_vendor_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/vendor.service */ "./src/services/vendor.service.ts");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _update_book_update_book_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../update-book/update-book.component */ "./src/app/components/update-book/update-book.component.ts");
/* harmony import */ var _add_book_add_book_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../add-book/add-book.component */ "./src/app/components/add-book/add-book.component.ts");







let DisplayBooksComponent = class DisplayBooksComponent {
    constructor(vendorService, messageService, snackBar, dialog) {
        this.vendorService = vendorService;
        this.messageService = messageService;
        this.snackBar = snackBar;
        this.dialog = dialog;
        this.books = [];
        this.pages = [];
        this.pageSize = 8;
    }
    ngOnInit() {
        this.messageService.booksCountMessage.subscribe((data) => {
            this.totalBooks = 0;
            this.onBooksCount(data);
        });
    }
    onBooksCount(data) {
        console.log(data);
        if (data.status === 200) {
            console.log(data.data);
            this.totalBooks = data.data;
        }
        this.messageService.currentMessage.subscribe((data) => {
            this.books = [];
            this.onDisplayBooks(data);
        });
    }
    onBookDetail(event) {
        event.stopPropagation();
    }
    onUpdateBookForm(book) {
        this.dialog.open(_update_book_update_book_component__WEBPACK_IMPORTED_MODULE_5__["UpdateBookComponent"], {
            width: '600px',
            data: book,
            panelClass: 'custom-modalbox',
        });
    }
    openBookForm() {
        this.dialog.open(_add_book_add_book_component__WEBPACK_IMPORTED_MODULE_6__["AddBookComponent"], {
            panelClass: 'custom-modalbox',
        });
    }
    onDisplayBooks(data) {
        if (data.status === 200) {
            data.data.forEach((bookData) => {
                this.books.push(bookData);
            });
            this.pages = [];
            this.totalPages = parseInt((this.totalBooks / this.pageSize).toFixed(), 10);
            if (this.totalBooks > (this.totalPages * this.pageSize)) {
                this.totalPages = this.totalPages + 1;
            }
            for (let i = 1; i <= this.totalPages; i++) {
                this.pages.push(i);
            }
            console.log(this.pages);
            this.snackBar.open(data.message, 'ok', {
                duration: 2000,
            });
        }
    }
    onDeleteBook(bookId) {
        console.log(bookId);
        this.vendorService.deleteBooks(bookId).subscribe((data) => {
            if (data.status === 200) {
                this.messageService.onBooksCount();
                if (localStorage.getItem('pageNum') === null) {
                    this.pageNum = 1;
                }
                else {
                    this.pageNum = Number(localStorage.getItem('pageNum'));
                }
                this.messageService.onBooksCount();
                this.messageService.changeMessage(this.pageNum);
                this.snackBar.open(data.message, 'ok', {
                    duration: 2000,
                });
            }
        }, (error) => {
            this.snackBar.open(error.error, 'ok', { duration: 2000 });
        });
    }
    onApproval(bookId) {
        this.vendorService.onApprove(bookId).subscribe((data) => {
            if (data.status === 200) {
                this.messageService.onBooksCount();
                this.messageService.changeMessage(1);
                this.snackBar.open(data.message, 'ok', {
                    duration: 2000,
                });
            }
        }, (error) => {
            this.snackBar.open(error.message, 'ok', {
                duration: 2000,
            });
        });
    }
    onBooksByPage(page) {
        this.messageService.changeMessage(page);
        localStorage.setItem('pageNum', page);
    }
};
DisplayBooksComponent.ctorParameters = () => [
    { type: src_services_vendor_service__WEBPACK_IMPORTED_MODULE_2__["VendorService"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_3__["MessageService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatDialog"] }
];
DisplayBooksComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-display-books',
        template: __webpack_require__(/*! raw-loader!./display-books.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/display-books/display-books.component.html"),
        styles: [__webpack_require__(/*! ./display-books.component.scss */ "./src/app/components/display-books/display-books.component.scss")]
    })
], DisplayBooksComponent);



/***/ }),

/***/ "./src/app/components/edit-profile/edit-profile.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/edit-profile/edit-profile.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".imagediv, .img {\n  height: 100px;\n  width: 100px;\n  top: 2%;\n}\n\n.input-field {\n  outline: none;\n  border: none;\n  width: 100%;\n}\n\n.emailfield {\n  pointer-events: none;\n  outline: none;\n  border: none;\n  color: rgba(0, 0, 0, 0.5);\n}\n\n.buttons {\n  float: right;\n  margin-top: 5%;\n}\n\n.custom-dialog-container .mat-dialog {\n  padding: 0px none;\n  border: 1px red solid;\n}\n\nh6 {\n  background-color: maroon;\n  color: white;\n  font-weight: normal;\n  text-align: center;\n}\n\n.fileuploadbtn {\n  visibility: hidden;\n  width: 0;\n  height: 0;\n  display: none;\n}\n\n/*::placeholder { \n    color: black;\n    opacity: 1;\n  }*/\n\n.matbutton {\n  outline: none;\n}\n\n.icon {\n  float: right;\n  margin-left: 20%;\n}\n\n.changetext {\n  border: 1px black solid;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9lZGl0LXByb2ZpbGUvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcZWRpdC1wcm9maWxlXFxlZGl0LXByb2ZpbGUuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZWRpdC1wcm9maWxlL2VkaXQtcHJvZmlsZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLGFBQUE7RUFDQSxZQUFBO0VBRUEsT0FBQTtBQ0RKOztBRElBO0VBRUksYUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDRko7O0FESUE7RUFFSSxvQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUNGSjs7QURLQTtFQUVFLFlBQUE7RUFDQSxjQUFBO0FDSEY7O0FES0E7RUFFSSxpQkFBQTtFQUNBLHFCQUFBO0FDSEo7O0FES0E7RUFDSSx3QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDRko7O0FESUE7RUFFSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtBQ0ZKOztBRElBOzs7SUFBQTs7QUFJQTtFQUVJLGFBQUE7QUNGSjs7QURJQTtFQUVJLFlBQUE7RUFDQSxnQkFBQTtBQ0ZKOztBRElBO0VBR0ksdUJBQUE7QUNISiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZWRpdC1wcm9maWxlL2VkaXQtcHJvZmlsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbWFnZWRpdiwuaW1nXG57XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgLy9sZWZ0OiAyMCU7XG4gICAgdG9wOiAyJTtcbiAgICAvL3Bvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5pbnB1dC1maWVsZFxue1xuICAgIG91dGxpbmU6bm9uZTtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgd2lkdGg6IDEwMCU7XG59XG4uZW1haWxmaWVsZFxue1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIG91dGxpbmU6IG5vbmU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIFxufVxuLmJ1dHRvbnNcbntcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiA1JTtcbn1cbi5jdXN0b20tZGlhbG9nLWNvbnRhaW5lciAubWF0LWRpYWxvZ1xue1xuICAgIHBhZGRpbmc6IDBweCBub25lO1xuICAgIGJvcmRlcjogMXB4IHJlZCBzb2xpZDtcbn1cbmg2e1xuICAgIGJhY2tncm91bmQtY29sb3I6IG1hcm9vbjtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uZmlsZXVwbG9hZGJ0blxue1xuICAgIHZpc2liaWxpdHk6aGlkZGVuO1xuICAgIHdpZHRoOjA7XG4gICAgaGVpZ2h0OjA7XG4gICAgZGlzcGxheTogbm9uZTtcbn1cbi8qOjpwbGFjZWhvbGRlciB7IFxuICAgIGNvbG9yOiBibGFjaztcbiAgICBvcGFjaXR5OiAxO1xuICB9Ki9cbi5tYXRidXR0b25cbntcbiAgICBvdXRsaW5lOiBub25lO1xufVxuLmljb25cbntcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgbWFyZ2luLWxlZnQ6IDIwJTtcbn1cbi5jaGFuZ2V0ZXh0XG57XG4gICAgLy9jb2xvcjogcmVkO1xuICAgIGJvcmRlcjogMXB4IGJsYWNrIHNvbGlkO1xufSIsIi5pbWFnZWRpdiwgLmltZyB7XG4gIGhlaWdodDogMTAwcHg7XG4gIHdpZHRoOiAxMDBweDtcbiAgdG9wOiAyJTtcbn1cblxuLmlucHV0LWZpZWxkIHtcbiAgb3V0bGluZTogbm9uZTtcbiAgYm9yZGVyOiBub25lO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmVtYWlsZmllbGQge1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgYm9yZGVyOiBub25lO1xuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjUpO1xufVxuXG4uYnV0dG9ucyB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogNSU7XG59XG5cbi5jdXN0b20tZGlhbG9nLWNvbnRhaW5lciAubWF0LWRpYWxvZyB7XG4gIHBhZGRpbmc6IDBweCBub25lO1xuICBib3JkZXI6IDFweCByZWQgc29saWQ7XG59XG5cbmg2IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogbWFyb29uO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmZpbGV1cGxvYWRidG4ge1xuICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gIHdpZHRoOiAwO1xuICBoZWlnaHQ6IDA7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi8qOjpwbGFjZWhvbGRlciB7IFxuICAgIGNvbG9yOiBibGFjaztcbiAgICBvcGFjaXR5OiAxO1xuICB9Ki9cbi5tYXRidXR0b24ge1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uaWNvbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLWxlZnQ6IDIwJTtcbn1cblxuLmNoYW5nZXRleHQge1xuICBib3JkZXI6IDFweCBibGFjayBzb2xpZDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/edit-profile/edit-profile.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/edit-profile/edit-profile.component.ts ***!
  \*******************************************************************/
/*! exports provided: EditProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditProfileComponent", function() { return EditProfileComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");




let EditProfileComponent = class EditProfileComponent {
    constructor(userService, snackBar) {
        this.userService = userService;
        this.snackBar = snackBar;
        this.hide = true;
        this.profile = localStorage.getItem('image');
        this.username = localStorage.getItem('username');
        this.password = "**********";
        this.editicon = true;
        this.passicon = false;
        this.isProfile = 'true';
        this.usermail = localStorage.getItem('email');
        this.fullname = localStorage.getItem('name');
        this.mobile = localStorage.getItem('mobile');
    }
    ngOnInit() { }
    update() {
        console.log('to update');
        console.log(this.fullname);
        console.log(this.password);
        let regExp = new RegExp('(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}');
        if (regExp.test(this.password)) {
            this.pass = this.password;
        }
        else
            this.pass = 'string';
        const data = {
            fullName: this.fullname,
            password: this.pass
        };
        console.log("regulae exp res:", regExp.test(this.password));
        console.log(data);
        this.userService.updateUser(data).subscribe((result) => {
            console.log(result);
            if (result.status === 200) {
                localStorage.setItem('name', data.fullName);
                this.snackBar.open(result.message, 'ok', { duration: 5000 });
            }
        }, (error) => {
            this.snackBar.open(error.error, 'ok', { duration: 5000 });
        });
    }
    changeIcon() {
        this.editicon = false;
        this.passicon = true;
        console.log("came to change icon");
    }
    OnSelectedFile(event) {
        console.log(event.target.files[0]);
        if (event.target.files.length > 0) {
            this.file = event.target.files[0];
            const formData = new FormData();
            formData.append('file', this.file);
            this.file.inProgress = true;
            console.log('FormData:', formData.get('file'));
            this.userService.uploadProfie(formData, this.isProfile).subscribe((result) => {
                console.log('PROFILE RESULT:', result);
                if (result.status === 200) {
                    localStorage.setItem('image', result.data);
                    this.profile = result.data;
                    console.log(this.profile);
                }
            });
        }
    }
};
EditProfileComponent.ctorParameters = () => [
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"] }
];
EditProfileComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit-profile',
        template: __webpack_require__(/*! raw-loader!./edit-profile.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/edit-profile/edit-profile.component.html"),
        styles: [__webpack_require__(/*! ./edit-profile.component.scss */ "./src/app/components/edit-profile/edit-profile.component.scss")]
    })
], EditProfileComponent);



/***/ }),

/***/ "./src/app/components/forgot-password/forgot-password.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/components/forgot-password/forgot-password.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "button {\n  background-color: #b33b3b;\n}\n\n.container {\n  width: 100%;\n  height: 100%;\n}\n\nmat-card {\n  overflow: hidden;\n  width: 40%;\n}\n\n.mat-card:not([class*=mat-elevation-z]) {\n  box-shadow: 0 2px 1px -1px black, 0 1px 1px 0 black, 0 1px 3px 0 black;\n}\n\nmat-toolbar {\n  background-color: #b33b3b;\n  justify-content: center;\n  margin-bottom: 5%;\n}\n\nbutton {\n  width: 40%;\n}\n\nmat-card-actions {\n  margin-bottom: 0px;\n}\n\nmat-card.lg {\n  display: flex;\n  justify-content: space-evenly;\n  width: 60%;\n  height: 50%;\n  font-size: larger;\n}\n\nmat-toolbar.lg {\n  height: 25%;\n  margin-bottom: 0px;\n}\n\n.mat-dialog-content {\n  padding: 0;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9mb3Jnb3QtcGFzc3dvcmQvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcZm9yZ290LXBhc3N3b3JkXFxmb3Jnb3QtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZm9yZ290LXBhc3N3b3JkL2ZvcmdvdC1wYXNzd29yZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0VKOztBREFBO0VBQ0ksZ0JBQUE7RUFDQSxVQUFBO0FDR0o7O0FEREE7RUFDSSxzRUFBQTtBQ0lKOztBREFBO0VBRUkseUJBQUE7RUFLQSx1QkFBQTtFQUNBLGlCQUFBO0FDRko7O0FES0E7RUFDSSxVQUFBO0FDRko7O0FET0E7RUFDSSxrQkFBQTtBQ0pKOztBRE9BO0VBRUksYUFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQ0xKOztBRE9BO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0FDSko7O0FETUE7RUFFSSxVQUFBO0VBQ0EsU0FBQTtBQ0pKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9mb3Jnb3QtcGFzc3dvcmQvZm9yZ290LXBhc3N3b3JkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYnV0dG9ue1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigxNzksIDU5LCA1OSk7XG59XG4uY29udGFpbmVyIHsgXG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxubWF0LWNhcmR7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICB3aWR0aDogNDAlO1xufVxuLm1hdC1jYXJkOm5vdChbY2xhc3MqPW1hdC1lbGV2YXRpb24tel0pIHtcbiAgICBib3gtc2hhZG93OiAwIDJweCAxcHggLTFweCByZ2JhKDAsMCwwLDEpLCBcbiAgICAgICAgICAgICAgICAwIDFweCAxcHggMCByZ2JhKDAsMCwwLDEpLCBcbiAgICAgICAgICAgICAgICAwIDFweCAzcHggMCByZ2JhKDAsMCwwLDEpO1xufVxubWF0LXRvb2xiYXJ7XG4gICAgLy8gdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICByZ2IoMTc5LCA1OSwgNTkpIDtcbi8vICAgICBoZWlnaHQ6IDI1JTtcbi8vICAgICBib3gtc2l6aW5nOiBjb250ZW50LWJveDtcbi8vICAgICBtYXgtaGVpZ2h0OiA1JSAhaW1wb3J0YW50OyBcbi8vICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbmJ1dHRvbntcbiAgICB3aWR0aDogNDAlO1xufVxuLy8gLm1hdC1jYXJkLXRpdGxle1xuLy8gICAgIC8vIGhlaWdodDogNTAlO1xuLy8gfVxubWF0LWNhcmQtYWN0aW9uc3tcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbm1hdC1jYXJkLmxne1xuICAgIC8vIGJhY2tncm91bmQtY29sb3I6IHJnYigxMTIsIDExMCwgMTEwKTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICAgIHdpZHRoOiA2MCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgZm9udC1zaXplOiBsYXJnZXI7XG59XG5tYXQtdG9vbGJhci5sZ3tcbiAgICBoZWlnaHQ6IDI1JTtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG4ubWF0LWRpYWxvZy1jb250ZW50XG57XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW46IDA7XG59IiwiYnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2IzM2IzYjtcbn1cblxuLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbm1hdC1jYXJkIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLm1hdC1jYXJkOm5vdChbY2xhc3MqPW1hdC1lbGV2YXRpb24tel0pIHtcbiAgYm94LXNoYWRvdzogMCAycHggMXB4IC0xcHggYmxhY2ssIDAgMXB4IDFweCAwIGJsYWNrLCAwIDFweCAzcHggMCBibGFjaztcbn1cblxubWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYjMzYjNiO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogNSU7XG59XG5cbmJ1dHRvbiB7XG4gIHdpZHRoOiA0MCU7XG59XG5cbm1hdC1jYXJkLWFjdGlvbnMge1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbm1hdC1jYXJkLmxnIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XG4gIHdpZHRoOiA2MCU7XG4gIGhlaWdodDogNTAlO1xuICBmb250LXNpemU6IGxhcmdlcjtcbn1cblxubWF0LXRvb2xiYXIubGcge1xuICBoZWlnaHQ6IDI1JTtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4ubWF0LWRpYWxvZy1jb250ZW50IHtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luOiAwO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/forgot-password/forgot-password.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/forgot-password/forgot-password.component.ts ***!
  \*************************************************************************/
/*! exports provided: ForgotPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordComponent", function() { return ForgotPasswordComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");






let ForgotPasswordComponent = class ForgotPasswordComponent {
    constructor(userService, snackBar, router) {
        this.userService = userService;
        this.snackBar = snackBar;
        this.router = router;
        this.forgotPasswordForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            emailId: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email])
        });
    }
    get emailId() {
        return this.forgotPasswordForm.get('emailId');
    }
    ngOnInit() {
    }
    onSubmit() {
        console.log(this.forgotPasswordForm.value);
        this.userService.forgotPassword(this.emailId.value).subscribe((response) => {
            console.log(response);
            if (response.status === 201) {
                console.log('Verifivation link send to your mailid,please your check mail');
                this.snackBar.open(response.message, 'ok', { duration: 5000 });
                console.log(response.object);
                // localStorage.setItem('forgotoken', response.object);
                //this.router.navigate(['resetpassword/:token'])
            }
        }, (error) => {
            console.log(error);
            if (error.status === 401) {
                this.snackBar.open(error.error.error, 'ok', { duration: 2000 });
            }
        });
    }
};
ForgotPasswordComponent.ctorParameters = () => [
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
ForgotPasswordComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-forgot-password',
        template: __webpack_require__(/*! raw-loader!./forgot-password.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/forgot-password/forgot-password.component.html"),
        styles: [__webpack_require__(/*! ./forgot-password.component.scss */ "./src/app/components/forgot-password/forgot-password.component.scss")]
    })
], ForgotPasswordComponent);



/***/ }),

/***/ "./src/app/components/get-all-sellers/get-all-sellers.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/components/get-all-sellers/get-all-sellers.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  font-family: arial, sans-serif;\n  border-collapse: collapse;\n  table-layout: fixed;\n}\n\ntd, th {\n  text-align: center;\n  padding: 8px;\n}\n\ntd {\n  text-align: left;\n  padding: 8px;\n}\n\nspan {\n  word-wrap: break-word;\n  -webkit-hyphens: auto;\n  -ms-hyphens: auto;\n  -o-hyphens: auto;\n  hyphens: auto;\n}\n\n@media only screen and (max-width: 450px) {\n  table {\n    font-size: xx-small;\n  }\n\n  .contactButton {\n    padding: 5px;\n    padding-left: 0.5%;\n    margin-left: 0.5%;\n  }\n}\n\n@media only screen and (max-width: 350px) {\n  .contact {\n    padding-left: 0.2%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9nZXQtYWxsLXNlbGxlcnMvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcZ2V0LWFsbC1zZWxsZXJzXFxnZXQtYWxsLXNlbGxlcnMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZ2V0LWFsbC1zZWxsZXJzL2dldC1hbGwtc2VsbGVycy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNJLDhCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQ0RKOztBRElFO0VBRUUsa0JBQUE7RUFDQSxZQUFBO0FDRko7O0FES0U7RUFFRSxnQkFBQTtFQUNBLFlBQUE7QUNISjs7QURTRTtFQUNFLHFCQUFBO0VBQ0EscUJBQUE7RUFFQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBQ05KOztBRFFFO0VBQ0U7SUFDRSxtQkFBQTtFQ0xKOztFRFVFO0lBQ0UsWUFBQTtJQUNBLGtCQUFBO0lBQ0EsaUJBQUE7RUNQSjtBQUNGOztBRFVFO0VBQ0U7SUFDRSxrQkFBQTtFQ1JKO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2dldC1hbGwtc2VsbGVycy9nZXQtYWxsLXNlbGxlcnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcblxudGFibGUge1xuICAgIGZvbnQtZmFtaWx5OiBhcmlhbCwgc2Fucy1zZXJpZjtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIHRhYmxlLWxheW91dDogZml4ZWQ7XG4gIH1cbiAgXG4gIHRkLCB0aCB7XG4gICAgLy9ib3JkZXI6IDFweCBzb2xpZCAjMjkyODI4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiA4cHg7XG4gICAgIFxuICB9XG4gIHRkIHtcbiAgICAvL2JvcmRlcjogMXB4IHNvbGlkICMyOTI4Mjg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgXG4gIHRyOm50aC1jaGlsZChldmVuKSB7XG4gICAgLy9iYWNrZ3JvdW5kLWNvbG9yOiAjZGRkZGRkO1xuICB9XG4gIHNwYW57XG4gICAgd29yZC13cmFwOiBicmVhay13b3JkO1xuICAgIC13ZWJraXQtaHlwaGVuczogYXV0bztcbiAgICAtbW96LWh5cGhlbnM6IGF1dG87XG4gICAgLW1zLWh5cGhlbnM6IGF1dG87XG4gICAgLW8taHlwaGVuczogYXV0bztcbiAgICBoeXBoZW5zOiBhdXRvO1xufVxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQ1MHB4KSB7XG4gICAgdGFibGV7XG4gICAgICBmb250LXNpemU6IHh4LXNtYWxsO1xuICAgIH1cbiAgICAuY29udGFjdHtcbiAgICAgIC8vcGFkZGluZy1sZWZ0OiAwLjIlO1xuICAgIH1cbiAgICAuY29udGFjdEJ1dHRvbntcbiAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgIHBhZGRpbmctbGVmdDogMC41JTtcbiAgICAgIG1hcmdpbi1sZWZ0OiAwLjUlO1xuICAgIH1cbiAgfVxuXG4gIEBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzUwcHgpIHtcbiAgICAuY29udGFjdHtcbiAgICAgIHBhZGRpbmctbGVmdDogMC4yJTtcbiAgICB9XG4gIH0iLCJ0YWJsZSB7XG4gIGZvbnQtZmFtaWx5OiBhcmlhbCwgc2Fucy1zZXJpZjtcbiAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcbiAgdGFibGUtbGF5b3V0OiBmaXhlZDtcbn1cblxudGQsIHRoIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA4cHg7XG59XG5cbnRkIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZzogOHB4O1xufVxuXG5zcGFuIHtcbiAgd29yZC13cmFwOiBicmVhay13b3JkO1xuICAtd2Via2l0LWh5cGhlbnM6IGF1dG87XG4gIC1tb3otaHlwaGVuczogYXV0bztcbiAgLW1zLWh5cGhlbnM6IGF1dG87XG4gIC1vLWh5cGhlbnM6IGF1dG87XG4gIGh5cGhlbnM6IGF1dG87XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcbiAgdGFibGUge1xuICAgIGZvbnQtc2l6ZTogeHgtc21hbGw7XG4gIH1cblxuICAuY29udGFjdEJ1dHRvbiB7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMC41JTtcbiAgICBtYXJnaW4tbGVmdDogMC41JTtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNTBweCkge1xuICAuY29udGFjdCB7XG4gICAgcGFkZGluZy1sZWZ0OiAwLjIlO1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/components/get-all-sellers/get-all-sellers.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/get-all-sellers/get-all-sellers.component.ts ***!
  \*************************************************************************/
/*! exports provided: GetAllSellersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetAllSellersComponent", function() { return GetAllSellersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");




let GetAllSellersComponent = class GetAllSellersComponent {
    constructor(messageService, snackBar) {
        this.messageService = messageService;
        this.snackBar = snackBar;
        this.profile = './assets/images/user.png';
        this.users = [];
        this.counter = 0;
        this.found = false;
    }
    ngOnInit() {
        this.messageService.adminSeller.subscribe((data) => {
            this.users = [];
            this.onGetSellers(data);
        });
    }
    onGetSellers(data) {
        if (data.status === 200) {
            data.data.forEach((userData) => {
                this.users.push(userData);
                this.found = true;
            });
            this.snackBar.open(data.message, 'ok', {
                duration: 2000,
            });
        }
    }
    onLink(user) {
        localStorage.setItem('sellerId', user.id);
    }
};
GetAllSellersComponent.ctorParameters = () => [
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_3__["MessageService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSnackBar"] }
];
GetAllSellersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-get-all-sellers',
        template: __webpack_require__(/*! raw-loader!./get-all-sellers.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/get-all-sellers/get-all-sellers.component.html"),
        styles: [__webpack_require__(/*! ./get-all-sellers.component.scss */ "./src/app/components/get-all-sellers/get-all-sellers.component.scss")]
    })
], GetAllSellersComponent);



/***/ }),

/***/ "./src/app/components/get-books-for-verification/get-books-for-verification.component.scss":
/*!*************************************************************************************************!*\
  !*** ./src/app/components/get-books-for-verification/get-books-for-verification.component.scss ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-div {\n  width: 100%;\n  padding-left: 10%;\n  padding-right: 10%;\n  padding-bottom: 2%;\n}\n\nmat-card {\n  margin-top: 20px;\n  margin-left: 15px;\n  width: 200px;\n  padding: 0;\n}\n\nmat-card:hover {\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n}\n\n.bookImageDiv {\n  background-color: whitesmoke;\n}\n\nimg {\n  padding: 10%;\n  width: 140px;\n  height: 160px;\n}\n\n.bookInfoDiv {\n  padding: 4% 10% 10%;\n}\n\n.span-title {\n  font-size: small;\n  font-weight: 500;\n  font-family: sans-serif;\n}\n\n.span-author {\n  font-size: xx-small;\n  font-weight: lighter;\n  font-family: sans-serif;\n}\n\n.span-price {\n  font-size: x-small;\n  font-weight: 500;\n  font-family: sans-serif;\n}\n\n.input-title {\n  height: 24px;\n  font-size: small;\n  font-weight: 500;\n  border: none;\n  outline: none;\n}\n\n.input-author {\n  height: 20px;\n  font-size: xx-small;\n  border: none;\n  outline: none;\n}\n\n.input-author-span {\n  padding-left: 1%;\n  height: 20px;\n  font-size: xx-small;\n  border: none;\n  outline: none;\n}\n\n.input-price {\n  height: 20px;\n  font-size: x-small;\n  font-weight: 500;\n  border: none;\n  outline: none;\n}\n\n.input-price-span {\n  padding-left: 1%;\n  height: 20px;\n  font-size: x-small;\n  font-weight: 500;\n  border: none;\n  outline: none;\n}\n\nbutton {\n  height: 32px;\n  width: 70px;\n  font-size: x-small;\n  background-color: brown;\n  color: white;\n  padding: 0;\n  margin-top: 3%;\n  border: none;\n  outline: none;\n}\n\n.book-details {\n  display: none;\n  position: absolute;\n}\n\nmat-card:hover + .book-details {\n  display: block;\n  margin-top: 2%;\n  position: absolute;\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n  width: 18%;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  background-color: whitesmoke;\n  margin-left: 12%;\n  z-index: 1;\n  padding: 2%;\n}\n\n@media only screen and (width: 823px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 23%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 812px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 23%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 768px) {\n  .main-div {\n    width: 100%;\n    padding-left: 17%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    flex-flow: row wrap;\n    box-sizing: border-box;\n    display: flex;\n    place-content: center flex-start;\n    align-items: center;\n  }\n}\n\n@media only screen and (width: 736px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 20%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 731px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 20%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 640px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 15%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n\n@media only screen and (width: 1024px) {\n  .main-div {\n    background-color: 0;\n    padding-left: 15%;\n    padding-right: 10%;\n    padding-bottom: 2%;\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9nZXQtYm9va3MtZm9yLXZlcmlmaWNhdGlvbi9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxnZXQtYm9va3MtZm9yLXZlcmlmaWNhdGlvblxcZ2V0LWJvb2tzLWZvci12ZXJpZmljYXRpb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZ2V0LWJvb2tzLWZvci12ZXJpZmljYXRpb24vZ2V0LWJvb2tzLWZvci12ZXJpZmljYXRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDQUo7O0FER0E7RUFDSSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUNBSjs7QURFQTtFQUNJLGtGQUFBO0FDQ0o7O0FEQ0E7RUFDSSw0QkFBQTtBQ0VKOztBREFBO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDR0o7O0FEREE7RUFDSSxtQkFBQTtBQ0lKOztBREZBO0VBQ0ksZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FDS0o7O0FESEE7RUFDSSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7QUNNSjs7QURKQTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ09KOztBRExBO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1FKOztBRE5BO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNTSjs7QURQQTtFQUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNVSjs7QURSQTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNXSjs7QURUQTtFQUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1lKOztBRFZBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUVBLGFBQUE7QUNZSjs7QURWQTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQ2FKOztBRFhBO0VBQ0ksY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtGQUFBO0VBR0EsVUFBQTtFQUVBLDJCQUFBO0VBQUEsd0JBQUE7RUFBQSxtQkFBQTtFQUVBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQ1VKOztBRFBBO0VBQ0k7SUFDSSxtQkFBQTtJQUNBLGlCQUFBO0lBQ0Esa0JBQUE7SUFDQSxrQkFBQTtJQUNBLFdBQUE7RUNVTjtBQUNGOztBRFJBO0VBQ0k7SUFDSSxtQkFBQTtJQUNBLGlCQUFBO0lBQ0Esa0JBQUE7SUFDQSxrQkFBQTtJQUNBLFdBQUE7RUNVTjtBQUNGOztBRFJBO0VBQ0k7SUFFSSxXQUFBO0lBQ0EsaUJBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsbUJBQUE7SUFDQSxzQkFBQTtJQUNBLGFBQUE7SUFDQSxnQ0FBQTtJQUNBLG1CQUFBO0VDU047QUFDRjs7QUROQTtFQUNJO0lBQ0ksbUJBQUE7SUFDQSxpQkFBQTtJQUNBLGtCQUFBO0lBQ0Esa0JBQUE7SUFDQSxXQUFBO0VDUU47QUFDRjs7QUROQTtFQUNJO0lBQ0ksbUJBQUE7SUFDQSxpQkFBQTtJQUNBLGtCQUFBO0lBQ0Esa0JBQUE7SUFDQSxXQUFBO0VDUU47QUFDRjs7QUROQTtFQUNJO0lBQ0ksbUJBQUE7SUFDQSxpQkFBQTtJQUNBLGtCQUFBO0lBQ0Esa0JBQUE7SUFDQSxXQUFBO0VDUU47QUFDRjs7QUROQTtFQUNJO0lBQ0ksbUJBQUE7SUFDQSxpQkFBQTtJQUNBLGtCQUFBO0lBQ0Esa0JBQUE7SUFDQSxXQUFBO0VDUU47QUFDRiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZ2V0LWJvb2tzLWZvci12ZXJpZmljYXRpb24vZ2V0LWJvb2tzLWZvci12ZXJpZmljYXRpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5tYWluLWRpdiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxMCU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbn1cblxubWF0LWNhcmQge1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgd2lkdGg6IDIwMHB4O1xuICAgIHBhZGRpbmc6IDA7XG59XG5tYXQtY2FyZDpob3ZlciB7XG4gICAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSg3MCwgNzEsIDcwLCAwLjIpLCAwIDZweCAyMHB4IDAgcmdiYSgyOSwgMjksIDI5LCAwLjE5KTtcbn1cbi5ib29rSW1hZ2VEaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlc21va2U7XG59XG5pbWcge1xuICAgIHBhZGRpbmc6IDEwJTtcbiAgICB3aWR0aDogMTQwcHg7XG4gICAgaGVpZ2h0OiAxNjBweDtcbn1cbi5ib29rSW5mb0RpdiB7XG4gICAgcGFkZGluZzogNCUgMTAlIDEwJTtcbn1cbi5zcGFuLXRpdGxlIHtcbiAgICBmb250LXNpemU6IHNtYWxsO1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG4uc3Bhbi1hdXRob3Ige1xuICAgIGZvbnQtc2l6ZTogeHgtc21hbGw7XG4gICAgZm9udC13ZWlnaHQ6IGxpZ2h0ZXI7XG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG4uc3Bhbi1wcmljZSB7XG4gICAgZm9udC1zaXplOiB4LXNtYWxsO1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG4uaW5wdXQtdGl0bGUge1xuICAgIGhlaWdodDogMjRweDtcbiAgICBmb250LXNpemU6IHNtYWxsO1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIG91dGxpbmU6IG5vbmU7XG59XG4uaW5wdXQtYXV0aG9yIHtcbiAgICBoZWlnaHQ6IDIwcHg7XG4gICAgZm9udC1zaXplOiB4eC1zbWFsbDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgb3V0bGluZTogbm9uZTtcbn1cbi5pbnB1dC1hdXRob3Itc3BhbiB7XG4gICAgcGFkZGluZy1sZWZ0OiAxJTtcbiAgICBoZWlnaHQ6IDIwcHg7XG4gICAgZm9udC1zaXplOiB4eC1zbWFsbDtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgb3V0bGluZTogbm9uZTtcbn1cbi5pbnB1dC1wcmljZSB7XG4gICAgaGVpZ2h0OiAyMHB4O1xuICAgIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICBvdXRsaW5lOiBub25lO1xufVxuLmlucHV0LXByaWNlLXNwYW4ge1xuICAgIHBhZGRpbmctbGVmdDogMSU7XG4gICAgaGVpZ2h0OiAyMHB4O1xuICAgIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICBvdXRsaW5lOiBub25lO1xufVxuYnV0dG9uIHtcbiAgICBoZWlnaHQ6IDMycHg7XG4gICAgd2lkdGg6IDcwcHg7XG4gICAgZm9udC1zaXplOiB4LXNtYWxsO1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nOiAwO1xuICAgIG1hcmdpbi10b3A6IDMlO1xuICAgIGJvcmRlcjogbm9uZTtcblxuICAgIG91dGxpbmU6IG5vbmU7XG59XG4uYm9vay1kZXRhaWxzIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cbm1hdC1jYXJkOmhvdmVyICsgLmJvb2stZGV0YWlscyB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgbWFyZ2luLXRvcDogMiU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoNzAsIDcxLCA3MCwgMC4yKSxcbiAgICAgIDAgNnB4IDIwcHggMCByZ2JhKDI5LCAyOSwgMjksIDAuMTkpO1xuICAgIC8vIGFsaWduLXNlbGY6IGNlbnRlcjtcbiAgICB3aWR0aDogMTglO1xuICAgIC8vIG1pbi1oZWlnaHQ6IDEwMHB4O1xuICAgIGhlaWdodDogZml0LWNvbnRlbnQ7XG4gICAgLy8gbWFyZ2luLXRvcDogMTBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xuICAgIG1hcmdpbi1sZWZ0OiAxMiU7XG4gICAgei1pbmRleDogMTtcbiAgICBwYWRkaW5nOiAyJTtcbiAgfVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogODIzcHgpIHtcbiAgICAubWFpbi1kaXYge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbigkY29sb3I6ICMwMDAwMDApO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDIzJTtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA4MTJweCkge1xuICAgIC5tYWluLWRpdiB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuKCRjb2xvcjogIzAwMDAwMCk7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMjMlO1xuICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDc2OHB4KSB7XG4gICAgLm1haW4tZGl2IHtcblxuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxNyU7XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgICAgICBmbGV4LWZsb3c6IHJvdyB3cmFwO1xuICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBwbGFjZS1jb250ZW50OiBjZW50ZXIgZmxleC1zdGFydDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA3MzZweCkge1xuICAgIC5tYWluLWRpdiB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuKCRjb2xvcjogIzAwMDAwMCk7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMjAlO1xuICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDczMXB4KSB7XG4gICAgLm1haW4tZGl2IHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW4oJGNvbG9yOiAjMDAwMDAwKTtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAyMCU7XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogNjQwcHgpIHtcbiAgICAubWFpbi1kaXYge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbigkY29sb3I6ICMwMDAwMDApO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDE1JTtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiAxMDI0cHgpIHtcbiAgICAubWFpbi1kaXYge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbigkY29sb3I6ICMwMDAwMDApO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDE1JTtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgIH1cbn1cbiIsIi5tYWluLWRpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWxlZnQ6IDEwJTtcbiAgcGFkZGluZy1yaWdodDogMTAlO1xuICBwYWRkaW5nLWJvdHRvbTogMiU7XG59XG5cbm1hdC1jYXJkIHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gIHdpZHRoOiAyMDBweDtcbiAgcGFkZGluZzogMDtcbn1cblxubWF0LWNhcmQ6aG92ZXIge1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDcwLCA3MSwgNzAsIDAuMiksIDAgNnB4IDIwcHggMCByZ2JhKDI5LCAyOSwgMjksIDAuMTkpO1xufVxuXG4uYm9va0ltYWdlRGl2IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcbn1cblxuaW1nIHtcbiAgcGFkZGluZzogMTAlO1xuICB3aWR0aDogMTQwcHg7XG4gIGhlaWdodDogMTYwcHg7XG59XG5cbi5ib29rSW5mb0RpdiB7XG4gIHBhZGRpbmc6IDQlIDEwJSAxMCU7XG59XG5cbi5zcGFuLXRpdGxlIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG5cbi5zcGFuLWF1dGhvciB7XG4gIGZvbnQtc2l6ZTogeHgtc21hbGw7XG4gIGZvbnQtd2VpZ2h0OiBsaWdodGVyO1xuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbn1cblxuLnNwYW4tcHJpY2Uge1xuICBmb250LXNpemU6IHgtc21hbGw7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufVxuXG4uaW5wdXQtdGl0bGUge1xuICBoZWlnaHQ6IDI0cHg7XG4gIGZvbnQtc2l6ZTogc21hbGw7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLmlucHV0LWF1dGhvciB7XG4gIGhlaWdodDogMjBweDtcbiAgZm9udC1zaXplOiB4eC1zbWFsbDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uaW5wdXQtYXV0aG9yLXNwYW4ge1xuICBwYWRkaW5nLWxlZnQ6IDElO1xuICBoZWlnaHQ6IDIwcHg7XG4gIGZvbnQtc2l6ZTogeHgtc21hbGw7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLmlucHV0LXByaWNlIHtcbiAgaGVpZ2h0OiAyMHB4O1xuICBmb250LXNpemU6IHgtc21hbGw7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLmlucHV0LXByaWNlLXNwYW4ge1xuICBwYWRkaW5nLWxlZnQ6IDElO1xuICBoZWlnaHQ6IDIwcHg7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG5idXR0b24ge1xuICBoZWlnaHQ6IDMycHg7XG4gIHdpZHRoOiA3MHB4O1xuICBmb250LXNpemU6IHgtc21hbGw7XG4gIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbi10b3A6IDMlO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbi5ib29rLWRldGFpbHMge1xuICBkaXNwbGF5OiBub25lO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG5cbm1hdC1jYXJkOmhvdmVyICsgLmJvb2stZGV0YWlscyB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tdG9wOiAyJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDcwLCA3MSwgNzAsIDAuMiksIDAgNnB4IDIwcHggMCByZ2JhKDI5LCAyOSwgMjksIDAuMTkpO1xuICB3aWR0aDogMTglO1xuICBoZWlnaHQ6IGZpdC1jb250ZW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xuICBtYXJnaW4tbGVmdDogMTIlO1xuICB6LWluZGV4OiAxO1xuICBwYWRkaW5nOiAyJTtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDgyM3B4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDIzJTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogODEycHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAwO1xuICAgIHBhZGRpbmctbGVmdDogMjMlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA3NjhweCkge1xuICAubWFpbi1kaXYge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmctbGVmdDogMTclO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgZmxleC1mbG93OiByb3cgd3JhcDtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgcGxhY2UtY29udGVudDogY2VudGVyIGZsZXgtc3RhcnQ7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDczNnB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDIwJTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDIlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kICh3aWR0aDogNzMxcHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAwO1xuICAgIHBhZGRpbmctbGVmdDogMjAlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMiU7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKHdpZHRoOiA2NDBweCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxNSU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAod2lkdGg6IDEwMjRweCkge1xuICAubWFpbi1kaXYge1xuICAgIGJhY2tncm91bmQtY29sb3I6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxNSU7XG4gICAgcGFkZGluZy1yaWdodDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiAyJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/get-books-for-verification/get-books-for-verification.component.ts":
/*!***********************************************************************************************!*\
  !*** ./src/app/components/get-books-for-verification/get-books-for-verification.component.ts ***!
  \***********************************************************************************************/
/*! exports provided: GetBooksForVerificationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetBooksForVerificationComponent", function() { return GetBooksForVerificationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/admin.service */ "./src/services/admin.service.ts");
/* harmony import */ var _rejection_rejection_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../rejection/rejection.component */ "./src/app/components/rejection/rejection.component.ts");





let GetBooksForVerificationComponent = class GetBooksForVerificationComponent {
    constructor(service, snackBar, dialog) {
        this.service = service;
        this.snackBar = snackBar;
        this.dialog = dialog;
        this.click = [];
        this.verify = [];
        this.counter = 0;
    }
    ngOnInit() {
        this.service.getAllBooksForVerification().subscribe((data) => {
            this.books = data.data;
        });
    }
    onApprove(book) {
        this.service.verfy(book.bookId, localStorage.getItem('sellerId'), true).subscribe((data) => {
            this.snackBar.open(data.message, 'ok', { duration: 5000 });
            this.counter = book.bookId;
            this.click[book.bookId] = this.counter;
            this.verify[book.bookId] = 'true';
        });
    }
    onReject(book) {
        this.dialog.open(_rejection_rejection_component__WEBPACK_IMPORTED_MODULE_4__["RejectionComponent"], { width: '30%' });
        if (localStorage.getItem('reject') === 'reject') {
            this.service.verfy(book.bookId, localStorage.getItem('sellerId'), false).subscribe((data) => {
                this.snackBar.open(data.message, 'ok', { duration: 5000 });
                this.counter = book.bookId;
                this.click[book.bookId] = this.counter;
                this.verify[book.bookId] = 'false';
            });
        }
    }
};
GetBooksForVerificationComponent.ctorParameters = () => [
    { type: src_services_admin_service__WEBPACK_IMPORTED_MODULE_3__["AdminService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSnackBar"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] }
];
GetBooksForVerificationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-get-books-for-verification',
        template: __webpack_require__(/*! raw-loader!./get-books-for-verification.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/get-books-for-verification/get-books-for-verification.component.html"),
        styles: [__webpack_require__(/*! ./get-books-for-verification.component.scss */ "./src/app/components/get-books-for-verification/get-books-for-verification.component.scss")]
    })
], GetBooksForVerificationComponent);



/***/ }),

/***/ "./src/app/components/getallbooks/getallbooks.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/components/getallbooks/getallbooks.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main-div {\n  margin-top: -23%;\n  float: left;\n  width: 25%;\n  padding: 0 10px;\n  padding-bottom: 27%;\n}\n\n.h6 {\n  font-size: 10px;\n  font-family: \"Times New Roman\", Times, serif;\n  font-style: normal;\n  margin-top: -2px;\n}\n\n#items1 {\n  margin-right: 73px;\n  display: flex;\n  align-items: center;\n  font-size: 15px;\n  margin-top: 30px;\n}\n\n.book-details {\n  display: none;\n  position: absolute;\n}\n\nmat-card:hover + .book-details {\n  display: block;\n  margin-top: 2%;\n  font-size: 13px;\n  color: black;\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n  width: 15%;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  background-color: white;\n  margin-left: 200px;\n  z-index: 1;\n  text-align: left;\n  padding: 1%;\n}\n\n#items {\n  margin-left: -2px;\n  font-size: 22px;\n  letter-spacing: 0px;\n  font-weight: bold;\n  font-style: normal;\n  color: black;\n  font-family: \"Times New Roman\", Times, serif;\n  margin-bottom: -60px;\n}\n\n@media only screen and (max-width: 720px) {\n  #items {\n    margin-left: -3px;\n    font-size: 16px;\n    margin-right: 2px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  #items1 {\n    margin-right: 6px;\n    font-size: 12px;\n  }\n}\n\n@media only screen and (max-width: 720px) {\n  .mat-form-field {\n    width: 90px;\n    margin-top: 10px;\n  }\n}\n\n#active {\n  color: darkgray;\n  font-size: 15px;\n  font-weight: 10px;\n}\n\n#left {\n  float: right;\n  height: -10px;\n  width: 15%;\n  margin-top: -367px;\n  margin-right: -14%;\n  border-color: white;\n}\n\n.row {\n  width: 100%;\n  padding-left: 10%;\n  padding-right: 10%;\n  padding-bottom: 2%;\n}\n\n@media screen and (max-width: 600px) {\n  .main-div {\n    width: 50%;\n    display: block;\n    margin-bottom: 20px;\n  }\n}\n\n.mat-card {\n  margin-top: 3%;\n  width: 220px;\n  padding: 0%;\n  margin-bottom: 15px;\n}\n\n.mat-card:hover {\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n}\n\n.mat-card-title {\n  font-size: 14px;\n}\n\n.mat-card-subtitle {\n  font-size: 11px;\n}\n\n.price {\n  font-size: 12px;\n  color: black;\n  font-weight: bold;\n  margin-top: -10px;\n}\n\n.bookImageDiv {\n  background-color: #f0e9e9;\n}\n\n.a {\n  line-height: normal;\n}\n\nimg {\n  padding: 10%;\n  width: 140px;\n  height: 160px;\n}\n\n.bookInfoDiv {\n  padding: 7% 10% 10% 10%;\n}\n\n.mat-raised-button {\n  margin-left: -6px;\n  font-weight: 100;\n  font-size: 10px;\n  padding-bottom: 30px;\n  height: 18px;\n  width: 80px;\n  background-color: #a03037;\n  color: white;\n  text-align: center;\n  display: inline-block;\n}\n\n.mat-stroked-button {\n  margin-left: 20px;\n  font-weight: 100;\n  font-size: 10px;\n  padding-bottom: 30px;\n  height: 18px;\n  width: 78px;\n  background-color: whitesmoke;\n  color: black;\n  text-align: center;\n  display: inline-block;\n}\n\n.whole-div {\n  width: 100%;\n  margin-top: 4%;\n  padding-left: 10%;\n  padding-right: 10%;\n  padding-bottom: 2%;\n}\n\n.centered {\n  position: absolute;\n  top: 25%;\n  left: 50%;\n  height: 32px;\n  transform: translate(-50%, -50%);\n  background-color: white;\n  opacity: 0.9;\n  width: 180px;\n  box-shadow: 0 4px 8px 0 rgba(70, 71, 70, 0.2), 0 6px 20px 0 rgba(29, 29, 29, 0.19);\n}\n\n.text {\n  color: black;\n  font-size: 13px;\n  font-weight: 550;\n  text-align: center;\n  margin-top: 7px;\n  font-family: Georgia, \"Times New Roman\", Times, serif;\n  font-style: normal;\n}\n\n.paginator {\n  left: 0;\n  bottom: 0;\n  width: 100%;\n  background-color: red;\n  color: white;\n  text-align: center;\n  margin-left: -500px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9nZXRhbGxib29rcy9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxnZXRhbGxib29rc1xcZ2V0YWxsYm9va3MuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZ2V0YWxsYm9va3MvZ2V0YWxsYm9va3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0EsNENBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FESUE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0RGOztBREdBO0VBQ0UsYUFBQTtFQUNBLGtCQUFBO0FDQUY7O0FERUE7RUFDRSxjQUFBO0VBQ0MsY0FBQTtFQUNELGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0ZBQUE7RUFFRSxVQUFBO0VBQ0YsMkJBQUE7RUFBQSx3QkFBQTtFQUFBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7QUNBRjs7QURHQTtFQUNFLGlCQUFBO0VBQ0QsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSw0Q0FBQTtFQUNBLG9CQUFBO0FDQUQ7O0FER0E7RUFDRTtJQUNFLGlCQUFBO0lBQ0EsZUFBQTtJQUNBLGlCQUFBO0VDQUY7QUFDRjs7QURFQTtFQUNFO0lBQ0UsaUJBQUE7SUFDQSxlQUFBO0VDQUY7QUFDRjs7QURFQTtFQUNBO0lBQ0UsV0FBQTtJQUNBLGdCQUFBO0VDQUE7QUFDRjs7QURNQTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNKRjs7QURPQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0pGOztBRE9BO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0pGOztBRGFBO0VBQ0U7SUFDRSxVQUFBO0lBQ0EsY0FBQTtJQUNBLG1CQUFBO0VDVkY7QUFDRjs7QURhQTtFQUNFLGNBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FDWEY7O0FEYUE7RUFDRSxrRkFBQTtBQ1ZGOztBRGNBO0VBQ0UsZUFBQTtBQ1hGOztBRGFBO0VBQ0UsZUFBQTtBQ1ZGOztBRGFBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FDVkY7O0FEYUE7RUFDRSx5QkFBQTtBQ1ZGOztBRGFBO0VBQ0UsbUJBQUE7QUNWRjs7QURhQTtFQUNFLFlBQUE7RUFHQSxZQUFBO0VBQ0EsYUFBQTtBQ1pGOztBRGNBO0VBQ0UsdUJBQUE7QUNYRjs7QURjQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNYRjs7QURjQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNYRjs7QURjQTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDWEY7O0FEZ0JBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxnQ0FBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNDLFlBQUE7RUFDQSxrRkFBQTtBQ2JIOztBRGlCQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxxREFBQTtFQUNBLGtCQUFBO0FDZEY7O0FEaUJBO0VBQ0UsT0FBQTtFQUNELFNBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ2REIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9nZXRhbGxib29rcy9nZXRhbGxib29rcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluLWRpdiB7XG4gIG1hcmdpbi10b3A6IC0yMyU7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogMjUlO1xuICBwYWRkaW5nOiAwIDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAyNyU7XG59XG5cbi5oNntcbiAgZm9udC1zaXplOiAxMHB4O1xuICBmb250LWZhbWlseTogJ1RpbWVzIE5ldyBSb21hbicsIFRpbWVzLCBzZXJpZjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBtYXJnaW4tdG9wOiAtMnB4O1xufVxuXG5cblxuI2l0ZW1zMSB7XG4gIG1hcmdpbi1yaWdodDogNzNweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZm9udC1zaXplOiAgMTVweDtcbiAgbWFyZ2luLXRvcDogMzBweDtcbn1cbi5ib29rLWRldGFpbHMge1xuICBkaXNwbGF5OiBub25lO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG5tYXQtY2FyZDpob3ZlciArIC5ib29rLWRldGFpbHMge1xuICBkaXNwbGF5OiBibG9jaztcbiAgIG1hcmdpbi10b3A6IDIlO1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiBibGFjaztcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSg3MCwgNzEsIDcwLCAwLjIpLFxuICAgIDAgNnB4IDIwcHggMCByZ2JhKDI5LCAyOSwgMjksIDAuMTkpO1xuICAgIHdpZHRoOiAxNSU7XG4gIGhlaWdodDogZml0LWNvbnRlbnQ7XG4gIGJhY2tncm91bmQtY29sb3I6d2hpdGU7XG4gIG1hcmdpbi1sZWZ0OiAyMDBweDtcbiAgei1pbmRleDogMTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZzogMSU7XG59XG5cbiNpdGVtcyB7XG4gIG1hcmdpbi1sZWZ0OiAtMnB4O1xuIGZvbnQtc2l6ZToyMnB4O1xuIGxldHRlci1zcGFjaW5nOiAwcHg7XG4gZm9udC13ZWlnaHQ6IGJvbGQ7XG4gZm9udC1zdHlsZTogbm9ybWFsO1xuIGNvbG9yOiBibGFjaztcbiBmb250LWZhbWlseTogJ1RpbWVzIE5ldyBSb21hbicsIFRpbWVzLCBzZXJpZjtcbiBtYXJnaW4tYm90dG9tOiAtNjBweDtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAjaXRlbXN7XG4gICAgbWFyZ2luLWxlZnQ6LTNweDtcbiAgICBmb250LXNpemU6MTZweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDJweDtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAjaXRlbXMxe1xuICAgIG1hcmdpbi1yaWdodDogNnB4O1xuICAgIGZvbnQtc2l6ZTogIDEycHg7XG4gIH1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzIwcHgpIHtcbi5tYXQtZm9ybS1maWVsZHtcbiAgd2lkdGg6IDkwcHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG59XG5cblxuXG5cbiNhY3RpdmUge1xuICBjb2xvcjogZGFya2dyYXk7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDEwcHg7XG59XG5cbiNsZWZ0IHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBoZWlnaHQ6IC0xMHB4O1xuICB3aWR0aDogMTUlO1xuICBtYXJnaW4tdG9wOiAtMzY3cHg7XG4gIG1hcmdpbi1yaWdodDogLTE0JTtcbiAgYm9yZGVyLWNvbG9yOiB3aGl0ZTtcbn1cblxuLnJvdyB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWxlZnQ6IDEwJTtcbiAgcGFkZGluZy1yaWdodDogMTAlO1xuICBwYWRkaW5nLWJvdHRvbTogMiU7XG59XG5cbi8vIC5yb3c6YWZ0ZXIge1xuLy8gICBjb250ZW50OiAnJztcbi8vICAgZGlzcGxheTogdGFibGU7XG4vLyAgIGNsZWFyOiBib3RoO1xuLy8gfVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2MDBweCkge1xuICAubWFpbi1kaXYge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfVxufVxuXG4ubWF0LWNhcmQge1xuICBtYXJnaW4tdG9wOiAzJTtcbiAgd2lkdGg6IDIyMHB4O1xuICBwYWRkaW5nOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cbi5tYXQtY2FyZDpob3ZlciB7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoNzAsIDcxLCA3MCwgMC4yKSxcbiAgICAwIDZweCAyMHB4IDAgcmdiYSgyOSwgMjksIDI5LCAwLjE5KTtcbn1cblxuLm1hdC1jYXJkLXRpdGxlIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLm1hdC1jYXJkLXN1YnRpdGxlIHtcbiAgZm9udC1zaXplOiAxMXB4O1xufVxuXG4ucHJpY2Uge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG1hcmdpbi10b3A6IC0xMHB4O1xufVxuXG4uYm9va0ltYWdlRGl2IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI0MCwgMjMzLCAyMzMpO1xufVxuXG4uYSB7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG59XG5cbmltZyB7XG4gIHBhZGRpbmc6IDEwJTtcbiAgLy8gICB3aWR0aDogODAlO1xuICAvLyAgIGhlaWdodDogMzB2aDtcbiAgd2lkdGg6IDE0MHB4O1xuICBoZWlnaHQ6IDE2MHB4O1xufVxuLmJvb2tJbmZvRGl2IHtcbiAgcGFkZGluZzogNyUgMTAlIDEwJSAxMCU7XG59XG5cbi5tYXQtcmFpc2VkLWJ1dHRvbiB7XG4gIG1hcmdpbi1sZWZ0OiAtNnB4O1xuICBmb250LXdlaWdodDogMTAwO1xuICBmb250LXNpemU6IDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAzMHB4O1xuICBoZWlnaHQ6IDE4cHg7XG4gIHdpZHRoOiA4MHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTAzMDM3O1xuICBjb2xvcjogd2hpdGU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4ubWF0LXN0cm9rZWQtYnV0dG9uIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gIGhlaWdodDogMThweDtcbiAgd2lkdGg6IDc4cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlc21va2U7XG4gIGNvbG9yOiBibGFjaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLndob2xlLWRpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiA0JTtcbiAgcGFkZGluZy1sZWZ0OiAxMCU7XG4gIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgcGFkZGluZy1ib3R0b206IDIlO1xuICBcbn1cblxuXG4uY2VudGVyZWQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMjUlO1xuICBsZWZ0OiA1MCU7XG4gIGhlaWdodDogMzJweDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBvcGFjaXR5OiAwLjk7XG4gICB3aWR0aDogMTgwcHg7XG4gICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDcwLCA3MSwgNzAsIDAuMiksXG4gICAgMCA2cHggMjBweCAwIHJnYmEoMjksIDI5LCAyOSwgMC4xOSk7XG59XG5cbi50ZXh0e1xuICBjb2xvcjpibGFjaztcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNTUwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDdweDtcbiAgZm9udC1mYW1pbHk6IEdlb3JnaWEsICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbn1cblxuLnBhZ2luYXRvcntcbiAgbGVmdDogMDtcbiBib3R0b206IDA7XG4gd2lkdGg6IDEwMCU7XG4gYmFja2dyb3VuZC1jb2xvcjogcmVkO1xuIGNvbG9yOiB3aGl0ZTtcbiB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gbWFyZ2luLWxlZnQ6IC01MDBweDtcbn1cbiIsIi5tYWluLWRpdiB7XG4gIG1hcmdpbi10b3A6IC0yMyU7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogMjUlO1xuICBwYWRkaW5nOiAwIDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAyNyU7XG59XG5cbi5oNiB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgZm9udC1mYW1pbHk6IFwiVGltZXMgTmV3IFJvbWFuXCIsIFRpbWVzLCBzZXJpZjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBtYXJnaW4tdG9wOiAtMnB4O1xufVxuXG4jaXRlbXMxIHtcbiAgbWFyZ2luLXJpZ2h0OiA3M3B4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59XG5cbi5ib29rLWRldGFpbHMge1xuICBkaXNwbGF5OiBub25lO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG5cbm1hdC1jYXJkOmhvdmVyICsgLmJvb2stZGV0YWlscyB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tdG9wOiAyJTtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogYmxhY2s7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoNzAsIDcxLCA3MCwgMC4yKSwgMCA2cHggMjBweCAwIHJnYmEoMjksIDI5LCAyOSwgMC4xOSk7XG4gIHdpZHRoOiAxNSU7XG4gIGhlaWdodDogZml0LWNvbnRlbnQ7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tbGVmdDogMjAwcHg7XG4gIHotaW5kZXg6IDE7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmc6IDElO1xufVxuXG4jaXRlbXMge1xuICBtYXJnaW4tbGVmdDogLTJweDtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBsZXR0ZXItc3BhY2luZzogMHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtZmFtaWx5OiBcIlRpbWVzIE5ldyBSb21hblwiLCBUaW1lcywgc2VyaWY7XG4gIG1hcmdpbi1ib3R0b206IC02MHB4O1xufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gICNpdGVtcyB7XG4gICAgbWFyZ2luLWxlZnQ6IC0zcHg7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIG1hcmdpbi1yaWdodDogMnB4O1xuICB9XG59XG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gICNpdGVtczEge1xuICAgIG1hcmdpbi1yaWdodDogNnB4O1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgfVxufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAubWF0LWZvcm0tZmllbGQge1xuICAgIHdpZHRoOiA5MHB4O1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gIH1cbn1cbiNhY3RpdmUge1xuICBjb2xvcjogZGFya2dyYXk7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDEwcHg7XG59XG5cbiNsZWZ0IHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBoZWlnaHQ6IC0xMHB4O1xuICB3aWR0aDogMTUlO1xuICBtYXJnaW4tdG9wOiAtMzY3cHg7XG4gIG1hcmdpbi1yaWdodDogLTE0JTtcbiAgYm9yZGVyLWNvbG9yOiB3aGl0ZTtcbn1cblxuLnJvdyB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWxlZnQ6IDEwJTtcbiAgcGFkZGluZy1yaWdodDogMTAlO1xuICBwYWRkaW5nLWJvdHRvbTogMiU7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDYwMHB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgd2lkdGg6IDUwJTtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICB9XG59XG4ubWF0LWNhcmQge1xuICBtYXJnaW4tdG9wOiAzJTtcbiAgd2lkdGg6IDIyMHB4O1xuICBwYWRkaW5nOiAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cblxuLm1hdC1jYXJkOmhvdmVyIHtcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSg3MCwgNzEsIDcwLCAwLjIpLCAwIDZweCAyMHB4IDAgcmdiYSgyOSwgMjksIDI5LCAwLjE5KTtcbn1cblxuLm1hdC1jYXJkLXRpdGxlIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4ubWF0LWNhcmQtc3VidGl0bGUge1xuICBmb250LXNpemU6IDExcHg7XG59XG5cbi5wcmljZSB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLXRvcDogLTEwcHg7XG59XG5cbi5ib29rSW1hZ2VEaXYge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjBlOWU5O1xufVxuXG4uYSB7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG59XG5cbmltZyB7XG4gIHBhZGRpbmc6IDEwJTtcbiAgd2lkdGg6IDE0MHB4O1xuICBoZWlnaHQ6IDE2MHB4O1xufVxuXG4uYm9va0luZm9EaXYge1xuICBwYWRkaW5nOiA3JSAxMCUgMTAlIDEwJTtcbn1cblxuLm1hdC1yYWlzZWQtYnV0dG9uIHtcbiAgbWFyZ2luLWxlZnQ6IC02cHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gIGhlaWdodDogMThweDtcbiAgd2lkdGg6IDgwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNhMDMwMzc7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5tYXQtc3Ryb2tlZC1idXR0b24ge1xuICBtYXJnaW4tbGVmdDogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgZm9udC1zaXplOiAxMHB4O1xuICBwYWRkaW5nLWJvdHRvbTogMzBweDtcbiAgaGVpZ2h0OiAxOHB4O1xuICB3aWR0aDogNzhweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcbiAgY29sb3I6IGJsYWNrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLndob2xlLWRpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiA0JTtcbiAgcGFkZGluZy1sZWZ0OiAxMCU7XG4gIHBhZGRpbmctcmlnaHQ6IDEwJTtcbiAgcGFkZGluZy1ib3R0b206IDIlO1xufVxuXG4uY2VudGVyZWQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMjUlO1xuICBsZWZ0OiA1MCU7XG4gIGhlaWdodDogMzJweDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBvcGFjaXR5OiAwLjk7XG4gIHdpZHRoOiAxODBweDtcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSg3MCwgNzEsIDcwLCAwLjIpLCAwIDZweCAyMHB4IDAgcmdiYSgyOSwgMjksIDI5LCAwLjE5KTtcbn1cblxuLnRleHQge1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDU1MDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiA3cHg7XG4gIGZvbnQtZmFtaWx5OiBHZW9yZ2lhLCBcIlRpbWVzIE5ldyBSb21hblwiLCBUaW1lcywgc2VyaWY7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbn1cblxuLnBhZ2luYXRvciB7XG4gIGxlZnQ6IDA7XG4gIGJvdHRvbTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbiAgY29sb3I6IHdoaXRlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi1sZWZ0OiAtNTAwcHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/getallbooks/getallbooks.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/getallbooks/getallbooks.component.ts ***!
  \*****************************************************************/
/*! exports provided: GetallbooksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetallbooksComponent", function() { return GetallbooksComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_book_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/book.service */ "./src/services/book.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_cart_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/cart.service */ "./src/services/cart.service.ts");
/* harmony import */ var src_models_cart_book_cart_book_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/models/cart-book/cart-book.module */ "./src/models/cart-book/cart-book.module.ts");
/* harmony import */ var src_models_cart_cart_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/models/cart/cart.module */ "./src/models/cart/cart.module.ts");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var _view_wishlist_view_wishlist_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../view-wishlist/view-wishlist.component */ "./src/app/components/view-wishlist/view-wishlist.component.ts");









let GetallbooksComponent = class GetallbooksComponent {
    constructor(bookservice, snackBar, cartService, messageService, dialog) {
        this.bookservice = bookservice;
        this.snackBar = snackBar;
        this.cartService = cartService;
        this.messageService = messageService;
        this.dialog = dialog;
        this.books = [];
    }
    ngOnInit() {
        this.getItems();
        this.messageService.cartMessage.subscribe((data) => {
            this.displayBooksInCart(data);
        });
    }
    displayBooksInCart(data) {
        if (data.status === 200) {
            this.cart = data.data;
        }
        this.messageService.currentUserMessage.subscribe((data) => {
            this.books = [];
            this.loadAllBooks(data);
        });
    }
    getServerData(pageIndex) {
        this.messageService.sendByPage(pageIndex);
    }
    onChange(value) {
        if (value === 'high') {
            this.messageService.changeoptionMessage();
        }
        else {
            if (value === 'low') {
                this.messageService.changeoptionMessage1();
            }
        }
    }
    loadAllBooks(data) {
        if (data.status === 200) {
            data.data.forEach((bookData) => {
                this.books.push(bookData);
            });
            // this.snackBar.open(data.message, 'ok', {
            //   duration: 2000,
            // });
        }
    }
    getItems() {
        this.bookservice.getNumberOfItems().subscribe((data) => {
            this.countResult = data.data;
        });
    }
    checkAddedToCart(bookId) {
        let addedTocart = false;
        if (localStorage.getItem('cart') !== null) {
            this.cart = JSON.parse(localStorage.getItem('cart'));
            this.cart.cartBooks.forEach((element) => {
                if (element.book.bookId === bookId) {
                    addedTocart = true;
                }
            });
        }
        if (localStorage.getItem('token') !== null) {
            this.cart.cartBooks.forEach((element) => {
                if (element.book.bookId === bookId) {
                    addedTocart = true;
                }
            });
        }
        return addedTocart;
    }
    onAddBookToWishList(bookId) {
        this.bookservice.addToWishListBooks(bookId).subscribe((data) => {
            if (data.status === 200) {
                this.messageService.onGetAllBooks();
                this.snackBar.open(data.message, 'ok', {
                    duration: 2000,
                });
            }
        }, (error) => {
            this.snackBar.open(error.error, 'ok', { duration: 2000 });
        });
    }
    openDialog(book) {
        const dialogRef = this.dialog.open(_view_wishlist_view_wishlist_component__WEBPACK_IMPORTED_MODULE_8__["ViewWishlistComponent"], {
            width: '500px',
            data: {
                id: book.bookId,
                bookname: book.bookName,
                bookauthor: book.authorName,
                bookprice: book.price,
                bookinfo: book.description,
                bookImage: book.imageURL
            },
        });
    }
    addToCart(book) {
        if (localStorage.getItem('token') === null) {
            this.cartBook = new src_models_cart_book_cart_book_module__WEBPACK_IMPORTED_MODULE_5__["CartBookModule"]();
            this.cartBook.bookQuantity = 1;
            if (localStorage.getItem('cart') === null) {
                this.cart = new src_models_cart_cart_module__WEBPACK_IMPORTED_MODULE_6__["CartModule"]();
                this.cart.totalBooksInCart = 0;
            }
            else {
                this.cart = JSON.parse(localStorage.getItem('cart'));
            }
            if (this.cart.totalBooksInCart < 5) {
                this.cartBook.book = book;
                this.cartBook.totalBookPrice = Number(book.price);
                this.cart.cartBooks.forEach((element) => {
                    if (element.book.bookId === book.bookId) {
                        this.cart.cartBooks.splice(this.cart.cartBooks.indexOf(element), 1);
                        this.cart.totalBooksInCart--;
                        this.snackBar.open('Book Already Added to Cart', 'ok', {
                            duration: 2000,
                        });
                    }
                });
                this.cart.cartBooks.push(this.cartBook);
                this.cart.totalBooksInCart++;
                localStorage.setItem('cart', JSON.stringify(this.cart));
                this.snackBar.open('Book Added to Cart', 'ok', { duration: 2000 });
                localStorage.setItem('cartSize', String(this.cart.totalBooksInCart));
                this.messageService.onRefresh();
            }
            else {
                this.snackBar.open('Your Cart is full', 'ok', { duration: 2000 });
            }
        }
        else {
            this.cartService.addToCart(book.bookId).subscribe((data) => {
                if (data.status === 200) {
                    localStorage.setItem('cartSize', data.data.totalBooksInCart);
                    this.messageService.cartBooks();
                    this.messageService.onCartCount();
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
                else if (data.status === 208) {
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
            }, (error) => {
                if (error.status === 500) {
                    this.snackBar.open('Internal Server Error', 'ok', {
                        duration: 2000,
                    });
                }
                else {
                    this.snackBar.open(error.error.message, 'ok', {
                        duration: 2000,
                    });
                }
            });
        }
    }
};
GetallbooksComponent.ctorParameters = () => [
    { type: src_services_book_service__WEBPACK_IMPORTED_MODULE_2__["BookService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"] },
    { type: src_services_cart_service__WEBPACK_IMPORTED_MODULE_4__["CartServiceService"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_7__["MessageService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] }
];
GetallbooksComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-getallbooks',
        template: __webpack_require__(/*! raw-loader!./getallbooks.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/getallbooks/getallbooks.component.html"),
        styles: [__webpack_require__(/*! ./getallbooks.component.scss */ "./src/app/components/getallbooks/getallbooks.component.scss")]
    })
], GetallbooksComponent);



/***/ }),

/***/ "./src/app/components/getallwish-list/getallwish-list.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/components/getallwish-list/getallwish-list.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".row {\n  margin-bottom: -500px;\n}\n\n.price {\n  font-size: 12px;\n  color: #A03037;\n  font-weight: bold;\n  margin-left: -600px;\n}\n\n.title-left {\n  font-size: 15px;\n  margin-bottom: -50px;\n  font-weight: bolder;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n  color: whitesmoke;\n  margin-right: 520px;\n}\n\n.title-right {\n  font-size: 15px;\n  margin-bottom: -50px;\n  font-weight: lighter;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n  color: whitesmoke;\n}\n\n.mat-dialog-title {\n  font-size: 15px;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n}\n\n.span {\n  font-size: 18px;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n  font-weight: normal;\n  color: steelblue;\n}\n\n.author {\n  font-size: 12px;\n  color: black;\n  margin-left: -600px;\n  margin-top: 15px;\n  padding-bottom: 19px;\n}\n\n.info {\n  font-size: 12px;\n  color: black;\n  margin-left: -600px;\n  padding-bottom: 19px;\n}\n\n.name {\n  font-size: 16px;\n  color: black;\n  margin-top: -110px;\n  margin-left: -600px;\n  font-family: Arial, Helvetica, sans-serif;\n  font-style: normal;\n  font-weight: bold;\n}\n\n.bookImageDiv {\n  background-color: #f0e9e9;\n  width: 120px;\n  height: 130px;\n  margin-top: -35px;\n  margin-left: -50px;\n  margin-bottom: 100px;\n  border-radius: 15px;\n}\n\n.a {\n  line-height: normal;\n}\n\nimg {\n  padding: 3%;\n  width: 90px;\n  height: 90px;\n  margin-left: 15px;\n  margin-top: 20px;\n}\n\n.bookInfoDiv {\n  padding: 7% 10% 10% 10%;\n}\n\n.mat-raised-button {\n  font-weight: 100;\n  font-size: 13px;\n  padding-bottom: 30px;\n  height: 18px;\n  width: 112px;\n  background: #A03037;\n  color: whitesmoke;\n  text-align: center;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  margin-left: 28px;\n}\n\n.mat-stroked-button {\n  font-weight: 100;\n  font-size: 13px;\n  padding-bottom: 30px;\n  height: 18px;\n  width: 128px;\n  background: khaki;\n  color: black;\n  text-align: center;\n  margin-top: -20px;\n  margin-bottom: 10px;\n  margin-left: 20px;\n}\n\n.title-center {\n  flex: 1 1 auto;\n  text-align: center;\n}\n\n.mat-icon {\n  margin-bottom: -48px;\n  margin-right: 5px;\n  color: whitesmoke;\n}\n\n.mat-toolbar {\n  background-color: #A03037;\n  height: 70px;\n  padding-bottom: 15px;\n  margin-top: -25px;\n  width: 57%;\n  margin-bottom: 13px;\n  align-items: center;\n  margin-left: 18%;\n}\n\n.mat-divider {\n  border: 1px solid;\n  color: #f0e9e9;\n  width: 127%;\n  margin-left: -32%;\n}\n\n.divider {\n  font-size: 12px;\n  color: #A03037;\n  font-weight: bold;\n  margin-left: -600px;\n  margin-top: 40px;\n}\n\n.box {\n  width: 170px;\n  height: 100px;\n  border: 2px solid whitesmoke;\n  border-radius: 10px;\n  align-items: center;\n  margin-top: -120px;\n  margin-left: -210px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9nZXRhbGx3aXNoLWxpc3QvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcZ2V0YWxsd2lzaC1saXN0XFxnZXRhbGx3aXNoLWxpc3QuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvZ2V0YWxsd2lzaC1saXN0L2dldGFsbHdpc2gtbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0FDQ0o7O0FESUU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBRUYsbUJBQUE7QUNGRjs7QURLRTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSx5Q0FBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUNGRjs7QURLRTtFQUNFLGVBQUE7RUFDQSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSx5Q0FBQTtFQUNBLGlCQUFBO0FDRko7O0FEV0U7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSx5Q0FBQTtBQ1JGOztBRFdFO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EseUNBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDUkY7O0FEYUU7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtBQ1ZGOztBRFlFO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0FDVEY7O0FEY0U7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNYRjs7QURlRTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxtQkFBQTtBQ1pGOztBRGVFO0VBQ0UsbUJBQUE7QUNaSjs7QURlRTtFQUNBLFdBQUE7RUFHQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNkRjs7QURnQkU7RUFDQSx1QkFBQTtBQ2JGOztBRGtCRTtFQUNBLGdCQUFBO0VBQ0UsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNmSjs7QURtQkU7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBRUEsaUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNqQko7O0FEb0JFO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDakJGOztBRHFCRTtFQUNFLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ2xCSjs7QUR1QkU7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ3BCRjs7QUR5QkU7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFFQSxXQUFBO0VBQ0EsaUJBQUE7QUN2QkY7O0FENEJFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUVBLG1CQUFBO0VBQ0MsZ0JBQUE7QUMxQkw7O0FENkJFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSw0QkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDMUJKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9nZXRhbGx3aXNoLWxpc3QvZ2V0YWxsd2lzaC1saXN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJvd3tcbiAgICBtYXJnaW4tYm90dG9tOiAtNTAwcHg7XG4gIH1cbiAgXG4gIFxuICBcbiAgLnByaWNle1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBjb2xvcjogI0EwMzAzNztcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgLy8gICBtYXJnaW4tdG9wOiAyMnB4O1xuICBtYXJnaW4tbGVmdDogLTYwMHB4O1xuICB9XG4gIFxuICAudGl0bGUtbGVmdHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBtYXJnaW4tYm90dG9tOiAtNTBweDtcbiAgZm9udC13ZWlnaHQ6Ym9sZGVyO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xuICBjb2xvcjogd2hpdGVzbW9rZTtcbiAgbWFyZ2luLXJpZ2h0OiA1MjBweDtcbiAgfVxuICBcbiAgLnRpdGxlLXJpZ2h0e1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBtYXJnaW4tYm90dG9tOiAtNTBweDtcbiAgICBmb250LXdlaWdodDogbGlnaHRlcjtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gICAgY29sb3I6IHdoaXRlc21va2U7XG4gICAgfVxuICBcbiAgXG4gIFxuICBcbiAgXG4gIFxuICBcbiAgLm1hdC1kaWFsb2ctdGl0bGV7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbiAgfVxuICBcbiAgLnNwYW57XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDs7XG4gIGNvbG9yOiBzdGVlbGJsdWU7XG4gIFxuICBcbiAgfVxuICBcbiAgLmF1dGhvcntcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogYmxhY2s7XG4gIG1hcmdpbi1sZWZ0OiAtNjAwcHg7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIHBhZGRpbmctYm90dG9tOiAxOXB4O1xuICB9XG4gIC5pbmZve1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IC02MDBweDtcbiAgcGFkZGluZy1ib3R0b206IDE5cHg7XG4gIH1cbiAgXG4gIFxuICBcbiAgLm5hbWV7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tdG9wOiAtMTEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAtNjAwcHg7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG4gIFxuICBcbiAgLmJvb2tJbWFnZURpdiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNDAsIDIzMywgMjMzKTtcbiAgd2lkdGg6IDEyMHB4O1xuICBoZWlnaHQ6IDEzMHB4O1xuICBtYXJnaW4tdG9wOiAtMzVweDtcbiAgbWFyZ2luLWxlZnQ6IC01MHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMDBweDtcbiAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgfVxuICBcbiAgLmF7XG4gICAgbGluZS1oZWlnaHQ6IG5vcm1hbDtcbiAgfVxuICBcbiAgaW1nIHtcbiAgcGFkZGluZzogMyU7XG4gIC8vICAgd2lkdGg6IDgwJTtcbiAgLy8gICBoZWlnaHQ6IDMwdmg7XG4gIHdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG4gIG1hcmdpbi1sZWZ0OjE1cHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIH1cbiAgLmJvb2tJbmZvRGl2IHtcbiAgcGFkZGluZzogNyUgMTAlIDEwJSAxMCU7XG4gIH1cbiAgXG4gIFxuICBcbiAgLm1hdC1yYWlzZWQtYnV0dG9uIHtcbiAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gICAgaGVpZ2h0OiAxOHB4O1xuICAgIHdpZHRoOiAxMTJweDtcbiAgICBiYWNrZ3JvdW5kOiAjQTAzMDM3O1xuICAgIGNvbG9yOndoaXRlc21va2U7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBtYXJnaW4tbGVmdDogMjhweDsgXG4gIH1cbiAgXG4gIFxuICAubWF0LXN0cm9rZWQtYnV0dG9ue1xuICAgIGZvbnQtd2VpZ2h0OiAxMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIHBhZGRpbmctYm90dG9tOiAzMHB4O1xuICAgIGhlaWdodDogMThweDtcbiAgICB3aWR0aDoxMjhweDtcbiAgICAvLyBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gdG9wIGxlZnQsICNmZmZmZmYgMCUsICNmZmNjMDAgMCUpO1xuICAgIGJhY2tncm91bmQ6ICBraGFraTtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IC0yMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7IFxuICB9XG4gIFxuICAudGl0bGUtY2VudGVyIHtcbiAgZmxleDogMSAxIGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICBcbiAgXG4gIC5tYXQtaWNvbntcbiAgICBtYXJnaW4tYm90dG9tOiAtNDhweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgICBjb2xvcjogd2hpdGVzbW9rZTtcbiAgfVxuICBcbiAgXG4gIFxuICAubWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiNBMDMwMzc7IFxuICBoZWlnaHQ6IDcwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAxNXB4O1xuICBtYXJnaW4tdG9wOiAtMjVweDtcbiAgd2lkdGg6IDU3JTtcbiAgbWFyZ2luLWJvdHRvbTogMTNweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWxlZnQ6IDE4JTtcbiAgfVxuICBcbiAgXG4gIFxuICAubWF0LWRpdmlkZXJ7XG4gIGJvcmRlcjogMXB4IHNvbGlkO1xuICBjb2xvcjogcmdiKDI0MCwgMjMzLCAyMzMpO1xuICAvLyBtYXJnaW4tdG9wOiA1cHg7XG4gIHdpZHRoOiAxMjclO1xuICBtYXJnaW4tbGVmdDogLTMyJTtcbiAgfVxuICBcbiAgXG4gIFxuICAuZGl2aWRlcntcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgY29sb3I6ICNBMDMwMzc7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIC8vICAgbWFyZ2luLXRvcDogMjJweDtcbiAgICBtYXJnaW4tbGVmdDogLTYwMHB4O1xuICAgICBtYXJnaW4tdG9wOiA0MHB4OyAgXG4gIH1cbiAgXG4gIC5ib3h7XG4gICAgd2lkdGg6IDE3MHB4O1xuICAgIGhlaWdodDogMTAwcHg7ICBcbiAgICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZXNtb2tlO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBtYXJnaW4tdG9wOiAtMTIwcHg7ICBcbiAgICBtYXJnaW4tbGVmdDogLTIxMHB4O1xuICAgIC8vIG1hcmdpbi1sZWZ0OiA4MHB4O1xuICAgIC8vIG1hcmdpbi10b3A6IC0zMHB4O1xuICB9XG4gICIsIi5yb3cge1xuICBtYXJnaW4tYm90dG9tOiAtNTAwcHg7XG59XG5cbi5wcmljZSB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNBMDMwMzc7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tbGVmdDogLTYwMHB4O1xufVxuXG4udGl0bGUtbGVmdCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogLTUwcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkZXI7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gIGNvbG9yOiB3aGl0ZXNtb2tlO1xuICBtYXJnaW4tcmlnaHQ6IDUyMHB4O1xufVxuXG4udGl0bGUtcmlnaHQge1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IC01MHB4O1xuICBmb250LXdlaWdodDogbGlnaHRlcjtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbiAgY29sb3I6IHdoaXRlc21va2U7XG59XG5cbi5tYXQtZGlhbG9nLXRpdGxlIHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xufVxuXG4uc3BhbiB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgY29sb3I6IHN0ZWVsYmx1ZTtcbn1cblxuLmF1dGhvciB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogLTYwMHB4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogMTlweDtcbn1cblxuLmluZm8ge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IC02MDBweDtcbiAgcGFkZGluZy1ib3R0b206IDE5cHg7XG59XG5cbi5uYW1lIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBjb2xvcjogYmxhY2s7XG4gIG1hcmdpbi10b3A6IC0xMTBweDtcbiAgbWFyZ2luLWxlZnQ6IC02MDBweDtcbiAgZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5ib29rSW1hZ2VEaXYge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjBlOWU5O1xuICB3aWR0aDogMTIwcHg7XG4gIGhlaWdodDogMTMwcHg7XG4gIG1hcmdpbi10b3A6IC0zNXB4O1xuICBtYXJnaW4tbGVmdDogLTUwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwMHB4O1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xufVxuXG4uYSB7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG59XG5cbmltZyB7XG4gIHBhZGRpbmc6IDMlO1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiA5MHB4O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cblxuLmJvb2tJbmZvRGl2IHtcbiAgcGFkZGluZzogNyUgMTAlIDEwJSAxMCU7XG59XG5cbi5tYXQtcmFpc2VkLWJ1dHRvbiB7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gIGhlaWdodDogMThweDtcbiAgd2lkdGg6IDExMnB4O1xuICBiYWNrZ3JvdW5kOiAjQTAzMDM3O1xuICBjb2xvcjogd2hpdGVzbW9rZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogMjhweDtcbn1cblxuLm1hdC1zdHJva2VkLWJ1dHRvbiB7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gIGhlaWdodDogMThweDtcbiAgd2lkdGg6IDEyOHB4O1xuICBiYWNrZ3JvdW5kOiBraGFraTtcbiAgY29sb3I6IGJsYWNrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IC0yMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogMjBweDtcbn1cblxuLnRpdGxlLWNlbnRlciB7XG4gIGZsZXg6IDEgMSBhdXRvO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5tYXQtaWNvbiB7XG4gIG1hcmdpbi1ib3R0b206IC00OHB4O1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgY29sb3I6IHdoaXRlc21va2U7XG59XG5cbi5tYXQtdG9vbGJhciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNBMDMwMzc7XG4gIGhlaWdodDogNzBweDtcbiAgcGFkZGluZy1ib3R0b206IDE1cHg7XG4gIG1hcmdpbi10b3A6IC0yNXB4O1xuICB3aWR0aDogNTclO1xuICBtYXJnaW4tYm90dG9tOiAxM3B4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tbGVmdDogMTglO1xufVxuXG4ubWF0LWRpdmlkZXIge1xuICBib3JkZXI6IDFweCBzb2xpZDtcbiAgY29sb3I6ICNmMGU5ZTk7XG4gIHdpZHRoOiAxMjclO1xuICBtYXJnaW4tbGVmdDogLTMyJTtcbn1cblxuLmRpdmlkZXIge1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjQTAzMDM3O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLWxlZnQ6IC02MDBweDtcbiAgbWFyZ2luLXRvcDogNDBweDtcbn1cblxuLmJveCB7XG4gIHdpZHRoOiAxNzBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGVzbW9rZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogLTEyMHB4O1xuICBtYXJnaW4tbGVmdDogLTIxMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/getallwish-list/getallwish-list.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/getallwish-list/getallwish-list.component.ts ***!
  \*************************************************************************/
/*! exports provided: GetallwishListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetallwishListComponent", function() { return GetallwishListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_models_cart_cart_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/models/cart/cart.module */ "./src/models/cart/cart.module.ts");
/* harmony import */ var src_models_cart_book_cart_book_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/models/cart-book/cart-book.module */ "./src/models/cart-book/cart-book.module.ts");
/* harmony import */ var src_services_book_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/book.service */ "./src/services/book.service.ts");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_cart_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/services/cart.service */ "./src/services/cart.service.ts");








let GetallwishListComponent = class GetallwishListComponent {
    constructor(bookservice, messageService, snackBar, cartService) {
        this.bookservice = bookservice;
        this.messageService = messageService;
        this.snackBar = snackBar;
        this.cartService = cartService;
    }
    ngOnInit() {
        this.messageService.currentUserMessage.subscribe(data => {
            this.loadwishlist();
        });
    }
    loadwishlist() {
        this.bookservice.viewWishlist().subscribe((data) => {
            this.books = data.data;
        });
    }
    onDeleteWishList(bookId) {
        console.log(bookId);
        this.bookservice.deletewishlist(bookId).subscribe((data) => {
            if (data.status === 200) {
                this.messageService.onViewAllWishlist();
                this.snackBar.open(data.message, 'ok', {
                    duration: 2000,
                });
            }
        }),
            (error) => {
                this.snackBar.open(error.error.message, 'ok', {
                    duration: 2000,
                });
            };
    }
    addToCart(book) {
        console.log(book);
        if (localStorage.getItem('token') === null) {
            this.cartBook = new src_models_cart_book_cart_book_module__WEBPACK_IMPORTED_MODULE_3__["CartBookModule"]();
            this.cartBook.bookQuantity = 1;
            if (localStorage.getItem('cart') === null) {
                this.cart = new src_models_cart_cart_module__WEBPACK_IMPORTED_MODULE_2__["CartModule"]();
                this.cart.totalBooksInCart = 0;
            }
            else {
                this.cart = JSON.parse(localStorage.getItem('cart'));
                console.log(this.cart);
            }
            if (this.cart.totalBooksInCart < 5) {
                this.cartBook.book = book;
                this.cartBook.totalBookPrice = Number(book.price);
                this.cart.cartBooks.forEach((element) => {
                    if (element.book.bookId === book.bookId) {
                        this.cart.cartBooks.splice(this.cart.cartBooks.indexOf(element), 1);
                        this.cart.totalBooksInCart--;
                        this.snackBar.open('Book Already Added to Cart', 'ok', {
                            duration: 2000,
                        });
                    }
                });
                this.cart.cartBooks.push(this.cartBook);
                this.cart.totalBooksInCart++;
                localStorage.setItem('cart', JSON.stringify(this.cart));
                this.snackBar.open('Book Added to Cart', 'ok', { duration: 2000 });
                localStorage.setItem('cartSize', String(this.cart.totalBooksInCart));
                this.messageService.onRefresh();
            }
            else {
                this.snackBar.open('Your Cart is full', 'ok', { duration: 2000 });
            }
        }
        else {
            this.cartService.addToCart(book.bookId).subscribe((data) => {
                console.log(data);
                if (data.status === 200) {
                    this.messageService.onRefresh();
                    localStorage.setItem('cartSize', data.data.totalBooksInCart);
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
                else if (data.status === 208) {
                    this.snackBar.open(data.message, 'ok', {
                        duration: 2000,
                    });
                }
            }, (error) => {
                if (error.status === 500) {
                    this.snackBar.open('Internal Server Error', 'ok', {
                        duration: 2000,
                    });
                }
                else {
                    this.snackBar.open(error.error.message, 'ok', {
                        duration: 2000,
                    });
                }
            });
        }
    }
};
GetallwishListComponent.ctorParameters = () => [
    { type: src_services_book_service__WEBPACK_IMPORTED_MODULE_4__["BookService"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_5__["MessageService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSnackBar"] },
    { type: src_services_cart_service__WEBPACK_IMPORTED_MODULE_7__["CartServiceService"] }
];
GetallwishListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-getallwish-list',
        template: __webpack_require__(/*! raw-loader!./getallwish-list.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/getallwish-list/getallwish-list.component.html"),
        styles: [__webpack_require__(/*! ./getallwish-list.component.scss */ "./src/app/components/getallwish-list/getallwish-list.component.scss")]
    })
], GetallwishListComponent);



/***/ }),

/***/ "./src/app/components/login/login.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/components/login/login.component.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".my-card {\n  width: 40%;\n  display: flex;\n  padding-bottom: 2px;\n  flex-wrap: wrap;\n  justify-content: center;\n  box-shadow: 0px 2px 8px 0px;\n  margin: 0 auto;\n}\n\n.mat-toolbar {\n  background-color: #b33b3b;\n  color: white;\n}\n\n.title-center {\n  flex: 1 1 auto;\n  text-align: center;\n}\n\n@media screen and (max-width: 959px) {\n  /* Column Gap */\n  .my-card {\n    margin-right: 50px;\n  }\n}\n\n@media screen and (max-width: 599px) {\n  .my-card {\n    display: flex;\n    flex-direction: column;\n    justify-content: flex-start;\n  }\n}\n\n.mat-form-field {\n  width: 100%;\n  padding-top: 5%;\n}\n\n.mat-radio-button {\n  padding-right: 25px;\n  margin-top: 0px;\n}\n\n.right {\n  margin-top: -4%;\n  margin-left: 45%;\n  color: #b33b3b;\n}\n\ninput[type=text] {\n  background-color: whitesmoke;\n}\n\n.a {\n  font-size: medium;\n  text-decoration: none;\n}\n\n.mat-raised-button {\n  margin-top: 10px;\n  background-color: #b33b3b;\n  color: aliceblue;\n}\n\n.left {\n  color: #b33b3b;\n}\n\n.mat-button {\n  color: #b33b3b;\n  margin-bottom: -50%;\n  border-radius: 30px;\n  height: 40px;\n}\n\n::ng-deep .mat-form-field-appearance-outline .mat-form-field-outline {\n  color: black;\n}\n\n::ng-deep .mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick {\n  color: black;\n}\n\n.container {\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n}\n\n/*.mat-dialog-content {\n  padding: 0px;\n  margin:0px;\n  margin-left: -47%;\n  padding-right: -30%;\n  //margin-top: 0px;\n  //margin-bottom: 0px;\n  //height: auto;\n  //box-sizing: border-box;\n  //box-shadow: 0px 2px 8px 0px;\n  //border-bottom: none;\n  border:1px red solid;\n}*/\n\n:host ::ng-deep .mat-form-field-wrapper {\n  margin: 0 !important;\n  padding-bottom: 6%;\n}\n\n::ng-deep mat-dialog-container {\n  overflow: hidden;\n  box-shadow: 0px 2px 8px 0px;\n}\n\n.mat-dialog-container {\n  padding: 0px !important;\n}\n\n/*::ng-deep .custom-modalbox > mat-dialog-container {\n  //background-color:;\n // padding-left: -50px;\n  //border: 1px red solid;\n // width: 100%;\n  //margin-left: 50%;\n  //opacity: 0;\n}*/\n\n.loginbutton {\n  margin-left: 40%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9sb2dpbi9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxsb2dpblxcbG9naW4uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxVQUFBO0VBS0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUdBLHVCQUFBO0VBQ0EsMkJBQUE7RUFFQSxjQUFBO0FDTkY7O0FEVUE7RUFDRSx5QkFBQTtFQUNBLFlBQUE7QUNQRjs7QURTQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQ05GOztBRFFBO0VBQ0UsZUFBQTtFQUNBO0lBQ0Usa0JBQUE7RUNMRjtBQUNGOztBRFFBO0VBQ0U7SUFDRSxhQUFBO0lBQ0Esc0JBQUE7SUFDQSwyQkFBQTtFQ05GO0FBQ0Y7O0FEWUE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtBQ1ZGOztBRFlBO0VBRUUsbUJBQUE7RUFDQSxlQUFBO0FDVkY7O0FEYUE7RUFDRyxlQUFBO0VBQ0QsZ0JBQUE7RUFDQSxjQUFBO0FDVkY7O0FEWUE7RUFDQyw0QkFBQTtBQ1REOztBRFdBO0VBRUUsaUJBQUE7RUFDQSxxQkFBQTtBQ1RGOztBRFdBO0VBQ0UsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FDUkY7O0FEV0E7RUFFRSxjQUFBO0FDVEY7O0FEV0E7RUFDRSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUNSRjs7QURXQTtFQUNFLFlBQUE7QUNSRjs7QURXQTtFQUNFLFlBQUE7QUNSRjs7QURVQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNQRjs7QURTQTs7Ozs7Ozs7Ozs7O0VBQUE7O0FBYUE7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0FDTkY7O0FEU0E7RUFDRyxnQkFBQTtFQUNBLDJCQUFBO0FDTkg7O0FEUUE7RUFDRSx1QkFBQTtBQ0xGOztBRE9BOzs7Ozs7O0VBQUE7O0FBUUE7RUFFRSxnQkFBQTtBQ0xGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9sb2dpbi9sb2dpbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5teS1jYXJkIHtcbiAgd2lkdGg6NDAlO1xuICAvL291dGxpbmU6IGF1dG87XG4gIC8vYm9yZGVyOiAxcHggcmVkIHNvbGlkO1xuICAvL21hcmdpbi1yaWdodDogMjAlO1xuICAvL2Zsb2F0OmNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgcGFkZGluZy1ib3R0b206IDJweDtcbiAgZmxleC13cmFwOiB3cmFwO1xuICAvL21hcmdpbi10b3A6IDEwJTtcbiAvLyBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm94LXNoYWRvdzogMHB4IDJweCA4cHggMHB4Oy8vMCA0cHggOHB4IDAgIHJnYigxNzksIDU5LCA1OSksMCA2cHggMjBweCAwIHJnYmEoMjQxLCAzNywgMzcsIDAuMTkpO1xuIC8vIGJvcmRlci1yYWRpdXM6IDEzcHg7XG4gIG1hcmdpbjogMCBhdXRvOyBcbiAgLy9vcGFjaXR5OiAxO1xufVxuXG4ubWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTc5LCA1OSwgNTkpO1xuICBjb2xvcjogd2hpdGU7XG59XG4udGl0bGUtY2VudGVyIHtcbiAgZmxleDogMSAxIGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDk1OXB4KSB7XG4gIC8qIENvbHVtbiBHYXAgKi9cbiAgLm15LWNhcmQge1xuICAgIG1hcmdpbi1yaWdodDogNTBweDtcbiAgfVxufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1OTlweCkge1xuICAubXktY2FyZCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgfVxufVxuXG4vLyAgLmV4YW1wbGUtY29udGFpbmVyIC5tYXQtZm9ybS1maWVsZCArIC5tYXQtZm9ybS1maWVsZCB7XG4vLyAgICAgIG1hcmdpbi1sZWZ0OiA4cHg7XG4vLyAgICB9XG4ubWF0LWZvcm0tZmllbGQge1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy10b3A6IDUlO1xufVxuLm1hdC1yYWRpby1idXR0b24ge1xuICAvL21hcmdpbjogMCA1cHggMCA1cHg7XG4gIHBhZGRpbmctcmlnaHQ6MjVweDtcbiAgbWFyZ2luLXRvcDowcHg7XG59XG5cbi5yaWdodCB7XG4gICBtYXJnaW4tdG9wOi00JTtcbiAgbWFyZ2luLWxlZnQ6NDUlO1xuICBjb2xvcjogcmdiKDE3OSwgNTksIDU5KTtcbn1cbmlucHV0W3R5cGU9dGV4dF0ge1xuIGJhY2tncm91bmQtY29sb3I6d2hpdGVzbW9rZTtcbn1cbi5hXG57XG4gIGZvbnQtc2l6ZTogbWVkaXVtO1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gfVxuLm1hdC1yYWlzZWQtYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE3OSwgNTksIDU5KTtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgLy9tYXJnaW4tbGVmdDogNTBweDtcbiAgfVxuLmxlZnRcbntcbiAgY29sb3I6cmdiKDE3OSwgNTksIDU5KTtcbn1cbi5tYXQtYnV0dG9ue1xuICBjb2xvcjogIHJnYigxNzksIDU5LCA1OSk7XG4gIG1hcmdpbi1ib3R0b206IC01MCU7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGhlaWdodDo0MHB4O1xuICBcbn1cbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lIHtcbiAgY29sb3I6IGJsYWNrO1xuICBcbn1cbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lLm1hdC1mb2N1c2VkIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lLXRoaWNrIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4vKi5tYXQtZGlhbG9nLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwcHg7XG4gIG1hcmdpbjowcHg7XG4gIG1hcmdpbi1sZWZ0OiAtNDclO1xuICBwYWRkaW5nLXJpZ2h0OiAtMzAlO1xuICAvL21hcmdpbi10b3A6IDBweDtcbiAgLy9tYXJnaW4tYm90dG9tOiAwcHg7XG4gIC8vaGVpZ2h0OiBhdXRvO1xuICAvL2JveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIC8vYm94LXNoYWRvdzogMHB4IDJweCA4cHggMHB4O1xuICAvL2JvcmRlci1ib3R0b206IG5vbmU7XG4gIGJvcmRlcjoxcHggcmVkIHNvbGlkO1xufSovXG46aG9zdCA6Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXJ7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWJvdHRvbTogNiU7XG59XG5cbjo6bmctZGVlcCBtYXQtZGlhbG9nLWNvbnRhaW5lciB7XG4gICBvdmVyZmxvdzogaGlkZGVuO1xuICAgYm94LXNoYWRvdzogMHB4IDJweCA4cHggMHB4O1xufVxuLm1hdC1kaWFsb2ctY29udGFpbmVyIHtcbiAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XG59XG4vKjo6bmctZGVlcCAuY3VzdG9tLW1vZGFsYm94ID4gbWF0LWRpYWxvZy1jb250YWluZXIge1xuICAvL2JhY2tncm91bmQtY29sb3I6O1xuIC8vIHBhZGRpbmctbGVmdDogLTUwcHg7XG4gIC8vYm9yZGVyOiAxcHggcmVkIHNvbGlkO1xuIC8vIHdpZHRoOiAxMDAlO1xuICAvL21hcmdpbi1sZWZ0OiA1MCU7XG4gIC8vb3BhY2l0eTogMDtcbn0qL1xuLmxvZ2luYnV0dG9uXG57XG4gIG1hcmdpbi1sZWZ0OiA0MCU7XG59IiwiLm15LWNhcmQge1xuICB3aWR0aDogNDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBwYWRkaW5nLWJvdHRvbTogMnB4O1xuICBmbGV4LXdyYXA6IHdyYXA7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBib3gtc2hhZG93OiAwcHggMnB4IDhweCAwcHg7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuXG4ubWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYjMzYjNiO1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi50aXRsZS1jZW50ZXIge1xuICBmbGV4OiAxIDEgYXV0bztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5NTlweCkge1xuICAvKiBDb2x1bW4gR2FwICovXG4gIC5teS1jYXJkIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDUwcHg7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU5OXB4KSB7XG4gIC5teS1jYXJkIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICB9XG59XG4ubWF0LWZvcm0tZmllbGQge1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy10b3A6IDUlO1xufVxuXG4ubWF0LXJhZGlvLWJ1dHRvbiB7XG4gIHBhZGRpbmctcmlnaHQ6IDI1cHg7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cblxuLnJpZ2h0IHtcbiAgbWFyZ2luLXRvcDogLTQlO1xuICBtYXJnaW4tbGVmdDogNDUlO1xuICBjb2xvcjogI2IzM2IzYjtcbn1cblxuaW5wdXRbdHlwZT10ZXh0XSB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlc21va2U7XG59XG5cbi5hIHtcbiAgZm9udC1zaXplOiBtZWRpdW07XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuLm1hdC1yYWlzZWQtYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2IzM2IzYjtcbiAgY29sb3I6IGFsaWNlYmx1ZTtcbn1cblxuLmxlZnQge1xuICBjb2xvcjogI2IzM2IzYjtcbn1cblxuLm1hdC1idXR0b24ge1xuICBjb2xvcjogI2IzM2IzYjtcbiAgbWFyZ2luLWJvdHRvbTogLTUwJTtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgaGVpZ2h0OiA0MHB4O1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2Utb3V0bGluZSAubWF0LWZvcm0tZmllbGQtb3V0bGluZSB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUubWF0LWZvY3VzZWQgLm1hdC1mb3JtLWZpZWxkLW91dGxpbmUtdGhpY2sge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4vKi5tYXQtZGlhbG9nLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwcHg7XG4gIG1hcmdpbjowcHg7XG4gIG1hcmdpbi1sZWZ0OiAtNDclO1xuICBwYWRkaW5nLXJpZ2h0OiAtMzAlO1xuICAvL21hcmdpbi10b3A6IDBweDtcbiAgLy9tYXJnaW4tYm90dG9tOiAwcHg7XG4gIC8vaGVpZ2h0OiBhdXRvO1xuICAvL2JveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIC8vYm94LXNoYWRvdzogMHB4IDJweCA4cHggMHB4O1xuICAvL2JvcmRlci1ib3R0b206IG5vbmU7XG4gIGJvcmRlcjoxcHggcmVkIHNvbGlkO1xufSovXG46aG9zdCA6Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXIge1xuICBtYXJnaW46IDAgIWltcG9ydGFudDtcbiAgcGFkZGluZy1ib3R0b206IDYlO1xufVxuXG46Om5nLWRlZXAgbWF0LWRpYWxvZy1jb250YWluZXIge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2hhZG93OiAwcHggMnB4IDhweCAwcHg7XG59XG5cbi5tYXQtZGlhbG9nLWNvbnRhaW5lciB7XG4gIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xufVxuXG4vKjo6bmctZGVlcCAuY3VzdG9tLW1vZGFsYm94ID4gbWF0LWRpYWxvZy1jb250YWluZXIge1xuICAvL2JhY2tncm91bmQtY29sb3I6O1xuIC8vIHBhZGRpbmctbGVmdDogLTUwcHg7XG4gIC8vYm9yZGVyOiAxcHggcmVkIHNvbGlkO1xuIC8vIHdpZHRoOiAxMDAlO1xuICAvL21hcmdpbi1sZWZ0OiA1MCU7XG4gIC8vb3BhY2l0eTogMDtcbn0qL1xuLmxvZ2luYnV0dG9uIHtcbiAgbWFyZ2luLWxlZnQ6IDQwJTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/login/login.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/components/login/login.component.ts ***!
  \*****************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../forgot-password/forgot-password.component */ "./src/app/components/forgot-password/forgot-password.component.ts");
/* harmony import */ var src_services_cart_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/services/cart.service */ "./src/services/cart.service.ts");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/services/encr-decr.service */ "./src/services/encr-decr.service.ts");










let LoginComponent = class LoginComponent {
    constructor(formBuilder, route, router, userService, snackBar, dialog, encrDecr, cartService, messageService) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.snackBar = snackBar;
        this.dialog = dialog;
        this.encrDecr = encrDecr;
        this.cartService = cartService;
        this.messageService = messageService;
        this.hide = true;
        this.loading = false;
        this.submitted = false;
        this.title = 'Book Store Login';
        this.error = '';
        if (localStorage.getItem('popup') === "true")
            this.popup = true;
        else
            this.popup = false;
        console.log("popup?", this.popup);
    }
    ngOnInit() {
        this.LoginForm = this.formBuilder.group({
            loginid: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(4),
                ],
            ],
            password: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6),
                ],
            ],
            userroles: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
        });
        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
    }
    // convenience getter for easy access to form fields
    get f() {
        return this.LoginForm.controls;
    }
    opendialogforforgotpassowrd() {
        console.log("to open forgot popup");
        this.dialog.open(_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_6__["ForgotPasswordComponent"], { height: '50%', width: '50%' });
    }
    onSubmit() {
        this.submitted = true;
        // stop here if form is invalid
        console.log('Submitting');
        /* if (!this.LoginForm.valid) {
           console.log(
             'Form not valid. Please check that fields are correctly filled in'
           );
           return;
         }*/
        /* if(this.roles==')
         this.role=1;
         else {
           this.roles=2;
         }*/
        // console.log("user role:",this.LoginForm.get('userroles').value);
        if (this.LoginForm.get('userroles').value.localeCompare('admin') === 0) {
            this.role1 = 1;
        }
        if (this.LoginForm.get('userroles').value.localeCompare('vendor') === 0) {
            this.role1 = 2;
        }
        if (this.LoginForm.get('userroles').value.localeCompare('customer') === 0) {
            this.role1 = 3;
        }
        /*if(this.roles==0)
        {
          this.role1=1;
        }
       else
        {
           this.role1=2;
       }*/
        console.log('ROLE:', this.role1);
        const data = {
            loginId: this.LoginForm.get('loginid').value,
            password: this.encrDecr.set('123456$#@$^@1ERF', this.LoginForm.get('password').value),
            /* this.resetPassword.password = this.encrDecr.set(
               '123456$#@$^@1ERF',
               this.resetPassword.password
             );*/
            role: this.role1
        };
        this.loading = true;
        this.userService.login(data).subscribe((response) => {
            console.log('LOGIN COMPONENT:', response);
            if (response.status === 200) {
                //this.dialogRef.close();
                localStorage.setItem('token', response['token']);
                localStorage.setItem('image', response.data['imageUrl']);
                localStorage.setItem('name', response.data['name']);
                localStorage.setItem('username', response.data['userName']);
                localStorage.setItem('email', response.data['email']);
                localStorage.setItem('mobile', response.data['mobileNumber']);
                localStorage.setItem('status', response.data['userStatus']);
                if (this.role1 === 3) {
                    this.messageService.onRefresh();
                    this.cartService.placeOrder(JSON.parse(localStorage.getItem('cart'))).subscribe((data) => {
                        if (data.status === 200) {
                            this.messageService.cartBooks();
                            this.messageService.onCartCount();
                            localStorage.removeItem('cart');
                        }
                    }, (error) => {
                        if (error.status === 417) {
                            this.messageService.cartBooks();
                            localStorage.removeItem('cart');
                            this.snackBar.open(error.error.message, 'ok', {
                                duration: 2000
                            });
                        }
                        this.snackBar.open(error.error.message, 'ok', {
                            duration: 2000
                        });
                    });
                }
                if (this.role1 === 1) {
                    this.router.navigate(['admin-dashboard']);
                }
                if (this.role1 === 2) {
                    this.router.navigate(['vendor-dashboard']);
                }
                this.logsuccess = true;
                //console.log('user has been successfully logged in:');
                this.snackBar.open(response.message, 'ok', { duration: 5000 });
            }
        }, (error) => {
            //console.log(error);
            this.loading = false;
            // if (error.status === 400) {
            this.snackBar.open(error.error.message, 'ok', { duration: 2000 });
            // }
        });
    }
    onRegister() {
        this.router.navigate(['/register']);
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatDialog"] },
    { type: src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_9__["EncrDecrService"] },
    { type: src_services_cart_service__WEBPACK_IMPORTED_MODULE_7__["CartServiceService"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_8__["MessageService"] }
];
LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'dashboard/login',
        template: __webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/login/login.component.html"),
        styles: [__webpack_require__(/*! ./login.component.scss */ "./src/app/components/login/login.component.scss")]
    })
], LoginComponent);



/***/ }),

/***/ "./src/app/components/myorders/myorders.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/components/myorders/myorders.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  font-family: arial, sans-serif;\n  border-collapse: collapse;\n  width: 100%;\n  margin-top: 1%;\n}\n\ntd, th {\n  border: 1px solid #dddddd;\n  text-align: center;\n  padding: 8px;\n}\n\n.tool {\n  background-color: #b33b3b;\n  height: 55px;\n  color: aliceblue;\n}\n\na {\n  text-decoration: none;\n}\n\n.profile {\n  margin-left: 90%;\n}\n\n::ng-deep .profilemenu {\n  width: 300px;\n  height: 335px;\n}\n\n.mat-headline, .mat-subheading-1 {\n  margin-top: 50%;\n  text-align: center;\n  padding: 0px;\n  margin: 0px;\n}\n\n.signup, .log {\n  width: 100%;\n}\n\n.fileuploadbtn {\n  width: 0px;\n  height: 0px;\n  display: none;\n  visibility: hidden;\n}\n\n.icon {\n  color: black;\n}\n\n.pic {\n  width: 50px;\n  height: 50px;\n  border-radius: 50%;\n  color: brown;\n  position: absolute;\n  margin-left: 11%;\n}\n\n.upload-img {\n  position: relative;\n  margin-left: 50%;\n  padding-top: 13%;\n}\n\n.editbutton {\n  background-color: #b33b3b;\n  color: white;\n  left: 40%;\n}\n\n#logout {\n  left: 40%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9teW9yZGVycy9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxteW9yZGVyc1xcbXlvcmRlcnMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvbXlvcmRlcnMvbXlvcmRlcnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw4QkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDQ0o7O0FEQ0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0VKOztBRENDO0VBQ0kscUJBQUE7QUNFTDs7QURHQTtFQUVJLGdCQUFBO0FDREo7O0FER0E7RUFDSSxZQUFBO0VBQ0EsYUFBQTtBQ0FKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNJLFdBQUE7QUNFSjs7QURHQTtFQUVJLFVBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FDREo7O0FER0E7RUFFSSxZQUFBO0FDREo7O0FER0E7RUFFSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURHQTtFQUVJLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0RKOztBREdBO0VBRUkseUJBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtBQ0RKOztBREdBO0VBRUksU0FBQTtBQ0RKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9teW9yZGVycy9teW9yZGVycy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcbiAgICBmb250LWZhbWlseTogYXJpYWwsIHNhbnMtc2VyaWY7XG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW4tdG9wOiAxJTtcbiAgfVxuICBcbiAgdGQsIHRoIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLnRvb2x7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE3OSwgNTksIDU5KTtcbiAgICBoZWlnaHQ6IDU1cHg7XG4gICAgY29sb3I6IGFsaWNlYmx1ZTtcbiAgICBcbiB9XG4gYXtcbiAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuIH1cblxuXG5cbi5wcm9maWxlXG57XG4gICAgbWFyZ2luLWxlZnQ6IDkwJTtcbn1cbjo6bmctZGVlcCAucHJvZmlsZW1lbnUge1xuICAgIHdpZHRoOiAzMDBweDtcbiAgICBoZWlnaHQ6IDMzNXB4O1xufVxuLm1hdC1oZWFkbGluZSwubWF0LXN1YmhlYWRpbmctMXtcbiAgICBtYXJnaW4tdG9wOiA1MCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICBtYXJnaW46IDBweDtcbn1cbi5zaWdudXAsLmxvZ3tcbiAgICB3aWR0aDogMTAwJTtcbiAgICAvL2JhY2tncm91bmQtY29sb3I6IHJnYigxNzksIDU5LCA1OSk7XG4gICAgLy9jb2xvcjogd2hpdGU7XG59XG5cbi5maWxldXBsb2FkYnRuXG57XG4gICAgd2lkdGg6IDBweDtcbiAgICBoZWlnaHQ6IDBweDtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbn1cbi5pY29uXG57XG4gICAgY29sb3I6IGJsYWNrO1xufVxuLnBpY1xue1xuICAgIHdpZHRoOiA1MHB4O1xuICAgIGhlaWdodDogNTBweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgY29sb3I6IGJyb3duO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBtYXJnaW4tbGVmdDogMTElO1xufVxuLnVwbG9hZC1pbWdcbntcbiAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcbiAgICBtYXJnaW4tbGVmdDogNTAlO1xuICAgIHBhZGRpbmctdG9wOiAxMyU7XG59XG4uZWRpdGJ1dHRvblxue1xuICAgIGJhY2tncm91bmQtY29sb3I6cmdiKDE3OSwgNTksIDU5KTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbGVmdDogNDAlO1xufVxuI2xvZ291dFxue1xuICAgIGxlZnQ6IDQwJTtcbn0iLCJ0YWJsZSB7XG4gIGZvbnQtZmFtaWx5OiBhcmlhbCwgc2Fucy1zZXJpZjtcbiAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbi10b3A6IDElO1xufVxuXG50ZCwgdGgge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDhweDtcbn1cblxuLnRvb2wge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYjMzYjNiO1xuICBoZWlnaHQ6IDU1cHg7XG4gIGNvbG9yOiBhbGljZWJsdWU7XG59XG5cbmEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbi5wcm9maWxlIHtcbiAgbWFyZ2luLWxlZnQ6IDkwJTtcbn1cblxuOjpuZy1kZWVwIC5wcm9maWxlbWVudSB7XG4gIHdpZHRoOiAzMDBweDtcbiAgaGVpZ2h0OiAzMzVweDtcbn1cblxuLm1hdC1oZWFkbGluZSwgLm1hdC1zdWJoZWFkaW5nLTEge1xuICBtYXJnaW4tdG9wOiA1MCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMHB4O1xuICBtYXJnaW46IDBweDtcbn1cblxuLnNpZ251cCwgLmxvZyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uZmlsZXVwbG9hZGJ0biB7XG4gIHdpZHRoOiAwcHg7XG4gIGhlaWdodDogMHB4O1xuICBkaXNwbGF5OiBub25lO1xuICB2aXNpYmlsaXR5OiBoaWRkZW47XG59XG5cbi5pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4ucGljIHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBjb2xvcjogYnJvd247XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbWFyZ2luLWxlZnQ6IDExJTtcbn1cblxuLnVwbG9hZC1pbWcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi1sZWZ0OiA1MCU7XG4gIHBhZGRpbmctdG9wOiAxMyU7XG59XG5cbi5lZGl0YnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2IzM2IzYjtcbiAgY29sb3I6IHdoaXRlO1xuICBsZWZ0OiA0MCU7XG59XG5cbiNsb2dvdXQge1xuICBsZWZ0OiA0MCU7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/myorders/myorders.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/myorders/myorders.component.ts ***!
  \***********************************************************/
/*! exports provided: MyordersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyordersComponent", function() { return MyordersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/admin.service */ "./src/services/admin.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _book_review_book_review_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../book-review/book-review.component */ "./src/app/components/book-review/book-review.component.ts");
/* harmony import */ var _edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../edit-profile/edit-profile.component */ "./src/app/components/edit-profile/edit-profile.component.ts");








let MyordersComponent = class MyordersComponent {
    constructor(userService, dialog, Adminservice, router) {
        this.userService = userService;
        this.dialog = dialog;
        this.Adminservice = Adminservice;
        this.router = router;
        this.btnName = "Review";
        this.username = localStorage.getItem('name');
        this.usermail = localStorage.getItem('email');
        this.profile = localStorage.getItem('image');
        this.userService.getmyOrders().subscribe((response) => {
            console.log("orders:", response);
            this.orderedbooks = response.data;
        });
        this.router.routeReuseStrategy.shouldReuseRoute = () => { return false; };
    }
    openDialog(book) {
        console.log("book=", book);
        console.log("book id:", book.book.bookId);
        localStorage.setItem('orderid', book.myOrderId);
        localStorage.setItem('bookId', book.book.bookId);
        let dialogRef = this.dialog.open(_book_review_book_review_component__WEBPACK_IMPORTED_MODULE_6__["BookReviewComponent"], { width: '30%' });
        dialogRef.afterClosed().subscribe(result => {
            this.router.navigate(['/myorders']);
            this.router.navigate(['/myorders']);
        });
        //this.btnName="4.5";
    }
    ngOnInit() {
    }
    Logout() {
        console.log('CAME TO LOGOUT');
        this.Adminservice.logout().subscribe();
        localStorage.clear();
        console.log(localStorage.length);
        this.router.navigate(['/dashboard']);
    }
    openDialogztoedit() {
        this.dialog.open(_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_7__["EditProfileComponent"]);
    }
};
MyordersComponent.ctorParameters = () => [
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialog"] },
    { type: src_services_admin_service__WEBPACK_IMPORTED_MODULE_4__["AdminService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
MyordersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-myorders',
        template: __webpack_require__(/*! raw-loader!./myorders.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/myorders/myorders.component.html"),
        styles: [__webpack_require__(/*! ./myorders.component.scss */ "./src/app/components/myorders/myorders.component.scss")]
    })
], MyordersComponent);



/***/ }),

/***/ "./src/app/components/pagination/pagination.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/components/pagination/pagination.component.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcGFnaW5hdGlvbi9wYWdpbmF0aW9uLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/pagination/pagination.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/pagination/pagination.component.ts ***!
  \***************************************************************/
/*! exports provided: PaginationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaginationComponent", function() { return PaginationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let PaginationComponent = class PaginationComponent {
    constructor() {
        this.totalRecords = 0;
        this.recordsPerPage = 0;
        this.page = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.pages = [];
    }
    ngOnChanges() {
        const pageCount = this.getPageCount();
        this.pages = this.getArrayOfPage(pageCount);
        this.activePage = 0;
        this.page.emit(0);
    }
    getPageCount() {
        let totalPage = 0;
        if (this.totalRecords > 0 && this.recordsPerPage > 0) {
            const pageCount = this.totalRecords / this.recordsPerPage;
            const roundedPageCount = Math.floor(pageCount);
            totalPage = roundedPageCount < pageCount ? roundedPageCount + 1 : roundedPageCount;
        }
        return totalPage;
    }
    getArrayOfPage(pageCount) {
        let pageArray = [];
        if (pageCount > 0) {
            for (var i = 1; i <= pageCount; i++) {
                pageArray.push(i);
            }
        }
        return pageArray;
    }
    onClickPage(pageNumber) {
        this.activePage = pageNumber;
        this.page.emit(this.activePage);
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PaginationComponent.prototype, "totalRecords", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PaginationComponent.prototype, "recordsPerPage", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], PaginationComponent.prototype, "page", void 0);
PaginationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pagination',
        template: __webpack_require__(/*! raw-loader!./pagination.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/pagination/pagination.component.html"),
        styles: [__webpack_require__(/*! ./pagination.component.scss */ "./src/app/components/pagination/pagination.component.scss")]
    })
], PaginationComponent);



/***/ }),

/***/ "./src/app/components/register/register.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/components/register/register.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".regbutton {\n  background-color: #720a0a;\n  color: aliceblue;\n}\n\nmat-card {\n  width: 35%;\n  margin-top: 2%;\n}\n\n.mat-card:not([class*=mat-elevation-z]) {\n  box-shadow: 0 2px 1px -1px black, 0 1px 1px 0 black, 0 1px 3px 0 black;\n}\n\n:host ::ng-deep .mat-form-field-wrapper {\n  margin: 0 !important;\n  padding-bottom: 1%;\n  padding-top: 2%;\n}\n\n::ng-deep .mat-form-field-appearance-outline .mat-form-field-outline {\n  color: black;\n}\n\n::ng-deep .mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick {\n  color: black;\n}\n\n::ng-deep .mat-form-field.mat-focused .mat-form-field-label {\n  color: black;\n}\n\n/*\n::ng-deep .mat-form-field-label {\n    color: rgb(114, 10, 10);\n    // color: $mainColor!important;\n}\n::ng-deep .mat-card{\n    border-radius: 2% !important;\n    border: #000 !important;\n}*/\n\n.mat-toolbar, .mat-toolbar-row {\n  background-color: #720a0a;\n  color: white;\n  padding-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9yZWdpc3Rlci9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxyZWdpc3RlclxccmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvcmVnaXN0ZXIvcmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBQTtFQUNBLGdCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxVQUFBO0VBQ0EsY0FBQTtBQ0VKOztBREFBO0VBQ0ksc0VBQUE7QUNHSjs7QURDQTtFQUNJLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUE7RUFDSSxZQUFBO0FDR0o7O0FEQUE7RUFDSSxZQUFBO0FDR0o7O0FEQUE7RUFFSSxZQUFBO0FDRUo7O0FEQUE7Ozs7Ozs7O0VBQUE7O0FBU0E7RUFFSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9yZWdpc3Rlci9yZWdpc3Rlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWdidXR0b257XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDExNCwgMTAsIDEwKTsgXG4gICAgY29sb3I6IGFsaWNlYmx1ZTtcbn1cbm1hdC1jYXJke1xuICAgIHdpZHRoOiAzNSU7XG4gICAgbWFyZ2luLXRvcDogMiU7XG59XG4ubWF0LWNhcmQ6bm90KFtjbGFzcyo9bWF0LWVsZXZhdGlvbi16XSkge1xuICAgIGJveC1zaGFkb3c6IDAgMnB4IDFweCAtMXB4IHJnYmEoMCwwLDAsMSksIFxuICAgICAgICAgICAgICAgIDAgMXB4IDFweCAwIHJnYmEoMCwwLDAsMSksIFxuICAgICAgICAgICAgICAgIDAgMXB4IDNweCAwIHJnYmEoMCwwLDAsMSk7XG59XG46aG9zdCA6Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLXdyYXBwZXJ7XG4gICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1ib3R0b206IDElO1xuICAgIHBhZGRpbmctdG9wOiAyJTtcbn1cbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lIHtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgXG59XG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2Utb3V0bGluZS5tYXQtZm9jdXNlZCAubWF0LWZvcm0tZmllbGQtb3V0bGluZS10aGljayB7XG4gICAgY29sb3I6IGJsYWNrO1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLm1hdC1mb2N1c2VkIC5tYXQtZm9ybS1maWVsZC1sYWJlbCB7XG4gICAgLy9jb2xvcjogcmdiKDExNCwgMTAsIDEwKTtcbiAgICBjb2xvcjogYmxhY2s7XG59XG4vKlxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1sYWJlbCB7XG4gICAgY29sb3I6IHJnYigxMTQsIDEwLCAxMCk7XG4gICAgLy8gY29sb3I6ICRtYWluQ29sb3IhaW1wb3J0YW50O1xufVxuOjpuZy1kZWVwIC5tYXQtY2FyZHtcbiAgICBib3JkZXItcmFkaXVzOiAyJSAhaW1wb3J0YW50O1xuICAgIGJvcmRlcjogIzAwMCAhaW1wb3J0YW50O1xufSovXG4ubWF0LXRvb2xiYXIsLm1hdC10b29sYmFyLXJvd1xue1xuICAgIGJhY2tncm91bmQtY29sb3I6cmdiKDExNCwgMTAsIDEwKTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZy10b3A6IDEwcHg7XG59IiwiLnJlZ2J1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM3MjBhMGE7XG4gIGNvbG9yOiBhbGljZWJsdWU7XG59XG5cbm1hdC1jYXJkIHtcbiAgd2lkdGg6IDM1JTtcbiAgbWFyZ2luLXRvcDogMiU7XG59XG5cbi5tYXQtY2FyZDpub3QoW2NsYXNzKj1tYXQtZWxldmF0aW9uLXpdKSB7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDFweCAtMXB4IGJsYWNrLCAwIDFweCAxcHggMCBibGFjaywgMCAxcHggM3B4IDAgYmxhY2s7XG59XG5cbjpob3N0IDo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtd3JhcHBlciB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWJvdHRvbTogMSU7XG4gIHBhZGRpbmctdG9wOiAyJTtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUgLm1hdC1mb3JtLWZpZWxkLW91dGxpbmUge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lLm1hdC1mb2N1c2VkIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lLXRoaWNrIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLm1hdC1mb2N1c2VkIC5tYXQtZm9ybS1maWVsZC1sYWJlbCB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLypcbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtbGFiZWwge1xuICAgIGNvbG9yOiByZ2IoMTE0LCAxMCwgMTApO1xuICAgIC8vIGNvbG9yOiAkbWFpbkNvbG9yIWltcG9ydGFudDtcbn1cbjo6bmctZGVlcCAubWF0LWNhcmR7XG4gICAgYm9yZGVyLXJhZGl1czogMiUgIWltcG9ydGFudDtcbiAgICBib3JkZXI6ICMwMDAgIWltcG9ydGFudDtcbn0qL1xuLm1hdC10b29sYmFyLCAubWF0LXRvb2xiYXItcm93IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzcyMGEwYTtcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/register/register.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/register/register.component.ts ***!
  \***********************************************************/
/*! exports provided: RegisterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterComponent", function() { return RegisterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/encr-decr.service */ "./src/services/encr-decr.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");







let RegisterComponent = class RegisterComponent {
    constructor(service, EncrDecr, router, dialog, snackbar) {
        this.service = service;
        this.EncrDecr = EncrDecr;
        this.router = router;
        this.dialog = dialog;
        this.snackbar = snackbar;
        this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+')]);
        this.name = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3),
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-zA-z]+([\\s][a-zA-Z]+)*$')
        ]));
        this.phone = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10),
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10),
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('(0|9)?[7-9][0-9]{9}')
        ]));
        this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(8),
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(16),
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}')
        ]));
        this.username = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(4),
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}')
        ]));
        this.passwordType = 'password';
        this.show = false;
        this.radioval = 0;
    }
    ngOnInit() { }
    onclick() {
        if (this.show) {
            this.passwordType = 'password';
            this.show = false;
        }
        else {
            this.passwordType = 'text';
            this.show = true;
        }
    }
    onRegister() {
        if (this.email.hasError('required') || this.name.hasError('required') ||
            this.password.hasError('required') || this.phone.hasError('required') ||
            this.username.hasError('required')) {
            this.snackbar.open('Cannot submit empty fields', 'ok', { duration: 5000 });
        }
        else if (this.email.hasError('email') || this.name.hasError('minlength') ||
            this.password.hasError('minlength') || this.password.hasError('maxlength') ||
            this.phone.hasError('minlength')) {
            this.snackbar.open('Cannot submit invalid input', 'ok', { duration: 5000 });
        }
        else if (isNaN(this.phone.value)) {
            this.snackbar.open('Phone Number should be digits only', 'ok', { duration: 5000 });
        }
        else if (this.radioval == 0) {
            this.snackbar.open('Select the role', 'ok', { duration: 5000 });
        }
        else {
            if (this.radioval == 2) {
                this.selectedrole = 2;
            }
            else if (this.radioval == 3) {
                this.selectedrole = 3;
            }
            const data = {
                email: this.email.value,
                name: this.name.value,
                mobileNumber: this.phone.value,
                //password: this.password.value,
                password: this.EncrDecr.set('123456$#@$^@1ERF', this.password.value),
                userName: this.username.value,
                role: this.selectedrole
            };
            this.service.register(data).subscribe((response) => {
                if (response.status == 200) {
                    localStorage.setItem("popup", "true");
                    this.snackbar.open(response.message, 'ok', { duration: 5000 });
                    this.router.navigate(['/login']);
                }
                else {
                    this.snackbar.open(response.message, 'Canecl', { duration: 5000 });
                }
            });
        }
    }
    onLogin() {
        //const dialogRef = this.dialog.open(LoginComponent, {
        //  width: '40%',
        //  height:'90%',
        //});
        localStorage.setItem("popup", "true");
        this.router.navigate(['/login']);
    }
};
RegisterComponent.ctorParameters = () => [
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
    { type: src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_4__["EncrDecrService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDialog"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSnackBar"] }
];
RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register',
        template: __webpack_require__(/*! raw-loader!./register.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/register/register.component.html"),
        styles: [__webpack_require__(/*! ./register.component.scss */ "./src/app/components/register/register.component.scss")]
    })
], RegisterComponent);



/***/ }),

/***/ "./src/app/components/rejection/rejection.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/components/rejection/rejection.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "::ng-deep .mat-form-field-appearance-outline .mat-form-field-outline {\n  color: black !important;\n}\n\n::ng-deep .mat-form-field-appearance-outline.mat-form-field-invalid.mat-form-field-invalid .mat-form-field-outline-thick {\n  color: red !important;\n  opacity: 0.8 !important;\n}\n\n::ng-deep .mat-form-field-invalid .mat-input-element, .mat-warn .mat-input-element {\n  caret-color: black !important;\n}\n\n::ng-deep .mat-form-field-invalid .mat-input-element, .mat-warn .mat-input-element {\n  caret-color: red !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9yZWplY3Rpb24vQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xccmVqZWN0aW9uXFxyZWplY3Rpb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvcmVqZWN0aW9uL3JlamVjdGlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHVCQUFBO0FDQ0o7O0FERUE7RUFDSSxxQkFBQTtFQUNBLHVCQUFBO0FDQ0o7O0FEQ0E7RUFDSSw2QkFBQTtBQ0VKOztBREFBO0VBQ0ksMkJBQUE7QUNHSiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcmVqZWN0aW9uL3JlamVjdGlvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lIHtcbiAgICBjb2xvcjogYmxhY2shaW1wb3J0YW50O1xuICAgIFxufVxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUubWF0LWZvcm0tZmllbGQtaW52YWxpZC5tYXQtZm9ybS1maWVsZC1pbnZhbGlkIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lLXRoaWNre1xuICAgIGNvbG9yOiByZWQhaW1wb3J0YW50O1xuICAgIG9wYWNpdHk6IDAuOCFpbXBvcnRhbnQ7XG59XG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWludmFsaWQgLm1hdC1pbnB1dC1lbGVtZW50LCAubWF0LXdhcm4gLm1hdC1pbnB1dC1lbGVtZW50IHtcbiAgICBjYXJldC1jb2xvcjogYmxhY2shaW1wb3J0YW50O1xufVxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1pbnZhbGlkIC5tYXQtaW5wdXQtZWxlbWVudCwgLm1hdC13YXJuIC5tYXQtaW5wdXQtZWxlbWVudCB7XG4gICAgY2FyZXQtY29sb3I6IHJlZCFpbXBvcnRhbnQ7XG59IiwiOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUgLm1hdC1mb3JtLWZpZWxkLW91dGxpbmUge1xuICBjb2xvcjogYmxhY2sgIWltcG9ydGFudDtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUubWF0LWZvcm0tZmllbGQtaW52YWxpZC5tYXQtZm9ybS1maWVsZC1pbnZhbGlkIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lLXRoaWNrIHtcbiAgY29sb3I6IHJlZCAhaW1wb3J0YW50O1xuICBvcGFjaXR5OiAwLjggIWltcG9ydGFudDtcbn1cblxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1pbnZhbGlkIC5tYXQtaW5wdXQtZWxlbWVudCwgLm1hdC13YXJuIC5tYXQtaW5wdXQtZWxlbWVudCB7XG4gIGNhcmV0LWNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWludmFsaWQgLm1hdC1pbnB1dC1lbGVtZW50LCAubWF0LXdhcm4gLm1hdC1pbnB1dC1lbGVtZW50IHtcbiAgY2FyZXQtY29sb3I6IHJlZCAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/rejection/rejection.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/rejection/rejection.component.ts ***!
  \*************************************************************/
/*! exports provided: RejectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RejectionComponent", function() { return RejectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");



let RejectionComponent = class RejectionComponent {
    constructor() {
        this.description = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
    }
    ngOnInit() {
    }
    getErrorMessage() {
        if (this.description.hasError('required')) {
            return 'You must enter a message';
        }
    }
    onSubmit() {
        console.log(this.description);
        localStorage.setItem('reject', 'reject');
        localStorage.setItem('description', this.description.value);
    }
};
RejectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-rejection',
        template: __webpack_require__(/*! raw-loader!./rejection.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/rejection/rejection.component.html"),
        styles: [__webpack_require__(/*! ./rejection.component.scss */ "./src/app/components/rejection/rejection.component.scss")]
    })
], RejectionComponent);



/***/ }),

/***/ "./src/app/components/reset-password/reset-password.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/components/reset-password/reset-password.component.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "button {\n  background-color: brown;\n  width: 25%;\n}\n\nmat-card-title {\n  padding-left: 0px;\n  padding-right: 0px;\n}\n\n.container {\n  width: 100%;\n  height: 100%;\n}\n\n.mat-card-header {\n  background-color: brown;\n  box-shadow: 0 4px 8px 0 rgba(244, 245, 244, 0.2), 0 6px 20px 0 rgba(244, 247, 245, 0.19);\n}\n\n.mat-card-main {\n  width: 35%;\n  box-shadow: 0 4px 8px 0 rgba(244, 245, 244, 0.2), 0 6px 20px 0 rgba(244, 247, 245, 0.19);\n}\n\n.title-center {\n  flex: 1 1 auto;\n  text-align: center;\n  font-size: x-large;\n}\n\nmat-toolbar {\n  background-color: brown;\n}\n\n::ng-deep .mat-form-field-appearance-outline .mat-form-field-outline {\n  color: black;\n}\n\n::ng-deep .mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9yZXNldC1wYXNzd29yZC9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFxyZXNldC1wYXNzd29yZFxccmVzZXQtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvcmVzZXQtcGFzc3dvcmQvcmVzZXQtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBQTtFQUNBLFVBQUE7QUNDRjs7QURDQTtFQUVFLGlCQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDRUY7O0FEQUE7RUFDRSx1QkFBQTtFQUNBLHdGQUFBO0FDR0Y7O0FEQUE7RUFDRSxVQUFBO0VBQ0Esd0ZBQUE7QUNHRjs7QURBQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDR0Y7O0FEREE7RUFDRSx1QkFBQTtBQ0lGOztBREZBO0VBQ0UsWUFBQTtBQ0tGOztBREZBO0VBQ0UsWUFBQTtBQ0tGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9yZXNldC1wYXNzd29yZC9yZXNldC1wYXNzd29yZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xuICB3aWR0aDogMjUlO1xufVxubWF0LWNhcmQtdGl0bGUge1xuICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTIyLCAxNDksIDI0MCk7XG4gIHBhZGRpbmctbGVmdDogMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAwcHg7XG59XG4uY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5tYXQtY2FyZC1oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgyNDQsIDI0NSwgMjQ0LCAwLjIpLFxuICAgIDAgNnB4IDIwcHggMCByZ2JhKDI0NCwgMjQ3LCAyNDUsIDAuMTkpO1xufVxuLm1hdC1jYXJkLW1haW4ge1xuICB3aWR0aDogMzUlO1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDI0NCwgMjQ1LCAyNDQsIDAuMiksXG4gICAgMCA2cHggMjBweCAwIHJnYmEoMjQ0LCAyNDcsIDI0NSwgMC4xOSk7XG59XG4udGl0bGUtY2VudGVyIHtcbiAgZmxleDogMSAxIGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiB4LWxhcmdlO1xufVxubWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbn1cbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lIHtcbiAgY29sb3I6IGJsYWNrO1xuICBcbn1cbjo6bmctZGVlcCAubWF0LWZvcm0tZmllbGQtYXBwZWFyYW5jZS1vdXRsaW5lLm1hdC1mb2N1c2VkIC5tYXQtZm9ybS1maWVsZC1vdXRsaW5lLXRoaWNrIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuIiwiYnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYnJvd247XG4gIHdpZHRoOiAyNSU7XG59XG5cbm1hdC1jYXJkLXRpdGxlIHtcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcbn1cblxuLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5tYXQtY2FyZC1oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbiAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgyNDQsIDI0NSwgMjQ0LCAwLjIpLCAwIDZweCAyMHB4IDAgcmdiYSgyNDQsIDI0NywgMjQ1LCAwLjE5KTtcbn1cblxuLm1hdC1jYXJkLW1haW4ge1xuICB3aWR0aDogMzUlO1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDI0NCwgMjQ1LCAyNDQsIDAuMiksIDAgNnB4IDIwcHggMCByZ2JhKDI0NCwgMjQ3LCAyNDUsIDAuMTkpO1xufVxuXG4udGl0bGUtY2VudGVyIHtcbiAgZmxleDogMSAxIGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiB4LWxhcmdlO1xufVxuXG5tYXQtdG9vbGJhciB7XG4gIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xufVxuXG46Om5nLWRlZXAgLm1hdC1mb3JtLWZpZWxkLWFwcGVhcmFuY2Utb3V0bGluZSAubWF0LWZvcm0tZmllbGQtb3V0bGluZSB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuOjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZC1hcHBlYXJhbmNlLW91dGxpbmUubWF0LWZvY3VzZWQgLm1hdC1mb3JtLWZpZWxkLW91dGxpbmUtdGhpY2sge1xuICBjb2xvcjogYmxhY2s7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/reset-password/reset-password.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/components/reset-password/reset-password.component.ts ***!
  \***********************************************************************/
/*! exports provided: ResetPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordComponent", function() { return ResetPasswordComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_app_shared_passwordValidator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/passwordValidator */ "./src/app/shared/passwordValidator.ts");
/* harmony import */ var src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/services/encr-decr.service */ "./src/services/encr-decr.service.ts");








let ResetPasswordComponent = class ResetPasswordComponent {
    constructor(formBuilder, userService, router, route, snackBar, encrDecr) {
        this.formBuilder = formBuilder;
        this.userService = userService;
        this.router = router;
        this.route = route;
        this.snackBar = snackBar;
        this.encrDecr = encrDecr;
        this.hide = true;
        this.hide1 = true;
        this.title = 'Reset Password';
    }
    ngOnInit() {
        this.resetPasswordForm = this.formBuilder.group({
            password: [
                '',
                [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}'),
                ],
            ],
            confirmPassword: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
        }, { validator: src_app_shared_passwordValidator__WEBPACK_IMPORTED_MODULE_6__["PasswordValidator"] });
        this.token = this.route.snapshot.paramMap.get('token');
        ///((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[#$%]).{8,20})/
    }
    onConfirm() {
        /*this.resetPassword = this.resetPasswordForm.value;
        console.log(this.resetPassword.password+" token:",this.token);
        this.resetPassword.password = this.encrDecr.set(
          '123456$#@$^@1ERF',
          this.resetPassword.password
        );
        console.log(this.resetPassword.password);*/
        const data = {
            password: this.encrDecr.set('123456$#@$^@1ERF', this.resetPasswordForm.get('confirmPassword').value),
            confirmpassword: this.encrDecr.set('123456$#@$^@1ERF', this.resetPasswordForm.get('confirmPassword').value),
        };
        // console.log("data:",data);
        // console.log("token:",this.token);
        this.userService.resetPassword(data, this.token).subscribe((response) => {
            console.log(response);
            if (response.status === 201) {
                this.snackBar.open(response.message, 'ok', { duration: 3000 });
                //this.router.navigate(['login']);
            }
        }, (error) => {
            //console.log(error);
            this.snackBar.open(error.error, 'ok', { duration: 3000 });
        });
    }
};
ResetPasswordComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"] },
    { type: src_services_encr_decr_service__WEBPACK_IMPORTED_MODULE_7__["EncrDecrService"] }
];
ResetPasswordComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-reset-password',
        template: __webpack_require__(/*! raw-loader!./reset-password.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/reset-password/reset-password.component.html"),
        styles: [__webpack_require__(/*! ./reset-password.component.scss */ "./src/app/components/reset-password/reset-password.component.scss")]
    })
], ResetPasswordComponent);



/***/ }),

/***/ "./src/app/components/review/review.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/review/review.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "button {\n  outline: none;\n}\n\n@media screen and (max-width: 1000px) {\n  .main-div {\n    width: 450px;\n  }\n}\n\n@media screen and (max-width: 800px) {\n  .main-div {\n    width: 350px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  .main-div {\n    width: 250px;\n  }\n}\n\n@media screen and (max-width: 420px) {\n  .main-div {\n    width: 230px;\n    display: flex;\n    flex-direction: column;\n    justify-content: flex-start;\n  }\n}\n\n@media screen and (max-width: 350px) {\n  .main-div {\n    width: 280px;\n    display: flex;\n    flex-direction: column;\n    justify-content: flex-start;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9yZXZpZXcvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xccmV2aWV3XFxyZXZpZXcuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvcmV2aWV3L3Jldmlldy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7QUNDSjs7QURFQTtFQUNJO0lBQ0UsWUFBQTtFQ0NKO0FBQ0Y7O0FEQ0E7RUFDRTtJQUNFLFlBQUE7RUNDRjtBQUNGOztBRENBO0VBQ0U7SUFDRSxZQUFBO0VDQ0Y7QUFDRjs7QURDQTtFQUNFO0lBQ0UsWUFBQTtJQUNBLGFBQUE7SUFDQSxzQkFBQTtJQUNBLDJCQUFBO0VDQ0Y7QUFDRjs7QURDQTtFQUNFO0lBQ0UsWUFBQTtJQUNBLGFBQUE7SUFDQSxzQkFBQTtJQUNBLDJCQUFBO0VDQ0Y7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcmV2aWV3L3Jldmlldy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJ1dHRvbntcbiAgICBvdXRsaW5lOiBub25lO1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMDAwcHgpIHtcbiAgICAubWFpbi1kaXZ7XG4gICAgICB3aWR0aDogNDUwcHg7XG4gICAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogODAwcHgpIHtcbiAgLm1haW4tZGl2e1xuICAgIHdpZHRoOiAzNTBweDtcbiAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTAwcHgpIHtcbiAgLm1haW4tZGl2e1xuICAgIHdpZHRoOiAyNTBweDtcbiAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDIwcHgpIHtcbiAgLm1haW4tZGl2e1xuICAgIHdpZHRoOiAyMzBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNTBweCkge1xuICAubWFpbi1kaXZ7XG4gICAgd2lkdGg6IDI4MHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XG4gIH1cbn1cbiIsImJ1dHRvbiB7XG4gIG91dGxpbmU6IG5vbmU7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEwMDBweCkge1xuICAubWFpbi1kaXYge1xuICAgIHdpZHRoOiA0NTBweDtcbiAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogODAwcHgpIHtcbiAgLm1haW4tZGl2IHtcbiAgICB3aWR0aDogMzUwcHg7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDUwMHB4KSB7XG4gIC5tYWluLWRpdiB7XG4gICAgd2lkdGg6IDI1MHB4O1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0MjBweCkge1xuICAubWFpbi1kaXYge1xuICAgIHdpZHRoOiAyMzBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNTBweCkge1xuICAubWFpbi1kaXYge1xuICAgIHdpZHRoOiAyODBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/components/review/review.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/review/review.component.ts ***!
  \*******************************************************/
/*! exports provided: ReviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewComponent", function() { return ReviewComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_services_review_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/review.service */ "./src/services/review.service.ts");



let ReviewComponent = class ReviewComponent {
    constructor(service) {
        this.service = service;
    }
    ngOnInit() { }
    onRating(value) {
        this.rating = value;
    }
    onSubmit() {
        console.log(this.rating);
        this.service.addReviewApp(this.review, this.rating, localStorage.getItem('token')).subscribe((data) => {
            this.rating = data.data.rating;
            this.review = data.data.review;
        });
    }
};
ReviewComponent.ctorParameters = () => [
    { type: src_services_review_service__WEBPACK_IMPORTED_MODULE_2__["ReviewService"] }
];
ReviewComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-review',
        template: __webpack_require__(/*! raw-loader!./review.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/review/review.component.html"),
        styles: [__webpack_require__(/*! ./review.component.scss */ "./src/app/components/review/review.component.scss")]
    })
], ReviewComponent);



/***/ }),

/***/ "./src/app/components/success-page/success-page.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/success-page/success-page.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".successImageDiv {\n  width: 40%;\n  height: 35%;\n}\n\nth, td {\n  -webkit-text-size-adjust: 20%;\n     -moz-text-size-adjust: 20%;\n      -ms-text-size-adjust: 20%;\n          text-size-adjust: 20%;\n}\n\n.main-div {\n  width: device-width;\n}\n\n@media screen and (max-width: 350px) {\n  img {\n    margin-left: 80px;\n  }\n\n  span {\n    font-size: 85%;\n    margin-left: 40%;\n  }\n\n  table {\n    margin-left: 20px;\n  }\n\n  main-div {\n    margin-left: 20%;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  img {\n    margin-left: 40px;\n  }\n\n  main-div, div {\n    margin-left: 25px;\n  }\n\n  span {\n    font-size: 70%;\n    margin-left: 25%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9zdWNjZXNzLXBhZ2UvQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcc3VjY2Vzcy1wYWdlXFxzdWNjZXNzLXBhZ2UuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvc3VjY2Vzcy1wYWdlL3N1Y2Nlc3MtcGFnZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7RUFDQSxXQUFBO0FDQ0o7O0FEQ0E7RUFDSSw2QkFBQTtLQUFBLDBCQUFBO01BQUEseUJBQUE7VUFBQSxxQkFBQTtBQ0VKOztBREFBO0VBQ0ksbUJBQUE7QUNHSjs7QURBQTtFQUNJO0lBQ0ksaUJBQUE7RUNHTjs7RURERTtJQUNJLGNBQUE7SUFDQSxnQkFBQTtFQ0lOOztFRERFO0lBQ0ksaUJBQUE7RUNJTjs7RURGRTtJQUNJLGdCQUFBO0VDS047QUFDRjs7QURIRTtFQUNFO0lBQ0ksaUJBQUE7RUNLTjs7RURIRTtJQUNJLGlCQUFBO0VDTU47O0VESkU7SUFDSSxjQUFBO0lBQ0EsZ0JBQUE7RUNPTjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9zdWNjZXNzLXBhZ2Uvc3VjY2Vzcy1wYWdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnN1Y2Nlc3NJbWFnZURpdntcbiAgICB3aWR0aDogNDAlO1xuICAgIGhlaWdodDogMzUlO1xufVxudGgsIHRke1xuICAgIHRleHQtc2l6ZS1hZGp1c3Q6IDIwJTtcbn1cbi5tYWluLWRpdntcbiAgICB3aWR0aDogZGV2aWNlLXdpZHRoO1xuICAgIFxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzUwcHgpIHtcbiAgICBpbWd7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiA4MHB4XG4gICAgfVxuICAgIHNwYW57XG4gICAgICAgIGZvbnQtc2l6ZTogODUlO1xuICAgICAgICBtYXJnaW4tbGVmdDogNDAlO1xuICAgICAgICBcbiAgICB9XG4gICAgdGFibGV7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIH1cbiAgICBtYWluLWRpdntcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDIwJTtcbiAgICB9XG4gIH1cbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDAwcHgpIHtcbiAgICBpbWd7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiA0MHB4XG4gICAgfVxuICAgIG1haW4tZGl2LCBkaXZ7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyNXB4O1xuICAgIH1cbiAgICBzcGFue1xuICAgICAgICBmb250LXNpemU6IDcwJTtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDI1JTsgICBcbiAgICB9XG4gIH0gXG4gICIsIi5zdWNjZXNzSW1hZ2VEaXYge1xuICB3aWR0aDogNDAlO1xuICBoZWlnaHQ6IDM1JTtcbn1cblxudGgsIHRkIHtcbiAgdGV4dC1zaXplLWFkanVzdDogMjAlO1xufVxuXG4ubWFpbi1kaXYge1xuICB3aWR0aDogZGV2aWNlLXdpZHRoO1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNTBweCkge1xuICBpbWcge1xuICAgIG1hcmdpbi1sZWZ0OiA4MHB4O1xuICB9XG5cbiAgc3BhbiB7XG4gICAgZm9udC1zaXplOiA4NSU7XG4gICAgbWFyZ2luLWxlZnQ6IDQwJTtcbiAgfVxuXG4gIHRhYmxlIHtcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcbiAgfVxuXG4gIG1haW4tZGl2IHtcbiAgICBtYXJnaW4tbGVmdDogMjAlO1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0MDBweCkge1xuICBpbWcge1xuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xuICB9XG5cbiAgbWFpbi1kaXYsIGRpdiB7XG4gICAgbWFyZ2luLWxlZnQ6IDI1cHg7XG4gIH1cblxuICBzcGFuIHtcbiAgICBmb250LXNpemU6IDcwJTtcbiAgICBtYXJnaW4tbGVmdDogMjUlO1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/components/success-page/success-page.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/success-page/success-page.component.ts ***!
  \*******************************************************************/
/*! exports provided: SuccessPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessPageComponent", function() { return SuccessPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _review_review_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../review/review.component */ "./src/app/components/review/review.component.ts");




let SuccessPageComponent = class SuccessPageComponent {
    constructor(dialog) {
        this.dialog = dialog;
        this.id = localStorage.getItem('orderId');
        this.orderId = parseInt(this.id, 4) * 7893;
    }
    ngOnInit() {
    }
    openDialog() {
        this.dialog.open(_review_review_component__WEBPACK_IMPORTED_MODULE_3__["ReviewComponent"]);
    }
};
SuccessPageComponent.ctorParameters = () => [
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] }
];
SuccessPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-success-page',
        template: __webpack_require__(/*! raw-loader!./success-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/success-page/success-page.component.html"),
        styles: [__webpack_require__(/*! ./success-page.component.scss */ "./src/app/components/success-page/success-page.component.scss")]
    })
], SuccessPageComponent);



/***/ }),

/***/ "./src/app/components/update-book/update-book.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/components/update-book/update-book.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "mat-toolbar {\n  background-color: brown;\n}\n\nbutton {\n  background-color: brown;\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy91cGRhdGUtYm9vay9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFx1cGRhdGUtYm9va1xcdXBkYXRlLWJvb2suY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvdXBkYXRlLWJvb2svdXBkYXRlLWJvb2suY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBQTtBQ0NGOztBRENBO0VBQ0UsdUJBQUE7RUFDQSxhQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3VwZGF0ZS1ib29rL3VwZGF0ZS1ib29rLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsibWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbn1cbmJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6IGJyb3duO1xuICBvdXRsaW5lOiBub25lO1xufVxuIiwibWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbn1cblxuYnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYnJvd247XG4gIG91dGxpbmU6IG5vbmU7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/update-book/update-book.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/update-book/update-book.component.ts ***!
  \*****************************************************************/
/*! exports provided: UpdateBookComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateBookComponent", function() { return UpdateBookComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var src_services_vendor_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/services/vendor.service */ "./src/services/vendor.service.ts");






let UpdateBookComponent = class UpdateBookComponent {
    constructor(vendorService, messageService, dialogRef, data) {
        this.vendorService = vendorService;
        this.messageService = messageService;
        this.dialogRef = dialogRef;
        this.data = data;
        this.updateBookForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            price: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            quantity: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    }
    ngOnInit() { }
    onFormSubmit() {
        this.dialogRef.close();
        this.vendorService
            .updateBook(this.updateBookForm.value, this.data.bookId)
            .subscribe((data) => {
            this.messageService.onBooksCount();
            if (localStorage.getItem('pageNum') === null) {
                this.pageNum = 1;
            }
            else {
                this.pageNum = Number(localStorage.getItem('pageNum'));
            }
            this.messageService.changeMessage(this.pageNum);
        });
    }
};
UpdateBookComponent.ctorParameters = () => [
    { type: src_services_vendor_service__WEBPACK_IMPORTED_MODULE_5__["VendorService"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_4__["MessageService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatDialogRef"] },
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"],] }] }
];
UpdateBookComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-update-book',
        template: __webpack_require__(/*! raw-loader!./update-book.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/update-book/update-book.component.html"),
        styles: [__webpack_require__(/*! ./update-book.component.scss */ "./src/app/components/update-book/update-book.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"]))
], UpdateBookComponent);



/***/ }),

/***/ "./src/app/components/vendor-dashboard/vendor-dashboard.component.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/components/vendor-dashboard/vendor-dashboard.component.scss ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolBarDiv {\n  position: fixed;\n}\n\nmat-toolbar {\n  width: 100%;\n  background-color: #a03037;\n  top: 0;\n  position: fixed;\n  z-index: 100;\n}\n\n.search-mat-card {\n  margin-left: 2%;\n  width: 40%;\n  height: 60%;\n  padding: 0px;\n}\n\n.searchIcon {\n  opacity: 0.5;\n}\n\n.searchIcon:hover {\n  opacity: 1;\n}\n\n.searchInput {\n  height: 90%;\n  width: 90%;\n  border: none;\n  outline: none;\n}\n\n.titleText {\n  margin-left: 12%;\n  color: white;\n}\n\n@media only screen and (max-width: 720px) {\n  .titleText {\n    font-size: medium;\n    margin-left: 2%;\n    color: white;\n  }\n}\n\n.bookText {\n  font-size: 90%;\n  color: white;\n}\n\n.accountIcon {\n  font-size: 200%;\n  opacity: 0.5;\n}\n\n.accountIcon:hover {\n  opacity: 1;\n}\n\nbutton {\n  outline: none;\n}\n\n.spanClass {\n  flex-grow: 0.5;\n}\n\n.bookInput {\n  padding: 1% 4% 1%;\n  border: none;\n  outline: none;\n}\n\n.addBookButton {\n  color: white;\n  width: 15%;\n  background-color: #a03037;\n  border-radius: 2vw;\n}\n\n::-webkit-input-placeholder {\n  font-size: 90%;\n}\n\n::-moz-placeholder {\n  font-size: 90%;\n}\n\n::-ms-input-placeholder {\n  font-size: 90%;\n}\n\n::placeholder {\n  font-size: 90%;\n}\n\n.mainSellingSpan {\n  font-weight: bold;\n  font-size: 150%;\n}\n\n.subSellingSpan {\n  font-weight: 500;\n}\n\n.mainContent {\n  width: 100%;\n  height: 40%;\n}\n\n.mainContainer-lt-md {\n  width: 100%;\n  height: 35%;\n  margin-top: 50px;\n  background-image: url('bookstore-wallpaper2.jpg');\n}\n\n.mainContainer-lg {\n  width: 100%;\n  height: 25%;\n  margin-top: 50px;\n  background-image: url('bookstore-wallpaper2.jpg');\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy92ZW5kb3ItZGFzaGJvYXJkL0M6XFxVc2Vyc1xca2FtYW5cXERlc2t0b3BcXGZpbmFsIHByb2plY3RzXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3RlclxcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXIvc3JjXFxhcHBcXGNvbXBvbmVudHNcXHZlbmRvci1kYXNoYm9hcmRcXHZlbmRvci1kYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvdmVuZG9yLWRhc2hib2FyZC92ZW5kb3ItZGFzaGJvYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtBQ0NGOztBRENBO0VBQ0UsV0FBQTtFQUNBLHlCQUFBO0VBQ0EsTUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDRUY7O0FEQUE7RUFDRSxlQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDR0Y7O0FEREE7RUFDRSxZQUFBO0FDSUY7O0FERkE7RUFDRSxVQUFBO0FDS0Y7O0FESEE7RUFDRSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDTUY7O0FESkE7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUNPRjs7QURMQTtFQUNFO0lBQ0UsaUJBQUE7SUFDQSxlQUFBO0lBQ0EsWUFBQTtFQ1FGO0FBQ0Y7O0FETkE7RUFDRSxjQUFBO0VBQ0EsWUFBQTtBQ1FGOztBRE5BO0VBQ0UsZUFBQTtFQUNBLFlBQUE7QUNTRjs7QURQQTtFQUNFLFVBQUE7QUNVRjs7QURSQTtFQUNFLGFBQUE7QUNXRjs7QURUQTtFQUNFLGNBQUE7QUNZRjs7QURUQTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNZRjs7QURWQTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQ2FGOztBRFZBO0VBQ0UsY0FBQTtBQ2FGOztBRGRBO0VBQ0UsY0FBQTtBQ2FGOztBRGRBO0VBQ0UsY0FBQTtBQ2FGOztBRGRBO0VBQ0UsY0FBQTtBQ2FGOztBRFhBO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0FDY0Y7O0FEWkE7RUFDRSxnQkFBQTtBQ2VGOztBRGJBO0VBQ0UsV0FBQTtFQUNBLFdBQUE7QUNnQkY7O0FEZEE7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsaURBQUE7QUNpQkY7O0FEZkE7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsaURBQUE7QUNrQkYiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3ZlbmRvci1kYXNoYm9hcmQvdmVuZG9yLWRhc2hib2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sQmFyRGl2IHtcbiAgcG9zaXRpb246IGZpeGVkO1xufVxubWF0LXRvb2xiYXIge1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgdG9wOiAwO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHotaW5kZXg6IDEwMDtcbn1cbi5zZWFyY2gtbWF0LWNhcmQge1xuICBtYXJnaW4tbGVmdDogMiU7XG4gIHdpZHRoOiA0MCU7XG4gIGhlaWdodDogNjAlO1xuICBwYWRkaW5nOiAwcHg7XG59XG4uc2VhcmNoSWNvbiB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cbi5zZWFyY2hJY29uOmhvdmVyIHtcbiAgb3BhY2l0eTogMTtcbn1cbi5zZWFyY2hJbnB1dCB7XG4gIGhlaWdodDogOTAlO1xuICB3aWR0aDogOTAlO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4udGl0bGVUZXh0IHtcbiAgbWFyZ2luLWxlZnQ6IDEyJTtcbiAgY29sb3I6IHdoaXRlO1xufVxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAudGl0bGVUZXh0IHtcbiAgICBmb250LXNpemU6IG1lZGl1bTtcbiAgICBtYXJnaW4tbGVmdDogMiU7XG4gICAgY29sb3I6IHdoaXRlO1xuICB9XG59XG4uYm9va1RleHQge1xuICBmb250LXNpemU6IDkwJTtcbiAgY29sb3I6IHdoaXRlO1xufVxuLmFjY291bnRJY29uIHtcbiAgZm9udC1zaXplOiAyMDAlO1xuICBvcGFjaXR5OiAwLjU7XG59XG4uYWNjb3VudEljb246aG92ZXIge1xuICBvcGFjaXR5OiAxO1xufVxuYnV0dG9uIHtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5zcGFuQ2xhc3Mge1xuICBmbGV4LWdyb3c6IDAuNTtcbn1cblxuLmJvb2tJbnB1dCB7XG4gIHBhZGRpbmc6IDElIDQlIDElO1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uYWRkQm9va0J1dHRvbiB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgd2lkdGg6IDE1JTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgYm9yZGVyLXJhZGl1czogMnZ3O1xufVxuXG46OnBsYWNlaG9sZGVyIHtcbiAgZm9udC1zaXplOiA5MCU7XG59XG4ubWFpblNlbGxpbmdTcGFuIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMTUwJTtcbn1cbi5zdWJTZWxsaW5nU3BhbiB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG4ubWFpbkNvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA0MCU7XG59XG4ubWFpbkNvbnRhaW5lci1sdC1tZCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDM1JTtcbiAgbWFyZ2luLXRvcDogNTBweDtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi8uLi9hc3NldHMvaW1hZ2VzL2Jvb2tzdG9yZS13YWxscGFwZXIyLmpwZycpO1xufVxuLm1haW5Db250YWluZXItbGcge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAyNSU7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vLi4vYXNzZXRzL2ltYWdlcy9ib29rc3RvcmUtd2FsbHBhcGVyMi5qcGcnKTtcbn1cbiIsIi50b29sQmFyRGl2IHtcbiAgcG9zaXRpb246IGZpeGVkO1xufVxuXG5tYXQtdG9vbGJhciB7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTAzMDM3O1xuICB0b3A6IDA7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgei1pbmRleDogMTAwO1xufVxuXG4uc2VhcmNoLW1hdC1jYXJkIHtcbiAgbWFyZ2luLWxlZnQ6IDIlO1xuICB3aWR0aDogNDAlO1xuICBoZWlnaHQ6IDYwJTtcbiAgcGFkZGluZzogMHB4O1xufVxuXG4uc2VhcmNoSWNvbiB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cblxuLnNlYXJjaEljb246aG92ZXIge1xuICBvcGFjaXR5OiAxO1xufVxuXG4uc2VhcmNoSW5wdXQge1xuICBoZWlnaHQ6IDkwJTtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4udGl0bGVUZXh0IHtcbiAgbWFyZ2luLWxlZnQ6IDEyJTtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4gIC50aXRsZVRleHQge1xuICAgIGZvbnQtc2l6ZTogbWVkaXVtO1xuICAgIG1hcmdpbi1sZWZ0OiAyJTtcbiAgICBjb2xvcjogd2hpdGU7XG4gIH1cbn1cbi5ib29rVGV4dCB7XG4gIGZvbnQtc2l6ZTogOTAlO1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5hY2NvdW50SWNvbiB7XG4gIGZvbnQtc2l6ZTogMjAwJTtcbiAgb3BhY2l0eTogMC41O1xufVxuXG4uYWNjb3VudEljb246aG92ZXIge1xuICBvcGFjaXR5OiAxO1xufVxuXG5idXR0b24ge1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uc3BhbkNsYXNzIHtcbiAgZmxleC1ncm93OiAwLjU7XG59XG5cbi5ib29rSW5wdXQge1xuICBwYWRkaW5nOiAxJSA0JSAxJTtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG4uYWRkQm9va0J1dHRvbiB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgd2lkdGg6IDE1JTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2EwMzAzNztcbiAgYm9yZGVyLXJhZGl1czogMnZ3O1xufVxuXG46OnBsYWNlaG9sZGVyIHtcbiAgZm9udC1zaXplOiA5MCU7XG59XG5cbi5tYWluU2VsbGluZ1NwYW4ge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAxNTAlO1xufVxuXG4uc3ViU2VsbGluZ1NwYW4ge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG4ubWFpbkNvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA0MCU7XG59XG5cbi5tYWluQ29udGFpbmVyLWx0LW1kIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMzUlO1xuICBtYXJnaW4tdG9wOiA1MHB4O1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi8uLi9hc3NldHMvaW1hZ2VzL2Jvb2tzdG9yZS13YWxscGFwZXIyLmpwZ1wiKTtcbn1cblxuLm1haW5Db250YWluZXItbGcge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAyNSU7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uLy4uL2Fzc2V0cy9pbWFnZXMvYm9va3N0b3JlLXdhbGxwYXBlcjIuanBnXCIpO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/vendor-dashboard/vendor-dashboard.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/components/vendor-dashboard/vendor-dashboard.component.ts ***!
  \***************************************************************************/
/*! exports provided: VendorDashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VendorDashboardComponent", function() { return VendorDashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _add_book_add_book_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../add-book/add-book.component */ "./src/app/components/add-book/add-book.component.ts");
/* harmony import */ var src_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/message.service */ "./src/services/message.service.ts");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../edit-profile/edit-profile.component */ "./src/app/components/edit-profile/edit-profile.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");








let VendorDashboardComponent = class VendorDashboardComponent {
    constructor(dialog, messageService, userService, router) {
        this.dialog = dialog;
        this.messageService = messageService;
        this.userService = userService;
        this.router = router;
        this.isBookFormOpened = false;
        this.isProfile = 'true';
        this.isProfileAvailable = false;
        this.pageTemp = 1;
    }
    ngOnInit() {
        this.messageService.onBooksCount();
        if (localStorage.getItem('pageNum') === null) {
            this.pageNum = 1;
        }
        else {
            this.pageNum = Number(localStorage.getItem('pageNum'));
        }
        this.messageService.changeMessage(this.pageNum);
        this.username = localStorage.getItem('name');
        this.usermail = localStorage.getItem('email');
        this.userProfile = localStorage.getItem('image');
        if (this.userProfile !== 'null') {
            this.isProfileAvailable = true;
            this.profile = this.userProfile;
        }
        else {
            console.log(localStorage.getItem('image'));
            this.isProfileAvailable = false;
        }
    }
    openDialogztoedit() {
        this.dialog.open(_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_6__["EditProfileComponent"]);
    }
    openBookForm() {
        this.dialog.open(_add_book_add_book_component__WEBPACK_IMPORTED_MODULE_3__["AddBookComponent"], {
            panelClass: 'custom-modalbox',
        });
    }
    navigateTo() {
        this.router.navigate(['/vendor-dashboard']);
    }
    onKey(event) {
        this.messageService.searchBook(event);
    }
    Logout() {
        console.log('CAME TO LOGOUT');
        localStorage.clear();
        console.log(localStorage.length);
        this.router.navigate(['/dashboard']);
    }
    OnSelectedFile(event) {
        console.log(event.target.files[0]);
        if (event.target.files.length > 0) {
            this.file = event.target.files[0];
            const formData = new FormData();
            formData.append('file', this.file);
            this.file.inProgress = true;
            console.log('FormData:', formData.get('file'));
            this.userService
                .uploadProfie(formData, this.isProfile)
                .subscribe((result) => {
                console.log('PROFILE RESULT:', result);
                if (result.status === 200) {
                    localStorage.setItem('image', result.data);
                    this.profile = result.data;
                    console.log(this.profile);
                }
            });
        }
    }
};
VendorDashboardComponent.ctorParameters = () => [
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] },
    { type: src_services_message_service__WEBPACK_IMPORTED_MODULE_4__["MessageService"] },
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] }
];
VendorDashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-vendor-dashboard',
        template: __webpack_require__(/*! raw-loader!./vendor-dashboard.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/vendor-dashboard/vendor-dashboard.component.html"),
        styles: [__webpack_require__(/*! ./vendor-dashboard.component.scss */ "./src/app/components/vendor-dashboard/vendor-dashboard.component.scss")]
    })
], VendorDashboardComponent);



/***/ }),

/***/ "./src/app/components/verication-success-page/verication-success-page.component.scss":
/*!*******************************************************************************************!*\
  !*** ./src/app/components/verication-success-page/verication-success-page.component.scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".container {\n  height: 100%;\n  width: 100%;\n}\n\n.successImg {\n  width: 100%;\n  height: 50%;\n}\n\n.successMsg {\n  width: 100%;\n  height: 50%;\n}\n\n.mat-title {\n  width: 100%;\n  height: 30%;\n  text-align: center;\n  background-color: brown;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy92ZXJpY2F0aW9uLXN1Y2Nlc3MtcGFnZS9DOlxcVXNlcnNcXGthbWFuXFxEZXNrdG9wXFxmaW5hbCBwcm9qZWN0c1xcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXJcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyL3NyY1xcYXBwXFxjb21wb25lbnRzXFx2ZXJpY2F0aW9uLXN1Y2Nlc3MtcGFnZVxcdmVyaWNhdGlvbi1zdWNjZXNzLXBhZ2UuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvdmVyaWNhdGlvbi1zdWNjZXNzLXBhZ2UvdmVyaWNhdGlvbi1zdWNjZXNzLXBhZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxZQUFBO0VBQ0EsV0FBQTtBQ0FKOztBREVBO0VBRUksV0FBQTtFQUNBLFdBQUE7QUNBSjs7QURFQTtFQUVJLFdBQUE7RUFDQSxXQUFBO0FDQUo7O0FERUE7RUFFSSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3ZlcmljYXRpb24tc3VjY2Vzcy1wYWdlL3ZlcmljYXRpb24tc3VjY2Vzcy1wYWdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lclxue1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMTAwJTtcbn1cbi5zdWNjZXNzSW1nXG57XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG59XG4uc3VjY2Vzc01zZ1xue1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogNTAlO1xufVxuLm1hdC10aXRsZVxue1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMzAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbiAgICBjb2xvcjogd2hpdGU7XG59IiwiLmNvbnRhaW5lciB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5zdWNjZXNzSW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNTAlO1xufVxuXG4uc3VjY2Vzc01zZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwJTtcbn1cblxuLm1hdC10aXRsZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDMwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBicm93bjtcbiAgY29sb3I6IHdoaXRlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/verication-success-page/verication-success-page.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/verication-success-page/verication-success-page.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: VericationSuccessPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VericationSuccessPageComponent", function() { return VericationSuccessPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");





let VericationSuccessPageComponent = class VericationSuccessPageComponent {
    constructor(route, router, service, snackbar) {
        this.route = route;
        this.router = router;
        this.service = service;
        this.snackbar = snackbar;
        this.token = this.route.snapshot.paramMap.get('token');
        this.service.verifyUser(this.token).subscribe((result) => {
            if (result.status == 200) {
                this.router.navigate(['/verificationSuccess/:this.token']);
            }
        }, (error) => {
            this.snackbar.open(error.error.message, 'ok', { duration: 5000 });
        });
        console.log("token:", this.token);
    }
    onclick() {
        this.router.navigate(['/dashboard']);
    }
    ngOnInit() {
    }
};
VericationSuccessPageComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"] }
];
VericationSuccessPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-verication-success-page',
        template: __webpack_require__(/*! raw-loader!./verication-success-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/verication-success-page/verication-success-page.component.html"),
        styles: [__webpack_require__(/*! ./verication-success-page.component.scss */ "./src/app/components/verication-success-page/verication-success-page.component.scss")]
    })
], VericationSuccessPageComponent);



/***/ }),

/***/ "./src/app/components/verification/verification.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/verification/verification.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".container {\n  width: 100%;\n  height: 100%;\n}\n\n@media screen and (max-width: 599x) {\n  mat-card {\n    font-size: 16px;\n    background-color: red;\n    width: auto;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy92ZXJpZmljYXRpb24vQzpcXFVzZXJzXFxrYW1hblxcRGVza3RvcFxcZmluYWwgcHJvamVjdHNcXE9ubGluZS1Cb29rc3RvcmUtQXBwLUFuZ3VsYXItbWFzdGVyXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3Rlci9zcmNcXGFwcFxcY29tcG9uZW50c1xcdmVyaWZpY2F0aW9uXFx2ZXJpZmljYXRpb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvdmVyaWZpY2F0aW9uL3ZlcmlmaWNhdGlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDQ0o7O0FERUE7RUFDSTtJQUNJLGVBQUE7SUFDRCxxQkFBQTtJQUNDLFdBQUE7RUNDTjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy92ZXJpZmljYXRpb24vdmVyaWZpY2F0aW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lcntcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU5OXgpIHtcbiAgICBtYXQtY2FyZHtcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgIGJhY2tncm91bmQtY29sb3I6ICByZWQ7XG4gICAgICAgIHdpZHRoOiBhdXRvO1xuICAgIH1cbn0iLCIuY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTk5eCkge1xuICBtYXQtY2FyZCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbiAgICB3aWR0aDogYXV0bztcbiAgfVxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/verification/verification.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/verification/verification.component.ts ***!
  \*******************************************************************/
/*! exports provided: VerificationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerificationComponent", function() { return VerificationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/user.service */ "./src/services/user.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");





let VerificationComponent = class VerificationComponent {
    constructor(route, userservice, router, snackBar) {
        this.route = route;
        this.userservice = userservice;
        this.router = router;
        this.snackBar = snackBar;
    }
    ngOnInit() {
        this.token = this.route.snapshot.paramMap.get('token');
    }
    onVerify() {
        this.userservice.verification(this.token).subscribe((response) => {
            console.log(response);
            if (response.statusCode === 202) {
                this.snackBar.open(response.message, 'ok', { duration: 3000 });
                this.router.navigate(['login']);
            }
        }, (error) => {
            this.snackBar.open(error.error.error, 'ok', { duration: 3000 });
        });
    }
};
VerificationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: src_services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"] }
];
VerificationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-verification',
        template: __webpack_require__(/*! raw-loader!./verification.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/verification/verification.component.html"),
        styles: [__webpack_require__(/*! ./verification.component.scss */ "./src/app/components/verification/verification.component.scss")]
    })
], VerificationComponent);



/***/ }),

/***/ "./src/app/components/view-wishlist/view-wishlist.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/components/view-wishlist/view-wishlist.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".price {\n  font-size: 12px;\n  color: #A03037;\n  font-weight: bold;\n  margin-left: -170px;\n}\n\n.title-left {\n  font-size: 15px;\n  margin-bottom: -13px;\n  font-weight: lighter;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n}\n\n.mat-dialog-title {\n  font-size: 15px;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n}\n\n.span {\n  font-size: 18px;\n  font-style: normal;\n  font-family: Arial, Helvetica, sans-serif;\n  font-weight: normal;\n  color: steelblue;\n}\n\n.author {\n  font-size: 12px;\n  color: black;\n  margin-left: -170px;\n  margin-top: 15px;\n  padding-bottom: 19px;\n}\n\n.info {\n  font-size: 12px;\n  color: black;\n  margin-left: -170px;\n  padding-bottom: 19px;\n}\n\n.name {\n  font-size: 16px;\n  color: black;\n  margin-top: -50px;\n  margin-left: -170px;\n  font-family: Arial, Helvetica, sans-serif;\n  font-style: normal;\n  font-weight: bold;\n}\n\n.bookImageDiv {\n  background-color: #f0e9e9;\n  width: 120px;\n  height: 130px;\n  margin-top: -31px;\n  margin-left: -100px;\n  margin-bottom: 15px;\n}\n\n.a {\n  line-height: normal;\n}\n\nimg {\n  padding: 3%;\n  width: 90px;\n  height: 90px;\n  margin-left: 15px;\n  margin-top: 20px;\n}\n\n.bookInfoDiv {\n  padding: 7% 10% 10% 10%;\n}\n\n.mat-raised-button {\n  font-weight: 100;\n  font-size: 13px;\n  padding-bottom: 30px;\n  height: 18px;\n  width: 105px;\n  background: #A03037;\n  color: whitesmoke;\n  text-align: center;\n  margin-top: 8px;\n  margin-bottom: 10px;\n  margin-left: -5px;\n}\n\n.mat-stroked-button {\n  font-weight: 100;\n  font-size: 13px;\n  padding-bottom: 30px;\n  height: 18px;\n  width: 128px;\n  background: khaki;\n  color: black;\n  text-align: center;\n  margin-top: 8px;\n  margin-bottom: 10px;\n  margin-right: -5px;\n}\n\n.title-center {\n  flex: 1 1 auto;\n  text-align: center;\n}\n\n.box {\n  width: 300px;\n  height: 50px;\n  border: 1px solid whitesmoke;\n  border-radius: 1px;\n  align-items: center;\n  margin-left: 80px;\n  margin-top: -30px;\n  border: 2px solid;\n}\n\n.mat-toolbar {\n  background-color: #f0e9e9;\n  height: 30px;\n  padding-bottom: 15px;\n  margin-top: -25px;\n  width: 100%;\n  margin-bottom: 13px;\n}\n\n.mat-divider {\n  border: 1px solid;\n  color: #f0e9e9;\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy92aWV3LXdpc2hsaXN0L0M6XFxVc2Vyc1xca2FtYW5cXERlc2t0b3BcXGZpbmFsIHByb2plY3RzXFxPbmxpbmUtQm9va3N0b3JlLUFwcC1Bbmd1bGFyLW1hc3RlclxcT25saW5lLUJvb2tzdG9yZS1BcHAtQW5ndWxhci1tYXN0ZXIvc3JjXFxhcHBcXGNvbXBvbmVudHNcXHZpZXctd2lzaGxpc3RcXHZpZXctd2lzaGxpc3QuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvdmlldy13aXNobGlzdC92aWV3LXdpc2hsaXN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUVBLG1CQUFBO0FDQUY7O0FER0E7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUNBQUE7QUNBQTs7QURJQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHlDQUFBO0FDREE7O0FESUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSx5Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNEQTs7QURNQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0FDSEE7O0FES0E7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7QUNGQTs7QURPQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHlDQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0pBOztBRFFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQ0xBOztBRFVBO0VBQ0UsbUJBQUE7QUNQRjs7QURVQTtFQUNBLFdBQUE7RUFHQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNUQTs7QURXQTtFQUNBLHVCQUFBO0FDUkE7O0FEYUE7RUFDQSxnQkFBQTtFQUNFLGVBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNWRjs7QURjQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFFQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDWkY7O0FEZUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNaQTs7QURlQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FDWkE7O0FEZUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FDWkE7O0FEaUJBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ2RBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy92aWV3LXdpc2hsaXN0L3ZpZXctd2lzaGxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucHJpY2V7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNBMDMwMzc7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuLy8gICBtYXJnaW4tdG9wOiAyMnB4O1xuICBtYXJnaW4tbGVmdDogLTE3MHB4O1xufVxuXG4udGl0bGUtbGVmdHtcbmZvbnQtc2l6ZTogMTVweDtcbm1hcmdpbi1ib3R0b206IC0xM3B4O1xuZm9udC13ZWlnaHQ6IGxpZ2h0ZXI7XG5mb250LXN0eWxlOiBub3JtYWw7XG5mb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbn1cblxuXG4ubWF0LWRpYWxvZy10aXRsZXtcbmZvbnQtc2l6ZTogMTVweDtcbmZvbnQtc3R5bGU6IG5vcm1hbDtcbmZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xufVxuXG4uc3BhbntcbmZvbnQtc2l6ZTogMThweDtcbmZvbnQtc3R5bGU6IG5vcm1hbDtcbmZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xuZm9udC13ZWlnaHQ6IG5vcm1hbDs7XG5jb2xvcjogc3RlZWxibHVlO1xuXG5cbn1cblxuLmF1dGhvcntcbmZvbnQtc2l6ZTogMTJweDtcbmNvbG9yOiBibGFjaztcbm1hcmdpbi1sZWZ0OiAtMTcwcHg7XG5tYXJnaW4tdG9wOiAxNXB4O1xucGFkZGluZy1ib3R0b206IDE5cHg7XG59XG4uaW5mb3tcbmZvbnQtc2l6ZTogMTJweDtcbmNvbG9yOiBibGFjaztcbm1hcmdpbi1sZWZ0OiAtMTcwcHg7XG5wYWRkaW5nLWJvdHRvbTogMTlweDtcbn1cblxuXG5cbi5uYW1le1xuZm9udC1zaXplOiAxNnB4O1xuY29sb3I6IGJsYWNrO1xubWFyZ2luLXRvcDogLTUwcHg7XG5tYXJnaW4tbGVmdDogLTE3MHB4O1xuZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG5mb250LXN0eWxlOiBub3JtYWw7XG5mb250LXdlaWdodDogYm9sZDtcbn1cblxuXG4uYm9va0ltYWdlRGl2IHtcbmJhY2tncm91bmQtY29sb3I6IHJnYigyNDAsIDIzMywgMjMzKTtcbndpZHRoOiAxMjBweDtcbmhlaWdodDogMTMwcHg7XG5tYXJnaW4tdG9wOiAtMzFweDtcbm1hcmdpbi1sZWZ0OiAtMTAwcHg7XG5tYXJnaW4tYm90dG9tOiAxNXB4O1xuXG5cbn1cblxuLmF7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG59XG5cbmltZyB7XG5wYWRkaW5nOiAzJTtcbi8vICAgd2lkdGg6IDgwJTtcbi8vICAgaGVpZ2h0OiAzMHZoO1xud2lkdGg6IDkwcHg7XG5oZWlnaHQ6IDkwcHg7XG5tYXJnaW4tbGVmdDoxNXB4O1xubWFyZ2luLXRvcDogMjBweDtcbn1cbi5ib29rSW5mb0RpdiB7XG5wYWRkaW5nOiA3JSAxMCUgMTAlIDEwJTtcbn1cblxuXG5cbi5tYXQtcmFpc2VkLWJ1dHRvbiB7XG5mb250LXdlaWdodDogMTAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIHBhZGRpbmctYm90dG9tOiAzMHB4O1xuICBoZWlnaHQ6IDE4cHg7XG4gIHdpZHRoOiAxMDVweDtcbiAgYmFja2dyb3VuZDogI0EwMzAzNztcbiAgY29sb3I6d2hpdGVzbW9rZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiA4cHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAtNXB4OyBcbn1cblxuXG4ubWF0LXN0cm9rZWQtYnV0dG9ue1xuICBmb250LXdlaWdodDogMTAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIHBhZGRpbmctYm90dG9tOiAzMHB4O1xuICBoZWlnaHQ6IDE4cHg7XG4gIHdpZHRoOjEyOHB4O1xuICAvLyBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gdG9wIGxlZnQsICNmZmZmZmYgMCUsICNmZmNjMDAgMCUpO1xuICBiYWNrZ3JvdW5kOiAga2hha2k7XG4gIGNvbG9yOiBibGFjaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiA4cHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogLTVweDtcbn1cblxuLnRpdGxlLWNlbnRlciB7XG5mbGV4OiAxIDEgYXV0bztcbnRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmJveHtcbndpZHRoOiAzMDBweDtcbmhlaWdodDogNTBweDsgIFxuYm9yZGVyOiAxcHggc29saWQgd2hpdGVzbW9rZTtcbmJvcmRlci1yYWRpdXM6IDFweDtcbmFsaWduLWl0ZW1zOiBjZW50ZXI7XG5tYXJnaW4tbGVmdDogODBweDtcbm1hcmdpbi10b3A6IC0zMHB4O1xuYm9yZGVyOiAycHggc29saWQ7XG59XG5cbi5tYXQtdG9vbGJhciB7XG5iYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjQwLCAyMzMsIDIzMyk7XG5oZWlnaHQ6IDMwcHg7XG5wYWRkaW5nLWJvdHRvbTogMTVweDtcbm1hcmdpbi10b3A6IC0yNXB4O1xud2lkdGg6IDEwMCU7XG5tYXJnaW4tYm90dG9tOiAxM3B4O1xufVxuXG5cblxuLm1hdC1kaXZpZGVye1xuYm9yZGVyOiAxcHggc29saWQ7XG5jb2xvcjogcmdiKDI0MCwgMjMzLCAyMzMpO1xubWFyZ2luLXRvcDogNXB4O1xufVxuXG5cblxuXG5cbiIsIi5wcmljZSB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNBMDMwMzc7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tbGVmdDogLTE3MHB4O1xufVxuXG4udGl0bGUtbGVmdCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogLTEzcHg7XG4gIGZvbnQtd2VpZ2h0OiBsaWdodGVyO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xufVxuXG4ubWF0LWRpYWxvZy10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcbn1cblxuLnNwYW4ge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIGNvbG9yOiBzdGVlbGJsdWU7XG59XG5cbi5hdXRob3Ige1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IC0xNzBweDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgcGFkZGluZy1ib3R0b206IDE5cHg7XG59XG5cbi5pbmZvIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogYmxhY2s7XG4gIG1hcmdpbi1sZWZ0OiAtMTcwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAxOXB4O1xufVxuXG4ubmFtZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tdG9wOiAtNTBweDtcbiAgbWFyZ2luLWxlZnQ6IC0xNzBweDtcbiAgZm9udC1mYW1pbHk6IEFyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWY7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5ib29rSW1hZ2VEaXYge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjBlOWU5O1xuICB3aWR0aDogMTIwcHg7XG4gIGhlaWdodDogMTMwcHg7XG4gIG1hcmdpbi10b3A6IC0zMXB4O1xuICBtYXJnaW4tbGVmdDogLTEwMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufVxuXG4uYSB7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG59XG5cbmltZyB7XG4gIHBhZGRpbmc6IDMlO1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiA5MHB4O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cblxuLmJvb2tJbmZvRGl2IHtcbiAgcGFkZGluZzogNyUgMTAlIDEwJSAxMCU7XG59XG5cbi5tYXQtcmFpc2VkLWJ1dHRvbiB7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gIGhlaWdodDogMThweDtcbiAgd2lkdGg6IDEwNXB4O1xuICBiYWNrZ3JvdW5kOiAjQTAzMDM3O1xuICBjb2xvcjogd2hpdGVzbW9rZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiA4cHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAtNXB4O1xufVxuXG4ubWF0LXN0cm9rZWQtYnV0dG9uIHtcbiAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBwYWRkaW5nLWJvdHRvbTogMzBweDtcbiAgaGVpZ2h0OiAxOHB4O1xuICB3aWR0aDogMTI4cHg7XG4gIGJhY2tncm91bmQ6IGtoYWtpO1xuICBjb2xvcjogYmxhY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogOHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IC01cHg7XG59XG5cbi50aXRsZS1jZW50ZXIge1xuICBmbGV4OiAxIDEgYXV0bztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uYm94IHtcbiAgd2lkdGg6IDMwMHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlc21va2U7XG4gIGJvcmRlci1yYWRpdXM6IDFweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWxlZnQ6IDgwcHg7XG4gIG1hcmdpbi10b3A6IC0zMHB4O1xuICBib3JkZXI6IDJweCBzb2xpZDtcbn1cblxuLm1hdC10b29sYmFyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YwZTllOTtcbiAgaGVpZ2h0OiAzMHB4O1xuICBwYWRkaW5nLWJvdHRvbTogMTVweDtcbiAgbWFyZ2luLXRvcDogLTI1cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tYm90dG9tOiAxM3B4O1xufVxuXG4ubWF0LWRpdmlkZXIge1xuICBib3JkZXI6IDFweCBzb2xpZDtcbiAgY29sb3I6ICNmMGU5ZTk7XG4gIG1hcmdpbi10b3A6IDVweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/view-wishlist/view-wishlist.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/view-wishlist/view-wishlist.component.ts ***!
  \*********************************************************************/
/*! exports provided: ViewWishlistComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewWishlistComponent", function() { return ViewWishlistComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");



let ViewWishlistComponent = class ViewWishlistComponent {
    constructor(data) {
        this.data = data;
    }
    ngOnInit() { }
};
ViewWishlistComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"],] }] }
];
ViewWishlistComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-view-wishlist',
        template: __webpack_require__(/*! raw-loader!./view-wishlist.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/view-wishlist/view-wishlist.component.html"),
        styles: [__webpack_require__(/*! ./view-wishlist.component.scss */ "./src/app/components/view-wishlist/view-wishlist.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"]))
], ViewWishlistComponent);



/***/ }),

/***/ "./src/app/shared/passwordValidator.ts":
/*!*********************************************!*\
  !*** ./src/app/shared/passwordValidator.ts ***!
  \*********************************************/
/*! exports provided: PasswordValidator */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PasswordValidator", function() { return PasswordValidator; });
function PasswordValidator(control) {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    if (password.pristine || confirmPassword.pristine) {
        return null;
    }
    return password && confirmPassword && password.value != confirmPassword.value ?
        { 'mismatch': true } : null;
}


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    baseUrl: 'http://localhost:8080/'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ "./src/models/cart-book/cart-book.module.ts":
/*!**************************************************!*\
  !*** ./src/models/cart-book/cart-book.module.ts ***!
  \**************************************************/
/*! exports provided: CartBookModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartBookModule", function() { return CartBookModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");



let CartBookModule = class CartBookModule {
};
CartBookModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
        ]
    })
], CartBookModule);



/***/ }),

/***/ "./src/models/cart/cart.module.ts":
/*!****************************************!*\
  !*** ./src/models/cart/cart.module.ts ***!
  \****************************************/
/*! exports provided: CartModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartModule", function() { return CartModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");



let CartModule = class CartModule {
    constructor() {
        this.cartBooks = [];
    }
};
CartModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
        ]
    })
], CartModule);



/***/ }),

/***/ "./src/services/admin.service.ts":
/*!***************************************!*\
  !*** ./src/services/admin.service.ts ***!
  \***************************************/
/*! exports provided: AdminService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminService", function() { return AdminService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http.service */ "./src/services/http.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let AdminService = class AdminService {
    constructor(http) {
        this.http = http;
    }
    getAllSellers() {
        return this.http.GET('admin/getSellersForVerification', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    getAllBooksForVerification() {
        return this.http.GET('admin/getBooksForVerification/' + localStorage.getItem('sellerId'), {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    logout() {
        return this.http.PUT('users/logout', null, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    verfy(bookId, sellerId, verification) {
        return this.http.PUT('admin/bookVerification/' + bookId + '/' + sellerId + '/' + verification, localStorage.getItem('description'), {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
};
AdminService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] }
];
AdminService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], AdminService);



/***/ }),

/***/ "./src/services/book.service.ts":
/*!**************************************!*\
  !*** ./src/services/book.service.ts ***!
  \**************************************/
/*! exports provided: BookService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookService", function() { return BookService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http.service */ "./src/services/http.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let BookService = class BookService {
    constructor(http) {
        this.http = http;
        this.searchBookApi = '/sellers/search/';
        this.booksCountApi = '/sellers/booksCount';
    }
    getAllbooks() {
        return this.http.GET('books/getBooks', '');
    }
    searchBooks(input) {
        return this.http.GET(this.searchBookApi + input, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    getNumberOfItems() {
        return this.http.GET('books/getBookCount', "");
    }
    addToWishListBooks(bookId) {
        return this.http.POST('wishlists/addToWishlist/' + bookId, "", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    viewWishlist() {
        return this.http.GET('wishlists/displayItems', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    deletewishlist(bookId) {
        return this.http.DELETE('wishlists/removeFromWishlist/' + bookId, "", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    sortbookByPriceDesc() {
        return this.http.GET('books/getBooksByPriceDesc', '');
    }
    sortbookByPriceAsc() {
        return this.http.GET('books/getBooksByPriceAsc', '');
    }
    findByPage(findpage) {
        const token = '';
        return this.http.GET('books/getBookByPage?pageNo=' + findpage, token);
    }
    booksCount() {
        return this.http.GET(this.booksCountApi, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
};
BookService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] }
];
BookService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], BookService);



/***/ }),

/***/ "./src/services/cart.service.ts":
/*!**************************************!*\
  !*** ./src/services/cart.service.ts ***!
  \**************************************/
/*! exports provided: CartServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CartServiceService", function() { return CartServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http.service */ "./src/services/http.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let CartServiceService = class CartServiceService {
    constructor(http) {
        this.http = http;
        this.addToCartApi = 'carts/addToCart/';
        this.removeFromCartApi = 'carts/removeFromCart/';
        this.displayItemsApi = 'carts/displayItems';
        this.addQuantityApi = 'carts/addQuantity/';
        this.removeQuantityApi = 'carts/removeQuantity/';
        this.placeOrderApi = 'carts/placeOrder';
        this.updateQuantityApi = 'carts/updateQuantity/';
        this.cartCountApi = 'carts/cartSize';
    }
    addToCart(bookId) {
        return this.http.POST(this.addToCartApi + bookId, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    displayBooksInCart() {
        return this.http.GET(this.displayItemsApi, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    removeFromCart(cartBookId) {
        return this.http.DELETE(this.removeFromCartApi + cartBookId, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    addQuantity(cartBookId) {
        return this.http.PUT(this.addQuantityApi + cartBookId, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    removeQuantity(cartBookId) {
        return this.http.PUT(this.removeQuantityApi + cartBookId, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    placeOrder(cart) {
        return this.http.POST(this.placeOrderApi, cart, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    addToOrder() {
        return this.http.POST('orders/addMyOrder', '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    updateQuantity(quantity, cartBookId) {
        return this.http.PUT(this.updateQuantityApi + cartBookId + '/' + quantity, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    cartCount() {
        return this.http.GET(this.cartCountApi, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
};
CartServiceService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] }
];
CartServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CartServiceService);



/***/ }),

/***/ "./src/services/dashboard.service.ts":
/*!*******************************************!*\
  !*** ./src/services/dashboard.service.ts ***!
  \*******************************************/
/*! exports provided: DashboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardService", function() { return DashboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http.service */ "./src/services/http.service.ts");



let DashboardService = class DashboardService {
    constructor(http) {
        this.http = http;
    }
    search(searchBook) {
        const token = '';
        return this.http.GET('books/bookStoreApplication/getBookByAuthorName?authorName=' + searchBook, token);
    }
};
DashboardService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] }
];
DashboardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], DashboardService);



/***/ }),

/***/ "./src/services/encr-decr.service.ts":
/*!*******************************************!*\
  !*** ./src/services/encr-decr.service.ts ***!
  \*******************************************/
/*! exports provided: EncrDecrService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EncrDecrService", function() { return EncrDecrService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_2__);



let EncrDecrService = class EncrDecrService {
    constructor() { }
    set(keys, value) {
        const key = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8.parse(keys);
        const iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8.parse(keys);
        const encrypted = crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].encrypt(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8.parse(value.toString()), key, {
            keySize: 128 / 8,
            iv,
            mode: crypto_js__WEBPACK_IMPORTED_MODULE_2__["mode"].CBC,
            padding: crypto_js__WEBPACK_IMPORTED_MODULE_2__["pad"].Pkcs7
        });
        return encrypted.toString();
    }
    get(keys, value) {
        const key = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8.parse(keys);
        const iv = crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8.parse(keys);
        const decrypted = crypto_js__WEBPACK_IMPORTED_MODULE_2__["AES"].decrypt(value, key, {
            keySize: 128 / 8,
            iv,
            mode: crypto_js__WEBPACK_IMPORTED_MODULE_2__["mode"].CBC,
            padding: crypto_js__WEBPACK_IMPORTED_MODULE_2__["pad"].Pkcs7
        });
        return decrypted.toString(crypto_js__WEBPACK_IMPORTED_MODULE_2__["enc"].Utf8);
    }
};
EncrDecrService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], EncrDecrService);



/***/ }),

/***/ "./src/services/http.service.ts":
/*!**************************************!*\
  !*** ./src/services/http.service.ts ***!
  \**************************************/
/*! exports provided: HttpService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpService", function() { return HttpService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




let HttpService = class HttpService {
    constructor(http) {
        this.http = http;
        this.baseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl;
    }
    POST(url, data, token) {
        return this.http.post(this.baseUrl + url, data, token);
    }
    GET(url, token) {
        return this.http.get(this.baseUrl + url, token);
    }
    PUT(url, data, token) {
        return this.http.put(this.baseUrl + url, data, token);
    }
    DELETE(url, data, token) {
        return this.http.delete(this.baseUrl + url, token);
    }
};
HttpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
HttpService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], HttpService);



/***/ }),

/***/ "./src/services/message.service.ts":
/*!*****************************************!*\
  !*** ./src/services/message.service.ts ***!
  \*****************************************/
/*! exports provided: MessageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessageService", function() { return MessageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _vendor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./vendor.service */ "./src/services/vendor.service.ts");
/* harmony import */ var _book_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./book.service */ "./src/services/book.service.ts");
/* harmony import */ var _cart_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cart.service */ "./src/services/cart.service.ts");
/* harmony import */ var _admin_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./admin.service */ "./src/services/admin.service.ts");
/* harmony import */ var _dashboard_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./dashboard.service */ "./src/services/dashboard.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm2015/material.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");










let MessageService = class MessageService {
    constructor(vendorService, bookService, cartService, adminService, dashboardService, snackBar, route) {
        this.vendorService = vendorService;
        this.bookService = bookService;
        this.cartService = cartService;
        this.adminService = adminService;
        this.dashboardService = dashboardService;
        this.snackBar = snackBar;
        this.route = route;
        this.messageSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.currentMessage = this.messageSource.asObservable();
        this.userMessageSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.currentUserMessage = this.userMessageSource.asObservable();
        this.cartSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.cartMessage = this.cartSource.asObservable();
        this.adminBookSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.adminBook = this.adminBookSource.asObservable();
        this.adminSellerSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.adminSeller = this.adminSellerSource.asObservable();
        this.quantitySource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.quantityMessage = this.quantitySource.asObservable();
        this.cartCountSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.cartCountMessage = this.cartCountSource.asObservable();
        this.booksCountSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](Response);
        this.booksCountMessage = this.booksCountSource.asObservable();
        this.pageNumSource = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](this.count);
        this.pageNumMessage = this.pageNumSource.asObservable();
    }
    changeMessage(page) {
        this.vendorService.displayBooks(page).subscribe((data) => {
            this.messageSource.next(data);
        });
    }
    searchBook(event) {
        this.bookService.searchBooks(event.target.value).subscribe((data) => {
            this.messageSource.next(data);
        });
    }
    searchUserBook(event) {
        this.dashboardService.search(event.target.value).subscribe((data) => {
            this.userMessageSource.next(data);
        });
    }
    changeoptionMessage() {
        this.bookService.sortbookByPriceDesc().subscribe((data) => {
            this.userMessageSource.next(data);
        });
    }
    changeoptionMessage1() {
        this.bookService.sortbookByPriceAsc().subscribe((data) => {
            this.userMessageSource.next(data);
        });
    }
    cartBooks() {
        if (localStorage.getItem('token') === null &&
            localStorage.getItem('cart') != null) {
            this.cartSource.next(JSON.parse(localStorage.getItem('cart')));
        }
        else {
            this.cartService.displayBooksInCart().subscribe((data) => {
                this.cartSource.next(data);
                this.count = data.data.totalBooksInCart;
            });
        }
    }
    adminBookMessage() {
        this.adminService.getAllBooksForVerification().subscribe((data) => {
            this.adminBookSource.next(data);
        });
    }
    adminSellerMessage() {
        this.adminService.getAllSellers().subscribe((data) => {
            this.adminSellerSource.next(data);
        }, (error) => {
            console.log(error);
            this.snackBar.open(error.error.message, 'ok', { duration: 2000 });
        });
    }
    onGetAllBooks() {
        this.bookService.getAllbooks().subscribe((data) => {
            this.userMessageSource.next(data);
        });
    }
    onViewAllWishlist() {
        this.bookService.viewWishlist().subscribe((data) => {
            this.userMessageSource.next(data);
        });
    }
    onRefresh() {
        this.route.navigate(['/dashboard']);
    }
    onCartRefresh() {
        this.route.navigate(['/dashboard/cart']);
    }
    onUpdateQuantity(event, cartBookId) {
        this.cartService.updateQuantity(event.target.value, cartBookId).subscribe((data) => {
            this.quantitySource.next(data);
        }, (error) => {
            this.quantitySource.next(error);
        });
    }
    onCartCount() {
        this.cartService.cartCount().subscribe(data => {
            this.cartCountSource.next(data);
        }, (error) => {
            this.cartCountSource.next(error);
        });
    }
    onBooksCount() {
        this.bookService.booksCount().subscribe(data => {
            this.booksCountSource.next(data);
        });
    }
    sendByPage(pageIndex) {
        this.bookService.findByPage(pageIndex).subscribe((data) => {
            this.userMessageSource.next(data);
        });
    }
    onPageNum(pageNo) {
        this.pageNumSource.next(pageNo);
    }
};
MessageService.ctorParameters = () => [
    { type: _vendor_service__WEBPACK_IMPORTED_MODULE_3__["VendorService"] },
    { type: _book_service__WEBPACK_IMPORTED_MODULE_4__["BookService"] },
    { type: _cart_service__WEBPACK_IMPORTED_MODULE_5__["CartServiceService"] },
    { type: _admin_service__WEBPACK_IMPORTED_MODULE_6__["AdminService"] },
    { type: _dashboard_service__WEBPACK_IMPORTED_MODULE_7__["DashboardService"] },
    { type: _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatSnackBar"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"] }
];
MessageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], MessageService);



/***/ }),

/***/ "./src/services/review.service.ts":
/*!****************************************!*\
  !*** ./src/services/review.service.ts ***!
  \****************************************/
/*! exports provided: ReviewService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewService", function() { return ReviewService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http.service */ "./src/services/http.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let ReviewService = class ReviewService {
    constructor(http) {
        this.http = http;
    }
    addReview(review, rating) {
        return this.http.POST('review/' + localStorage.getItem('bookId') + '/' + localStorage.getItem('orderid'), { review, rating }, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', localStorage.getItem('token')) });
    }
    getReview(token) {
        return this.http.GET('review/' + localStorage.getItem('bookId'), { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', token) });
    }
    addReviewApp(review, rating, token) {
        return this.http.POST('reviewApp/', { review, rating }, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]().set('token', token) });
    }
};
ReviewService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] }
];
ReviewService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ReviewService);



/***/ }),

/***/ "./src/services/user.service.ts":
/*!**************************************!*\
  !*** ./src/services/user.service.ts ***!
  \**************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./http.service */ "./src/services/http.service.ts");




let UserService = class UserService {
    constructor(http) {
        this.http = http;
        this.orderCheckoutApi = 'orders/checkOut';
    }
    register(user) {
        console.log(user);
        return this.http.POST('users/register', user, '');
    }
    forgotPassword(email) {
        const params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('email', email);
        return this.http.PUT('users/forgotpassword', params, '');
    }
    resetPassword(data, token) {
        console.log('IN USER SERVICE');
        console.log(data);
        console.log(token);
        // const params=new HttpParams().set('token',token);
        return this.http.PUT('users/resetpassword?token=' + token, data, '');
    }
    verification(authorization) {
        const token = '';
        return this.http.GET('user/verify' + authorization, token);
    }
    login(login) {
        return this.http.POST('users/login', login, '');
    }
    uploadProfie(file, isProfile) {
        console.log("IN USERSERVICE TO UPLOAD IMAGE:", file);
        return this.http.POST('users/uploadImage', file, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')), params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('isProfile', isProfile) });
    }
    updateUser(data) {
        console.log("in update user service:", data);
        return this.http.PUT('users/update', data, { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('token', localStorage.getItem('token')) });
    }
    onCheckOut() {
        return this.http.POST(this.orderCheckoutApi, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token'))
        });
    }
    // checkout(bookId,quantity)
    // {
    //   console.log("in user service for checkout",bookId,quantity);
    //   return this.http.POST('orders/checkout/'+bookId+'/'+quantity,'',{ params:new HttpParams().set('token',localStorage.getItem('token'))});
    // }
    checkout(bookSum) {
        // console.log("in user service for checkout",bookId,quantity);
        console.log('books', bookSum);
        return this.http.POST('orders/checkout/', { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('books', bookSum) }, { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('token', localStorage.getItem('token')) });
    }
    getmyOrders() {
        return this.http.GET('orders/myorders', { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')) });
    }
    Address(data) {
        console.log("address in user service:", data);
        return this.http.POST('address/addAddress', data, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')) });
    }
    getAddress(addresstype) {
        return this.http.GET('address/getAddressByType', { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('addressType', addresstype), headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')) });
    }
    verifyUser(token) {
        return this.http.GET('users/verify', { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('token', token) });
    }
};
UserService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_3__["HttpService"] }
];
UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], UserService);



/***/ }),

/***/ "./src/services/vendor.service.ts":
/*!****************************************!*\
  !*** ./src/services/vendor.service.ts ***!
  \****************************************/
/*! exports provided: VendorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VendorService", function() { return VendorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




let VendorService = class VendorService {
    constructor(http) {
        this.http = http;
        this.addBookApi = 'sellers/addBook/';
        this.updateBookApi = 'sellers/updateBook';
        this.deleteBookApi = 'sellers/removeBook/';
        this.displayBookApi = 'sellers/displayBooks/';
        this.uploadBookProfileApi = 'users/uploadImage';
        this.approveBookApi = 'sellers/approvalSent/';
    }
    addBook(book) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + this.addBookApi, book, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    displayBooks(page) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + this.displayBookApi, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')),
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('pageNo', page)
        });
    }
    deleteBooks(bookId) {
        return this.http.delete(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + this.deleteBookApi + bookId, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    uploadBookImage(file, isProfile) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + this.uploadBookProfileApi, file, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')),
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('isProfile', isProfile),
        });
    }
    updateBook(formGroup, bookId) {
        return this.http.put(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + this.updateBookApi + '/' + bookId, formGroup, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
    onApprove(bookId) {
        return this.http.put(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUrl + this.approveBookApi + bookId, '', {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('token', localStorage.getItem('token')),
        });
    }
};
VendorService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
VendorService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], VendorService);



/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\kaman\Desktop\final projects\Online-Bookstore-App-Angular-master\Online-Bookstore-App-Angular-master\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map