export interface ResetPassword {
    password: string;
}
